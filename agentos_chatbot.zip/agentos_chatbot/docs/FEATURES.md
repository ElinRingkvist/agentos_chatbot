# Feature map

Every item from the product spec, where it lives, and what it needs to run.

**Status legend**
- ✅ **Works out of the box** (offline, no keys)
- 🔑 **Needs a key/account** (set in `.env`, see `.env.example`)
- 🧩 **Server side done; needs a client app** — the backend/API is here, the native app (iOS/Android/desktop overlay/editor plugin) is not part of this repo

## Persistent agent architecture & environment

| Feature | Status | Implementation |
|---|---|---|
| Persistent cloud computers (own FS, terminal, browser) | ✅ / 🔑 browser needs `playwright` | `workspace/workspace.ts`, `security/sandbox.ts`, `browser/cloudBrowser.ts` |
| Proactive initiation ("messages you first") | ✅ | `proactive/heartbeat.ts` — pluggable scanners, LLM triage, de-duplication |
| Morning digest | ✅ (+🔑 per source) | `proactive/digest.ts` — time & sections configurable (`PUT /digest/settings`) |
| Shared context window & memory | ✅ | `core/memory.ts` `buildContext()` injected into every agent prompt |
| Multi-hour task execution | ✅ | `tasks/taskQueue.ts` — planned steps, checkpoint per step, notify when ready |
| Semantic codebase indexing | ✅ | `indexing/codeIndex.ts` — local, incremental, symbols + vector chunks |
| Context anchors (files, folders, git diffs, docs, web) | ✅ | `context/anchors.ts` — `@file:` `@folder:` `@git` `@url:` `@web:` |
| Conversation search & instant grep | ✅ | `search/conversationSearch.ts` — inverted index + regex grep |
| Local workspace file management | ✅ | `fs.read/write/modify/list/delete` tools |
| Security & sandboxing | ✅ | `security/policy.ts` (allow/deny, roles, profiles), `security/sandbox.ts` |
| Shell & terminal execution | ✅ | `shell.run` tool; history shared via API/SSE to every device |
| Workflow learning by demonstration | ✅ | `skills/skills.ts` — records GUI/browser/tool actions → parameterised skill |
| Laptop-closed execution | ✅ | `cli.ts daemon` + `daemon/service.ts` (systemd/launchd/Task Scheduler); tasks resume after restart |
| Desktop & phone (iOS, Android, Linux) | 🧩 | `devices/devices.ts` pairing + `server/api.ts` |
| Compounding long-term memory | ✅ | categories incl. preferences, files, browser sessions; hit-count ranking |
| Internet searching (Chrome, Safari, Edge) | ✅ / 🔑 | `search/webSearch.ts` (Google CSE, Brave, DuckDuckGo) + real browsers via Playwright channels |

## Multi-agent collaboration & workspace

| Feature | Status | Implementation |
|---|---|---|
| Parallel multi-bot tasks | ✅ | `multiagent/router.ts` `parallel()`; `engine.createAgent()` for Inbox Manager, Talent Scout, Expense Manager… |
| Team bots & access lists (+ subscription gating) | ✅ | `multiagent/teams.ts` |
| Voice + text input | ✅ / 🔑 | `voice/voice.ts` (whisper.cpp offline or HF Whisper), `POST /voice` |
| Small always-on-top chat window | 🧩 | client app; uses `/route`, `/voice`, `/events` |
| Multi-agent group chats | ✅ | `multiagent/groupChat.ts` — handoffs, merged citations |
| Multi-agent routing (isolated sessions) | ✅ | `multiagent/router.ts` — per-agent lock prevents overlap |
| Dynamic working memory (CMS) | ✅ | `cms/workingMemory.ts` — versioned, locked, optimistic concurrency |

## Workflows, routines & controls

| Feature | Status | Implementation |
|---|---|---|
| Dynamic activity states (Idle/Working/Done) | ✅ | `agent.status` events on `/events`, `GET /agents` |
| Attention effects on notifications | ✅ / 🧩 | `notifications/notifier.ts` `effect` hint (loud/gentle/typing), ntfy priorities |
| Instinct Concierge (voice calls) | 🔑 Twilio | `connectors/telephony.ts` + `/webhooks/twilio/*` |
| Dedicated assistant email address | 🔑 IMAP/SMTP | `connectors/email.ts` — aliases, verification-code extraction |
| Persistent cloud desktop | ✅ / 🔑 | cloud browser + GUI automation (`connectors/mausBot.ts`) |
| Automated routines (time & event triggers) | ✅ | `scheduler/routines.ts`, `scheduler/cron.ts` ("every Friday morning") |
| Human-in-the-loop approvals | ✅ | `approvals/approvals.ts` — approve / reject / edit |
| Sign-in & log-in memory | ✅ | `credentials/vault.ts` (AES-256-GCM, TOTP) + `CloudBrowser.login()` |
| 24/7 proactive automation | ✅ | daemon + heartbeat + routines |
| Cron & heartbeat scheduling | ✅ | default digest routine; add more via CLI/API |

## Ecosystem & app integrations

| Feature | Status | Implementation |
|---|---|---|
| Native platform connectors (Google, Microsoft, Apple) | 🔑 / macOS | `connectors/platforms.ts` |
| Mobile remote control of local agents | 🧩 | pairing codes, device tokens, SSE (`devices/`, `server/api.ts`) |
| Group DM integration | 🔑 | `connectors/messaging.ts` — Telegram groups, SMS, iMessage, plan extraction |
| OS-level permissions | ✅ (per-profile grant) | `os/permissions.ts` — clipboard, screen, mic, location |
| Code hosting / CI-CD / monitoring | 🔑 | `connectors/devtools.ts` — GitHub, Vercel, Cloudflare, Sentry, Linear, Supabase |
| Slack & Linear agents | 🔑 | `/webhooks/slack` (mention → background task → thread reply), `/webhooks/linear` (label `agent`) |
| BugBot & security review | ✅ static / 🔑 GitHub | `review/bugbot.ts` + `/webhooks/github` auto-review on PRs |
| Model Context Protocol | ✅ | `mcp/mcpClient.ts` — stdio + streamable HTTP, `.agentos/mcp.json` |
| Smart tab completion | ✅ engine / 🧩 editor plugin | `code/editing.ts` `predictCompletion()`, `POST /code/complete` |
| Inline edits | ✅ | `inlineEdit()`, `POST /code/edit` |
| Preserved code diffs (accept/reject hunks) | ✅ | `code/diff.ts` unified + side-by-side + per-hunk apply |
| Composer (multi-file edits) | ✅ | `Composer` — staged, atomic apply, rollback |
| Projects (long initiatives, many subagents) | ✅ | `projects/orchestrator.ts` — milestone DAG over the task queue |
| Agent mode vs Ask mode | ✅ | `agent.run(…, { mode: "ask" | "agent" })` |
| Cloud agents & canvases (share links) | ✅ | `canvas/canvas.ts`, `GET /canvas/:id?t=…` |
| Cross-platform access | 🧩 | API is platform-agnostic; service installers for macOS/Windows/Linux |
| Continue on another device | ✅ | `devices.handoff()`, automatic handoff when a device goes offline |
| Document & slide generation / analysis | ✅ (+ `pdf-parse` for PDF input) | `documents/documents.ts` — PDF, HTML slides, spreadsheet, CSV, markdown |
| Interactive media cards (Lovable, Canva, Figma, Notion) | 🔑 | `connectors/creative.ts` |
| Local image manipulation (logo variants) | ✅ SVG / `sharp` for PNG | `media/images.ts` |
| Live canvas workspaces | ✅ | agents generate/revise versioned HTML canvases |
| Overnight summarisation | ✅ | part of the digest (since last digest) |
| Unread-messages navigation (read & answer) | 🔑 per channel | `proactive/inbox.ts` |
| Social media (read, comment, post, DMs) | 🔑 | `connectors/social.ts` — Mastodon, Bluesky, X |
| Traffic & maps | ✅ OSM/OSRM / 🔑 Google live traffic | `connectors/maps.ts` + commute in digest |

## Honest limitations

- No native mobile/desktop apps, overlay window or editor extension are included — they are clients of the API.
- iMessage reading/sending works only on a Mac running the daemon (AppleScript + Full Disk Access).
- Phone calls require a Twilio number and a public HTTPS URL (`PUBLIC_BASE_URL`), e.g. via a tunnel.
- "Laptop closed" means the daemon must run somewhere that stays on (a server/VM, or a Mac set to stay awake on power).
