<div align="center">

# 🤖 Agentic OS
### The Open-Source, Offline-First Multi-Agent Operating System

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![TypeScript](https://img.shields.io/badge/TypeScript-Ready-blue?logo=typescript)](https://www.typescriptlang.org/)
[![Hugging Face](https://img.shields.io/badge/Hugging%20Face-Qwen2.5--Coder-yellow?logo=huggingface)](https://huggingface.co/)

*Persistent background agents with memory, tools, sandboxed terminals, browsers, routines, approvals and 20+ integrations — running locally or on your own server.*

[Quick Start](#-quick-start) • [Architecture](#-architecture) • [Features](docs/FEATURES.md) • [API](#-remote-control-api) • [Contributing](#-contributing)

</div>

---

## 🌟 What is Agentic OS?

**Agentic OS** is a modular TypeScript/Node.js runtime for autonomous AI agents. Each agent has its own persistent workspace (file system + terminal + browser profile), shares a compounding long-term memory, and runs 24/7 as a daemon: it executes multi-hour tasks, sweeps your connected apps every few hours, messages you first when something needs attention, and pauses for your approval before sensitive actions.

It is **headless by design** — there is no bundled UI. Desktop, tablet, phone and editor clients talk to the [remote-control API](#-remote-control-api) (JSON + Server-Sent Events).

## 🚀 Quick Start

```bash
git clone https://github.com/ElinRingkvist/agentos_chatbot.git
cd agentos_chatbot
npm install
cp .env.example .env          # optional: add model + integration keys

npm start                     # demo workflow
npm run daemon                # 24/7 mode: heartbeat, routines, tasks, API on :7717
npm run cli -- help           # all CLI commands
npm test
```

**Models.** By default it talks to any OpenAI-compatible server on `http://localhost:11434/v1` (Ollama: `ollama pull qwen2.5-coder:7b`). Set `HF_TOKEN` to use the Hugging Face router instead, or `LLM_PROVIDER=offline` for a deterministic stub (CI). If the model is unreachable it falls back to offline mode instead of crashing.

## 🧠 Architecture

```text
                    ┌──────────── Remote-control API (HTTP + SSE) ────────────┐
 phone / desktop /  │  agents · tasks · approvals · inbox · digest · devices  │  Slack · Linear · GitHub
 editor plugins ───►│  code completion/edits · composer · canvas share links  │◄─ Twilio webhooks
                    └───────────────────────────┬─────────────────────────────┘
                                                │
   ┌──────────────────────────── AgenticOS kernel (core/engine) ───────────────────────────┐
   │ Agents (ask/agent mode, tool loop) ─ Router ─ Group chat ─ Parallel ─ Projects        │
   │ TaskQueue (checkpointed, resumable) ─ Routines (cron/natural/event) ─ Skills          │
   │ Heartbeat scanners ─ Morning digest ─ Unified inbox ─ Notifier (ntfy/Telegram/Slack)   │
   │ Tool registry ──► Security policy (allow/deny, roles, profiles) ──► Approval cards    │
   │ Memory (semantic) ─ Conversation index ─ Code index ─ CMS working memory ─ Vault       │
   └───────────┬───────────────┬──────────────┬───────────────┬──────────────┬─────────────┘
         Workspace+sandbox  Cloud browser   MausBot GUI     MCP servers    Connectors
         (process/docker)   (Playwright)    (xdotool/...)   (stdio/http)   email, calendar, Google,
                                                                           Microsoft, Apple, social,
                                                                           maps, telephony, devops…
```

| Folder | What lives there |
|---|---|
| `src/core` | Kernel, agent loop, long-term memory |
| `src/ai` | LLM providers (OpenAI-compatible, HF, offline), embeddings, HF tasks |
| `src/tools` | Tool registry + built-in and integration tools |
| `src/security` | Pre-model tool policy, command rules, sandboxed execution |
| `src/approvals` | Human-in-the-loop approval cards |
| `src/tasks`, `src/projects` | Multi-hour background tasks, multi-milestone projects |
| `src/scheduler`, `src/skills` | Cron/natural-language/event routines, skills learned by demonstration |
| `src/multiagent` | Routing, parallel bots, group chats, team access lists |
| `src/proactive` | Heartbeat scanners, morning digest, unified inbox |
| `src/indexing`, `src/search`, `src/context` | Code index, conversation search/grep, context anchors |
| `src/code` | Diff engine, inline edits, tab completion, multi-file composer |
| `src/connectors` | Email, calendar, Google, Microsoft, Apple, messaging, social, telephony, maps, devtools, creative apps, GUI |
| `src/server`, `src/devices`, `src/daemon` | API, device pairing/handoff, OS service install |

See **[docs/FEATURES.md](docs/FEATURES.md)** for every feature, where it is implemented and what it needs.

## 🔌 Remote-control API

Start with `npm run daemon`. Every request needs `Authorization: Bearer <token>` (token in `.agentos/api-token`, or a paired device token).

```bash
TOKEN=$(cat .agentos/api-token)
curl -H "Authorization: Bearer $TOKEN" localhost:7717/agents
curl -H "Authorization: Bearer $TOKEN" -H 'content-type: application/json' \
     -d '{"goal":"Build a KPI dashboard from data/sales.csv","agent":"DevBot"}' localhost:7717/tasks
curl -N -H "Authorization: Bearer $TOKEN" localhost:7717/events     # live status stream
```

Main routes: `/agents`, `/agents/:name/run`, `/route`, `/parallel`, `/group`, `/tasks`, `/projects`, `/approvals/:id`, `/routines`, `/skills/*`, `/memory/search`, `/conversations/search`, `/index`, `/code/complete`, `/code/edit`, `/composer/*`, `/inbox`, `/digest`, `/notifications`, `/devices/*`, `/sessions/*`, `/voice`, `/vault`, `/teams/*`, `/canvas/:id`, `/webhooks/{slack,linear,github,twilio}`.

## 🔐 Security model

- Tools are filtered **before** the model sees them (profile allow/deny globs + identity role).
- Shell commands run in a scrubbed environment jailed to the agent workspace (or a `--network none` Docker container with `AGENTOS_SANDBOX_MODE=docker`); destructive patterns are always blocked.
- Sending email/messages, posting, phone calls, form submits, pushes and deletes create **approval cards** (approve / reject / edit) in the terminal, API or notification.
- Credentials live in an AES-256-GCM vault; webhooks are HMAC-verified.

## 🤝 Contributing

PRs welcome. Run `npm run typecheck && npm test` before opening one. New integrations go in `src/connectors/` and are exposed to agents in `src/tools/integrations.ts`.

## 📄 License

MIT © Elin Ringkvist
