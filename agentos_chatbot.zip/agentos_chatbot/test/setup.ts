import * as fs from "fs";
import * as os from "os";
import * as path from "path";

// Isolate every test run in a throwaway data directory and force the offline model.
const home = fs.mkdtempSync(path.join(os.tmpdir(), "agentos-test-"));
process.env.AGENTOS_HOME = home;
process.env.AGENTOS_WORKSPACES = path.join(home, "workspaces");
process.env.LLM_PROVIDER = "offline";
process.env.AGENTOS_APPROVAL_MODE = "auto";
process.env.MAUSBOT_DRY_RUN = "1";
process.env.AGENTOS_VAULT_KEY = "test-master-key";
process.env.AGENTOS_MEMORY_FILE = path.join(home, ".agent_memory.json");
