import { test } from "node:test";
import * as assert from "node:assert/strict";
import * as fs from "fs";
import { AgenticOS } from "../src/core/engine";
import { tools } from "../src/tools/registry";
import { writePdf } from "../src/documents/documents";
import { dataPath } from "../src/utils/fsx";

test("engine boots offline with default agents and tools", async () => {
  const os = new AgenticOS("en");
  assert.ok(os.agents.has("DevBot"));
  assert.ok(tools.get("shell.run"));
  const out = await os.agents.get("DevBot")!.run("hello", { mode: "ask" });
  assert.match(out, /offline model/);
  assert.equal(os.agents.get("DevBot")!.status, "Done");
});

test("tool registry enforces profile policy at invocation", async () => {
  const r = await tools.invoke("shell.run", { command: "echo hi" }, { agent: "R", profile: "readonly", role: "owner", workspace: "." });
  assert.equal(r.ok, false);
  assert.match(r.error ?? "", /security policy/);
});

test("sandboxed shell runs inside the agent workspace with a scrubbed env", async () => {
  process.env.SUPER_SECRET = "leak";
  const r = await tools.invoke("shell.run", { command: "echo $SUPER_SECRET-$AGENTOS_SANDBOX" }, { agent: "Dev", profile: "developer", role: "owner", workspace: "." });
  assert.equal(r.ok, true);
  assert.equal((r.result as any).stdout.trim(), "-1");
});

test("background task is planned, executed step by step and awaits review", async () => {
  const os = new AgenticOS("en");
  const t = await os.tasks.enqueue({ title: "demo", goal: "write a haiku", agent: "DevBot", steps: ["draft", "polish"], notifyOnDone: false });
  for (let i = 0; i < 100 && os.tasks.get(t.id)?.status !== "waiting_review"; i++) await new Promise((r) => setTimeout(r, 50));
  const done = os.tasks.get(t.id)!;
  assert.equal(done.status, "waiting_review");
  assert.deepEqual(done.steps.map((s) => s.status), ["done", "done"]);
});

test("pdf writer produces a valid PDF header and trailer", () => {
  const f = writePdf(dataPath("out", "t.pdf"), "Title", "Hello world ".repeat(500));
  const s = fs.readFileSync(f, "latin1");
  assert.ok(s.startsWith("%PDF-1.4"));
  assert.ok(s.trimEnd().endsWith("%%EOF"));
  assert.match(s, /\/Count [2-9]/);
});
