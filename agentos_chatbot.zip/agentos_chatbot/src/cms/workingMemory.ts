import * as fs from "fs";
import * as path from "path";
import { dataPath, readJson, safeJoin, writeJson } from "../utils/fsx";

export interface CmsDoc {
  key: string;
  content: string;
  contentType: "text" | "json" | "config" | "api" | "context";
  version: number;
  updatedBy: string;
  updatedAt: string;
  history: { version: number; updatedBy: string; updatedAt: string }[];
}

/**
 * Dynamic working memory: a file-based CMS that agents use as a single source
 * of truth for structure, context, API specs and configuration. Optimistic
 * concurrency (expectedVersion) plus a lock file prevent agents from
 * clobbering each other. Old versions are kept for rollback.
 */
export class WorkingMemoryCMS {
  private root = path.dirname(dataPath("cms", ".keep"));

  private fileFor(key: string) {
    return safeJoin(this.root, `${key.replace(/[^\w./-]/g, "_")}.json`);
  }

  private withLock<T>(key: string, fn: () => T): T {
    const lock = this.fileFor(key) + ".lock";
    fs.mkdirSync(path.dirname(lock), { recursive: true });
    const deadline = Date.now() + 5000;
    for (;;) {
      try {
        fs.writeFileSync(lock, String(process.pid), { flag: "wx" });
        break;
      } catch {
        try {
          if (Date.now() - fs.statSync(lock).mtimeMs > 30_000) fs.rmSync(lock, { force: true });
        } catch {
          /* raced */
        }
        if (Date.now() > deadline) throw new Error(`CMS key "${key}" is locked by another agent`);
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 25);
      }
    }
    try {
      return fn();
    } finally {
      fs.rmSync(lock, { force: true });
    }
  }

  get(key: string): CmsDoc | null {
    return readJson<CmsDoc | null>(this.fileFor(key), null);
  }

  put(key: string, content: string, agent: string, expectedVersion?: number, contentType: CmsDoc["contentType"] = "text"): CmsDoc {
    return this.withLock(key, () => {
      const cur = this.get(key);
      if (expectedVersion !== undefined && (cur?.version ?? 0) !== expectedVersion) {
        throw new Error(`Version conflict on "${key}": expected ${expectedVersion}, found ${cur?.version ?? 0}. Re-read and merge.`);
      }
      const file = this.fileFor(key);
      if (cur) writeJson(`${file}.v${cur.version}`, cur);
      const now = new Date().toISOString();
      const doc: CmsDoc = {
        key,
        content,
        contentType,
        version: (cur?.version ?? 0) + 1,
        updatedBy: agent,
        updatedAt: now,
        history: [...(cur?.history ?? []), { version: (cur?.version ?? 0) + 1, updatedBy: agent, updatedAt: now }].slice(-50),
      };
      writeJson(file, doc);
      return doc;
    });
  }

  rollback(key: string, version: number, agent: string): CmsDoc {
    const old = readJson<CmsDoc | null>(`${this.fileFor(key)}.v${version}`, null);
    if (!old) throw new Error(`No version ${version} of ${key}`);
    return this.put(key, old.content, agent, undefined, old.contentType);
  }

  list(prefix = ""): string[] {
    const out: string[] = [];
    const walk = (dir: string) => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) walk(full);
        else if (e.name.endsWith(".json")) out.push(path.relative(this.root, full).replace(/\.json$/, ""));
      }
    };
    if (fs.existsSync(this.root)) walk(this.root);
    return out.filter((k) => k.startsWith(prefix));
  }
}

export const cms = new WorkingMemoryCMS();
