import { dataPath, readJson, writeJson } from "../utils/fsx";

export type IdentityRole = "owner" | "admin" | "member" | "viewer";

/** OS-level capabilities that must be granted explicitly per profile. */
export type OSPermission = "clipboard" | "screen" | "microphone" | "location" | "messages" | "email" | "contacts" | "notifications" | "gui";

export interface ToolProfile {
  name: string;
  /** Glob patterns, e.g. "fs.*", "shell.run". Empty = nothing allowed. */
  allowTools: string[];
  denyTools: string[];
  /** Tools that pause for a human-in-the-loop approval card before running. */
  approvalTools: string[];
  /** Regex sources. A command must match one allow rule (if any) and no deny rule. */
  allowCommands: string[];
  denyCommands: string[];
  network: boolean;
  osPermissions: OSPermission[];
  /** Minimum identity role allowed to operate an agent with this profile. */
  minRole: IdentityRole;
}

export interface PolicyDecision {
  allowed: boolean;
  needsApproval: boolean;
  reason: string;
}

const ROLE_RANK: Record<IdentityRole, number> = { viewer: 0, member: 1, admin: 2, owner: 3 };

/** Always-on deny list applied to every shell command regardless of profile. */
export const HARD_DENY_COMMANDS = [
  String.raw`\brm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r)[a-z]*\s+(\/|~|\$HOME)(\s|$)`,
  String.raw`\bmkfs(\.\w+)?\b`,
  String.raw`\bdd\b.*\bof=\/dev\/`,
  String.raw`:\(\)\s*\{\s*:\|:&\s*\};:`,
  String.raw`\b(shutdown|reboot|halt|poweroff)\b`,
  String.raw`(curl|wget)[^|]*\|\s*(sudo\s+)?(ba|z)?sh\b`,
  String.raw`\bchmod\s+-R\s+777\s+\/`,
  String.raw`>\s*\/dev\/sd[a-z]`,
  String.raw`\bsudo\b`,
];

/** Sensitive action kinds that always require approval (bank, outbound comms, publishing). */
export const SENSITIVE_ACTIONS = /(wire|bank|iban|payment|transfer|send[_ ]?email|email\.send|reply|submit|publish|post|tweet|call\.place|purchase|delete)/i;

export const DEFAULT_PROFILES: Record<string, ToolProfile> = {
  readonly: {
    name: "readonly",
    allowTools: ["fs.read", "fs.list", "search.*", "memory.search", "code.search", "web.*"],
    denyTools: ["shell.*", "fs.write", "fs.delete"],
    approvalTools: [],
    allowCommands: [],
    denyCommands: [],
    network: true,
    osPermissions: [],
    minRole: "viewer",
  },
  developer: {
    name: "developer",
    allowTools: ["fs.*", "shell.run", "search.*", "memory.*", "code.*", "web.*", "git.*", "mcp.*", "browser.*"],
    denyTools: [],
    approvalTools: ["fs.delete", "git.push"],
    allowCommands: [],
    denyCommands: [String.raw`\bgit\s+push\s+.*--force`],
    network: true,
    osPermissions: [],
    minRole: "member",
  },
  assistant: {
    name: "assistant",
    allowTools: ["search.*", "memory.*", "web.*", "email.*", "calendar.*", "messages.*", "notify.*", "browser.*", "maps.*", "social.*", "call.*", "docs.*", "fs.read", "fs.list", "fs.write"],
    denyTools: ["shell.*"],
    approvalTools: ["email.send", "messages.send", "social.post", "call.place", "browser.submit"],
    allowCommands: [],
    denyCommands: [],
    network: true,
    osPermissions: ["notifications", "email", "messages", "location"],
    minRole: "member",
  },
  admin: {
    name: "admin",
    allowTools: ["*"],
    denyTools: [],
    approvalTools: ["email.send", "messages.send", "social.post", "call.place", "git.push", "fs.delete", "vault.*"],
    allowCommands: [],
    denyCommands: [],
    network: true,
    osPermissions: ["clipboard", "screen", "microphone", "location", "messages", "email", "contacts", "notifications", "gui"],
    minRole: "admin",
  },
};

export function globMatch(pattern: string, value: string): boolean {
  const re = new RegExp("^" + pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".") + "$");
  return re.test(value);
}

export class SecurityPolicy {
  private profiles: Record<string, ToolProfile>;
  private file = dataPath("security", "profiles.json");

  constructor() {
    this.profiles = { ...DEFAULT_PROFILES, ...readJson<Record<string, ToolProfile>>(this.file, {}) };
  }

  getProfile(name: string): ToolProfile {
    const p = this.profiles[name];
    if (!p) throw new Error(`Unknown security profile: ${name}`);
    return p;
  }

  /** Create or replace a custom profile (persisted). */
  upsertProfile(profile: ToolProfile) {
    this.profiles[profile.name] = profile;
    const custom = Object.fromEntries(Object.entries(this.profiles).filter(([k]) => !(k in DEFAULT_PROFILES) || this.profiles[k] !== DEFAULT_PROFILES[k]));
    writeJson(this.file, custom);
  }

  listProfiles(): ToolProfile[] {
    return Object.values(this.profiles);
  }

  /** Pre-model tool policy: evaluated before a tool is exposed to or executed for an agent. */
  checkTool(profileName: string, tool: string, role: IdentityRole = "owner", args: Record<string, unknown> = {}): PolicyDecision {
    const p = this.getProfile(profileName);
    if (ROLE_RANK[role] < ROLE_RANK[p.minRole]) return { allowed: false, needsApproval: false, reason: `role ${role} below ${p.minRole}` };
    if (p.denyTools.some((g) => globMatch(g, tool))) return { allowed: false, needsApproval: false, reason: `tool ${tool} denied by profile ${p.name}` };
    if (!p.allowTools.some((g) => globMatch(g, tool))) return { allowed: false, needsApproval: false, reason: `tool ${tool} not in allow list of ${p.name}` };
    if (!p.network && /^(web|search|browser|email|social|call|messages)\./.test(tool)) {
      return { allowed: false, needsApproval: false, reason: "network disabled for profile" };
    }
    if (tool === "shell.run" && typeof args.command === "string") {
      const c = this.checkCommand(profileName, args.command);
      if (!c.allowed) return c;
    }
    const needsApproval = p.approvalTools.some((g) => globMatch(g, tool)) || SENSITIVE_ACTIONS.test(tool);
    return { allowed: true, needsApproval, reason: "ok" };
  }

  checkCommand(profileName: string, command: string): PolicyDecision {
    const p = this.getProfile(profileName);
    for (const src of [...HARD_DENY_COMMANDS, ...p.denyCommands]) {
      if (new RegExp(src, "i").test(command)) return { allowed: false, needsApproval: false, reason: `command blocked by rule /${src}/` };
    }
    if (p.allowCommands.length && !p.allowCommands.some((src) => new RegExp(src, "i").test(command))) {
      return { allowed: false, needsApproval: false, reason: "command not in allow list" };
    }
    return { allowed: true, needsApproval: false, reason: "ok" };
  }

  hasOSPermission(profileName: string, perm: OSPermission): boolean {
    return this.getProfile(profileName).osPermissions.includes(perm);
  }

  toolsVisibleTo(profileName: string, allTools: string[], role: IdentityRole = "owner"): string[] {
    return allTools.filter((t) => this.checkTool(profileName, t, role).allowed);
  }
}

export const policy = new SecurityPolicy();
