import { spawn } from "child_process";
import * as fs from "fs";

export interface RunOptions {
  cwd: string;
  timeoutMs?: number;
  maxOutputBytes?: number;
  env?: Record<string, string>;
  /** "process" (default): scrubbed child process jailed to cwd. "docker": throwaway container with no network. */
  mode?: "process" | "docker";
  network?: boolean;
  stdin?: string;
  onData?: (chunk: string) => void;
}

export interface RunResult {
  code: number | null;
  stdout: string;
  stderr: string;
  timedOut: boolean;
  durationMs: number;
}

/** Minimal environment so secrets from the host process never leak into agent commands. */
function scrubbedEnv(cwd: string, extra: Record<string, string> = {}): Record<string, string> {
  return {
    PATH: process.env.PATH ?? "/usr/local/bin:/usr/bin:/bin",
    HOME: cwd,
    LANG: process.env.LANG ?? "C.UTF-8",
    TERM: "dumb",
    AGENTOS_SANDBOX: "1",
    ...extra,
  };
}

export function runSandboxed(command: string, opts: RunOptions): Promise<RunResult> {
  fs.mkdirSync(opts.cwd, { recursive: true });
  const mode = opts.mode ?? (process.env.AGENTOS_SANDBOX_MODE as RunOptions["mode"]) ?? "process";
  const timeoutMs = opts.timeoutMs ?? 120_000;
  const max = opts.maxOutputBytes ?? 1_000_000;
  const started = Date.now();

  const [bin, args] =
    mode === "docker"
      ? [
          "docker",
          [
            "run", "--rm", "-i",
            ...(opts.network ? [] : ["--network", "none"]),
            "--memory", "1g", "--cpus", "1", "--pids-limit", "256",
            "-v", `${opts.cwd}:/work`, "-w", "/work",
            process.env.AGENTOS_SANDBOX_IMAGE ?? "node:20-bookworm-slim",
            "sh", "-lc", command,
          ],
        ]
      : process.platform === "win32"
        ? ["cmd.exe", ["/d", "/s", "/c", command]]
        : ["/bin/sh", ["-c", command]];

  return new Promise((resolve) => {
    const child = spawn(bin as string, args as string[], {
      cwd: opts.cwd,
      env: mode === "docker" ? process.env : scrubbedEnv(opts.cwd, opts.env),
      stdio: ["pipe", "pipe", "pipe"],
      detached: process.platform !== "win32",
    });
    let stdout = "";
    let stderr = "";
    let timedOut = false;
    const cap = (s: string, add: string) => (s.length + add.length > max ? (s + add).slice(0, max) : s + add);
    child.stdout.on("data", (d) => {
      const t = d.toString();
      stdout = cap(stdout, t);
      opts.onData?.(t);
    });
    child.stderr.on("data", (d) => {
      const t = d.toString();
      stderr = cap(stderr, t);
      opts.onData?.(t);
    });
    if (opts.stdin) child.stdin.write(opts.stdin);
    child.stdin.end();
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        if (child.pid && process.platform !== "win32") process.kill(-child.pid, "SIGKILL");
        else child.kill("SIGKILL");
      } catch {
        /* already gone */
      }
    }, timeoutMs);
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ code, stdout, stderr, timedOut, durationMs: Date.now() - started });
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      resolve({ code: -1, stdout, stderr: stderr + String(err), timedOut, durationMs: Date.now() - started });
    });
  });
}
