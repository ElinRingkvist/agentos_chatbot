import * as path from "path";
import { optionalRequire } from "../utils/fsx";
import { Logger } from "../utils/logger";
import { bus } from "../events/bus";
import { vault } from "../credentials/vault";

export type BrowserKind = "chrome" | "edge" | "safari" | "chromium" | "firefox";

/**
 * Persistent cloud/desktop browser driven by Playwright (optional dependency:
 * `npm i playwright && npx playwright install`). Uses a persistent profile per
 * agent so cookies and logged-in sessions survive restarts. Navigates, clicks,
 * fills and submits forms without needing site APIs.
 */
export class CloudBrowser {
  private context: any = null;
  private page: any = null;

  constructor(private profileDir: string, private kind: BrowserKind = "chromium", private headless = process.env.BROWSER_HEADLESS !== "0") {}

  private async ensure() {
    if (this.page) return this.page;
    const pw = optionalRequire<any>("playwright");
    const engine = this.kind === "safari" ? pw.webkit : this.kind === "firefox" ? pw.firefox : pw.chromium;
    const channel = this.kind === "chrome" ? "chrome" : this.kind === "edge" ? "msedge" : undefined;
    this.context = await engine.launchPersistentContext(path.resolve(this.profileDir, this.kind), { headless: this.headless, channel, viewport: { width: 1366, height: 900 } });
    this.page = this.context.pages()[0] ?? (await this.context.newPage());
    return this.page;
  }

  async goto(url: string) {
    const p = await this.ensure();
    await p.goto(url, { waitUntil: "domcontentloaded" });
    bus.emit("demo.action", { kind: "browser.goto", data: { url } });
    return { url: p.url(), title: await p.title() };
  }

  async click(selectorOrText: string) {
    const p = await this.ensure();
    const loc = selectorOrText.startsWith("text=") || /^[#.\[]/.test(selectorOrText) ? p.locator(selectorOrText) : p.getByText(selectorOrText, { exact: false });
    await loc.first().click();
    bus.emit("demo.action", { kind: "browser.click", data: { target: selectorOrText } });
  }

  async fill(selector: string, value: string) {
    const p = await this.ensure();
    await p.locator(selector).first().fill(value);
    bus.emit("demo.action", { kind: "browser.fill", data: { selector, value: /pass/i.test(selector) ? "***" : value } });
  }

  async submit(selector = "form") {
    const p = await this.ensure();
    await p.locator(selector).first().evaluate((f: any) => (f.requestSubmit ? f.requestSubmit() : f.submit()));
    bus.emit("demo.action", { kind: "browser.submit", data: { selector } });
  }

  async text(maxChars = 15_000): Promise<string> {
    const p = await this.ensure();
    return String(await p.evaluate(() => (globalThis as any).document.body.innerText)).slice(0, maxChars);
  }

  async screenshot(file: string) {
    const p = await this.ensure();
    await p.screenshot({ path: file });
    return file;
  }

  /** Search using the real engine in the selected browser. */
  async search(query: string) {
    const engines: Record<BrowserKind, string> = {
      chrome: "https://www.google.com/search?q=",
      chromium: "https://www.google.com/search?q=",
      safari: "https://www.google.com/search?q=",
      edge: "https://www.bing.com/search?q=",
      firefox: "https://duckduckgo.com/?q=",
    };
    await this.goto(engines[this.kind] + encodeURIComponent(query));
    return this.text(8000);
  }

  /** Auto-login using credentials from the encrypted vault. */
  async login(site: string, opts: { url: string; userSelector: string; passSelector: string; submitSelector?: string }) {
    const cred = vault.get(site);
    if (!cred) throw new Error(`No stored credentials for ${site}`);
    await this.goto(opts.url);
    await this.fill(opts.userSelector, cred.username);
    await this.fill(opts.passSelector, cred.password);
    if (opts.submitSelector) await this.click(opts.submitSelector);
    else await this.submit();
    Logger.success("Browser", `Signed in to ${site} as ${cred.username}`);
  }

  async close() {
    await this.context?.close();
    this.context = this.page = null;
  }
}
