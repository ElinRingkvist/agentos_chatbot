import * as fs from "fs";
import * as path from "path";
import { config } from "../config";
import { safeJoin, walkFiles } from "../utils/fsx";
import { runSandboxed, RunResult } from "../security/sandbox";

/**
 * A persistent "computer" per agent: its own file system root, terminal, and
 * (optionally) browser profile directory. Survives restarts, so long-running
 * work and browser sessions continue where they left off.
 */
export class AgentWorkspace {
  readonly root: string;
  readonly browserProfileDir: string;
  private history: { command: string; code: number | null; at: string }[] = [];

  constructor(public readonly agentName: string) {
    this.root = path.join(config.workspaceRoot, agentName.replace(/[^\w.-]/g, "_"));
    this.browserProfileDir = path.join(this.root, ".browser-profile");
    fs.mkdirSync(this.root, { recursive: true });
  }

  resolve(rel: string) {
    return safeJoin(this.root, rel);
  }

  read(rel: string): string {
    return fs.readFileSync(this.resolve(rel), "utf-8");
  }

  write(rel: string, content: string) {
    const p = this.resolve(rel);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, content, "utf-8");
  }

  /** Replace an exact snippet in a file (modify in place). */
  modify(rel: string, find: string, replace: string): boolean {
    const content = this.read(rel);
    if (!content.includes(find)) return false;
    this.write(rel, content.replace(find, replace));
    return true;
  }

  delete(rel: string) {
    fs.rmSync(this.resolve(rel), { recursive: true, force: true });
  }

  list(rel = "."): string[] {
    const base = this.resolve(rel);
    return walkFiles(base, { ignore: /(^|[\\/])(node_modules|\.git|\.browser-profile)([\\/]|$)/ }).map((f) => path.relative(this.root, f));
  }

  async exec(command: string, timeoutMs?: number): Promise<RunResult> {
    const r = await runSandboxed(command, { cwd: this.root, timeoutMs });
    this.history.push({ command, code: r.code, at: new Date().toISOString() });
    fs.appendFileSync(path.join(this.root, ".terminal_history"), `${new Date().toISOString()}\t${r.code}\t${command}\n`);
    return r;
  }

  terminalHistory() {
    return this.history;
  }
}

const cache = new Map<string, AgentWorkspace>();
export function workspaceFor(agent: string): AgentWorkspace {
  if (!cache.has(agent)) cache.set(agent, new AgentWorkspace(agent));
  return cache.get(agent)!;
}
