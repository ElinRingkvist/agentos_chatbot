import { config } from "../config";
import { Logger } from "../utils/logger";

export interface ChatMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  name?: string;
  tool_call_id?: string;
}

export interface ToolSpec {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface ChatResult {
  content: string;
  toolCalls: ToolCall[];
}

export interface LLMProvider {
  readonly name: string;
  chat(messages: ChatMessage[], opts?: { tools?: ToolSpec[]; temperature?: number; maxTokens?: number; model?: string }): Promise<ChatResult>;
}

/**
 * Works with any OpenAI-compatible Chat Completions endpoint: Ollama, llama.cpp
 * server, LM Studio, vLLM, the Hugging Face router, OpenAI, OpenRouter, ...
 */
export class OpenAICompatibleProvider implements LLMProvider {
  constructor(
    public readonly name: string,
    private baseUrl: string,
    private apiKey: string,
    private model: string,
  ) {}

  async chat(messages: ChatMessage[], opts: { tools?: ToolSpec[]; temperature?: number; maxTokens?: number; model?: string } = {}): Promise<ChatResult> {
    const body: Record<string, unknown> = {
      model: opts.model ?? this.model,
      messages,
      temperature: opts.temperature ?? 0.2,
      max_tokens: opts.maxTokens ?? 2048,
    };
    if (opts.tools?.length) {
      body.tools = opts.tools.map((t) => ({ type: "function", function: t }));
      body.tool_choice = "auto";
    }
    const res = await fetch(`${this.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(config.llm.timeoutMs),
    });
    if (!res.ok) throw new Error(`${this.name} LLM error ${res.status}: ${(await res.text()).slice(0, 500)}`);
    const json: any = await res.json();
    const msg = json.choices?.[0]?.message ?? {};
    const toolCalls: ToolCall[] = (msg.tool_calls ?? []).map((tc: any) => ({
      id: tc.id,
      name: tc.function?.name,
      arguments: safeParse(tc.function?.arguments),
    }));
    return { content: msg.content ?? "", toolCalls };
  }
}

/** Deterministic provider used when no model is reachable, so the OS still runs offline and in CI. */
export class OfflineProvider implements LLMProvider {
  readonly name = "offline";
  async chat(messages: ChatMessage[]): Promise<ChatResult> {
    const last = [...messages].reverse().find((m) => m.role === "user")?.content ?? "";
    return { content: `[offline model] ${last.slice(0, 400)}`, toolCalls: [] };
  }
}

function safeParse(s: unknown): Record<string, unknown> {
  if (typeof s !== "string") return (s as Record<string, unknown>) ?? {};
  try {
    return JSON.parse(s);
  } catch {
    return { raw: s };
  }
}

/** Falls back to the offline provider when the primary one is unreachable. */
export class ResilientProvider implements LLMProvider {
  readonly name: string;
  private warned = false;
  constructor(private primary: LLMProvider, private fallback: LLMProvider = new OfflineProvider()) {
    this.name = primary.name;
  }
  async chat(messages: ChatMessage[], opts?: Parameters<LLMProvider["chat"]>[1]): Promise<ChatResult> {
    try {
      return await this.primary.chat(messages, opts);
    } catch (err) {
      if (!this.warned) {
        Logger.warn("LLM", `${this.primary.name} unavailable (${(err as Error).message}). Using offline fallback.`);
        this.warned = true;
      }
      return this.fallback.chat(messages, opts);
    }
  }
}

let shared: LLMProvider | null = null;

export function createProvider(): LLMProvider {
  const { provider, baseUrl, apiKey, model, hfToken, hfModel } = config.llm;
  if (provider === "offline") return new OfflineProvider();
  if (provider === "huggingface") {
    return new ResilientProvider(new OpenAICompatibleProvider("huggingface", "https://router.huggingface.co/v1", hfToken, hfModel));
  }
  return new ResilientProvider(new OpenAICompatibleProvider("openai-compatible", baseUrl, apiKey, model));
}

export function getLLM(): LLMProvider {
  if (!shared) shared = createProvider();
  return shared;
}

export function setLLM(p: LLMProvider) {
  shared = p;
}

/** Convenience: single prompt -> text. */
export async function complete(prompt: string, system = "You are a precise, helpful assistant."): Promise<string> {
  const r = await getLLM().chat([
    { role: "system", content: system },
    { role: "user", content: prompt },
  ]);
  return r.content;
}

/** Ask the model for JSON and parse it, tolerating ```json fences. */
export async function completeJson<T>(prompt: string, fallback: T, system?: string): Promise<T> {
  const text = await complete(`${prompt}\n\nRespond with JSON only.`, system);
  const m = text.match(/```(?:json)?\s*([\s\S]*?)```/) ?? text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
  try {
    return JSON.parse(m ? m[1] : text) as T;
  } catch {
    return fallback;
  }
}
