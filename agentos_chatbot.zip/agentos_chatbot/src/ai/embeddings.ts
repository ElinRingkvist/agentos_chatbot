import * as crypto from "crypto";

/**
 * Offline, dependency-free embedding: feature-hashed bag of words + character
 * trigrams + camelCase/snake_case sub-tokens, L2 normalised. Good enough for
 * code and chat retrieval without sending anything off the machine. Swap in
 * HuggingFaceConnector.embed() for neural embeddings.
 */
export const EMBED_DIM = 512;

export function tokenize(text: string): string[] {
  const words = text
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/[_\-./\\]/g, " ")
    .toLowerCase()
    .match(/[\p{L}\p{N}]+/gu);
  return words ?? [];
}

function bucket(token: string): [number, number] {
  const h = crypto.createHash("md5").update(token).digest();
  return [h.readUInt32LE(0) % EMBED_DIM, h[4] & 1 ? 1 : -1];
}

export function embed(text: string): Float32Array {
  const v = new Float32Array(EMBED_DIM);
  const tokens = tokenize(text);
  for (const t of tokens) {
    const [i, s] = bucket(`w:${t}`);
    v[i] += s;
    for (let k = 0; k + 3 <= t.length; k++) {
      const [j, s2] = bucket(`c:${t.slice(k, k + 3)}`);
      v[j] += s2 * 0.3;
    }
  }
  let norm = 0;
  for (let i = 0; i < EMBED_DIM; i++) norm += v[i] * v[i];
  norm = Math.sqrt(norm) || 1;
  for (let i = 0; i < EMBED_DIM; i++) v[i] /= norm;
  return v;
}

export function cosine(a: ArrayLike<number>, b: ArrayLike<number>): number {
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return dot;
}

export interface VectorRecord<M> {
  id: string;
  vector: number[];
  meta: M;
}

/** Tiny in-memory vector store with JSON persistence helpers. */
export class VectorStore<M> {
  records: VectorRecord<M>[] = [];
  add(id: string, text: string, meta: M) {
    this.records.push({ id, vector: Array.from(embed(text)), meta });
  }
  removeWhere(pred: (m: M) => boolean) {
    this.records = this.records.filter((r) => !pred(r.meta));
  }
  query(text: string, k = 8): { id: string; score: number; meta: M }[] {
    const q = embed(text);
    return this.records
      .map((r) => ({ id: r.id, score: cosine(q, r.vector), meta: r.meta }))
      .sort((a, b) => b.score - a.score)
      .slice(0, k);
  }
}
