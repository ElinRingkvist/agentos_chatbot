import { Logger } from "../utils/logger";
import { config } from "../config";
import { getLLM, OpenAICompatibleProvider, ResilientProvider } from "./llm";

/**
 * Hugging Face connector.
 * - localMode=true  -> uses the configured local OpenAI-compatible server (e.g. Ollama / llama.cpp running a GGUF build of the model)
 * - localMode=false -> uses the Hugging Face Inference router (needs HF_TOKEN)
 * Also exposes HF task endpoints used elsewhere (speech-to-text, image generation, embeddings).
 */
export class HuggingFaceConnector {
  private modelName: string;
  constructor(modelName: string = config.llm.hfModel) {
    this.modelName = modelName;
  }

  public async runInference(prompt: string, localMode: boolean = !config.llm.hfToken): Promise<string> {
    Logger.info("HuggingFace", `Running model [${this.modelName}] (${localMode ? "Local GGUF/ONNX Mode" : "HuggingFace Hub API"})...`);
    const provider = localMode
      ? getLLM()
      : new ResilientProvider(new OpenAICompatibleProvider("huggingface", "https://router.huggingface.co/v1", config.llm.hfToken, this.modelName));
    const res = await provider.chat([{ role: "user", content: prompt }]);
    Logger.success("HuggingFace", "Inference execution complete.");
    return res.content;
  }

  private async hfTask(model: string, body: BodyInit, contentType: string): Promise<Response> {
    if (!config.llm.hfToken) throw new Error("HF_TOKEN is required for Hugging Face task endpoints.");
    const res = await fetch(`https://router.huggingface.co/hf-inference/models/${model}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${config.llm.hfToken}`, "Content-Type": contentType },
      body,
    });
    if (!res.ok) throw new Error(`HF ${model} error ${res.status}: ${(await res.text()).slice(0, 300)}`);
    return res;
  }

  /** Speech-to-text (Whisper). */
  public async transcribe(audio: Buffer, model = "openai/whisper-large-v3-turbo", mime = "audio/wav"): Promise<string> {
    const res = await this.hfTask(model, new Uint8Array(audio), mime);
    const json: any = await res.json();
    return json.text ?? "";
  }

  /** Text-to-image. Returns PNG/JPEG bytes. */
  public async generateImage(prompt: string, model = "black-forest-labs/FLUX.1-schnell"): Promise<Buffer> {
    const res = await this.hfTask(model, JSON.stringify({ inputs: prompt }), "application/json");
    return Buffer.from(await res.arrayBuffer());
  }

  /** Sentence embeddings. */
  public async embed(texts: string[], model = "sentence-transformers/all-MiniLM-L6-v2"): Promise<number[][]> {
    const res = await this.hfTask(model, JSON.stringify({ inputs: texts }), "application/json");
    return (await res.json()) as number[][];
  }
}
