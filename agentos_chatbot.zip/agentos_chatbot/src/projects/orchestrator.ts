import { completeJson } from "../ai/llm";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";
import type { TaskQueue } from "../tasks/taskQueue";
import { notifier } from "../notifications/notifier";
import { bus } from "../events/bus";

export interface Milestone {
  id: string;
  title: string;
  dependsOn: string[];
  agent: string;
  workItems: string[];
  taskIds: string[];
  status: "blocked" | "ready" | "running" | "done" | "failed";
}

export interface Project {
  id: string;
  name: string;
  goal: string;
  milestones: Milestone[];
  createdAt: string;
  status: "active" | "done" | "paused";
}

/**
 * Projects: orchestrates large initiatives (feature rollouts, migrations)
 * as a dependency graph of milestones, each fanned out to many subagent
 * background tasks. Runs for days/weeks via the persistent task queue;
 * unblocks milestones automatically as dependencies finish.
 */
export class ProjectOrchestrator {
  private file = dataPath("projects.json");

  constructor(private queue: TaskQueue, private agentNames: () => string[]) {
    bus.on("task.completed", () => void this.tick());
    bus.on("task.failed", () => void this.tick());
  }

  list(): Project[] {
    return readJson<Project[]>(this.file, []);
  }
  private save(p: Project[]) {
    writeJson(this.file, p);
  }

  async create(name: string, goal: string): Promise<Project> {
    const agents = this.agentNames();
    const plan = await completeJson<{ milestones: { title: string; dependsOn?: number[]; agent?: string; workItems: string[] }[] }>(
      `Plan this initiative as milestones with dependencies (by index) and parallelisable work items.\nGoal: ${goal}\nAvailable agents: ${agents.join(", ")}\n` +
        `Return {"milestones":[{"title":"...","dependsOn":[0],"agent":"<name>","workItems":["..."]}]}`,
      { milestones: [{ title: goal, workItems: [goal] }] },
    );
    const ids = plan.milestones.map(() => uid("ms"));
    const project: Project = {
      id: uid("proj"),
      name,
      goal,
      createdAt: new Date().toISOString(),
      status: "active",
      milestones: plan.milestones.map((m, i) => ({
        id: ids[i],
        title: m.title,
        dependsOn: (m.dependsOn ?? []).filter((d) => d >= 0 && d < i).map((d) => ids[d]),
        agent: m.agent && agents.includes(m.agent) ? m.agent : agents[0],
        workItems: m.workItems?.length ? m.workItems : [m.title],
        taskIds: [],
        status: "blocked",
      })),
    };
    const all = this.list();
    all.push(project);
    this.save(all);
    Logger.success("Projects", `Created project "${name}" with ${project.milestones.length} milestones.`);
    await this.tick();
    return project;
  }

  pause(id: string, paused = true) {
    this.save(this.list().map((p) => (p.id === id ? { ...p, status: paused ? "paused" : "active" } : p)));
  }

  private ticking: Promise<void> = Promise.resolve();

  /** Advance every active project (serialised so concurrent events never race). */
  tick(): Promise<void> {
    this.ticking = this.ticking.catch(() => undefined).then(() => this.doTick());
    return this.ticking;
  }

  private async doTick() {
    const all = this.list();
    for (const p of all) {
      if (p.status !== "active") continue;
      for (const m of p.milestones) {
        if (m.status === "running") {
          const tasks = m.taskIds.map((id) => this.queue.get(id));
          if (tasks.some((t) => t?.status === "failed")) m.status = "failed";
          else if (tasks.every((t) => t && (t.status === "done" || t.status === "waiting_review"))) m.status = "done";
        }
      }
      for (const m of p.milestones) {
        if (m.status !== "blocked" && m.status !== "ready") continue;
        const depsDone = m.dependsOn.every((d) => p.milestones.find((x) => x.id === d)?.status === "done");
        if (!depsDone) continue;
        m.status = "running";
        for (const item of m.workItems) {
          const t = await this.queue.enqueue({ title: `${p.name} › ${m.title} › ${item}`.slice(0, 160), goal: `${p.goal}\nMilestone: ${m.title}\nWork item: ${item}`, agent: m.agent, notifyOnDone: false });
          m.taskIds.push(t.id);
        }
      }
      if (p.milestones.every((m) => m.status === "done")) {
        p.status = "done";
        await notifier.send(`Project complete: ${p.name}`, `${p.milestones.length} milestones finished.`, "high", "loud");
      }
    }
    this.save(all);
  }
}
