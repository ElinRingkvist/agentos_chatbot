import * as fs from "fs";
import * as path from "path";
import { complete, completeJson } from "../ai/llm";
import { optionalRequire } from "../utils/fsx";

/**
 * Document & slide generation without heavy dependencies:
 * - PDF: minimal PDF 1.4 writer (Helvetica, word-wrapping, multi-page)
 * - Slides: self-contained HTML deck (arrow-key navigation, print to PDF)
 * - Spreadsheets: CSV and Excel-compatible SpreadsheetML (.xls XML)
 * - Analysis: text extraction for txt/md/csv/json/html (+ pdf via optional pdf-parse)
 */

const pdfEsc = (s: string) => s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/[^\x20-\x7E]/g, "?");

function wrap(text: string, maxChars: number): string[] {
  const out: string[] = [];
  for (const para of text.split("\n")) {
    if (!para.trim()) {
      out.push("");
      continue;
    }
    let line = "";
    for (const w of para.split(/\s+/)) {
      if ((line + " " + w).trim().length > maxChars) {
        out.push(line);
        line = w;
      } else line = (line + " " + w).trim();
    }
    out.push(line);
  }
  return out;
}

export function writePdf(file: string, title: string, body: string) {
  const fontSize = 11;
  const leading = 15;
  const linesPerPage = 48;
  const lines = wrap(body, 92);
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += linesPerPage) pages.push(lines.slice(i, i + linesPerPage));
  if (!pages.length) pages.push([]);

  const objects: string[] = [];
  const add = (s: string) => (objects.push(s), objects.length);
  const catalog = add("");
  const pagesObj = add("");
  const font = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  const fontBold = add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  const pageIds: number[] = [];
  pages.forEach((pl, idx) => {
    let stream = "BT\n";
    let y = 800;
    if (idx === 0) {
      stream += `/F2 18 Tf 50 ${y} Td (${pdfEsc(title)}) Tj\n`;
      y -= 30;
      stream += `/F1 ${fontSize} Tf 0 -30 Td\n`;
    } else stream += `/F1 ${fontSize} Tf 50 ${y} Td\n`;
    for (const l of pl) stream += `(${pdfEsc(l)}) Tj 0 -${leading} Td\n`;
    stream += "ET";
    const content = add(`<< /Length ${Buffer.byteLength(stream)} >>\nstream\n${stream}\nendstream`);
    pageIds.push(add(`<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 595 842] /Contents ${content} 0 R /Resources << /Font << /F1 ${font} 0 R /F2 ${fontBold} 0 R >> >> >>`));
  });
  objects[catalog - 1] = `<< /Type /Catalog /Pages ${pagesObj} 0 R >>`;
  objects[pagesObj - 1] = `<< /Type /Pages /Kids [${pageIds.map((p) => `${p} 0 R`).join(" ")}] /Count ${pageIds.length} >>`;

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((o, i) => {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.map((o) => `${String(o).padStart(10, "0")} 00000 n `).join("\n")}\n`;
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root ${catalog} 0 R /Info << /Title (${pdfEsc(title)}) /Producer (Agentic OS) >> >>\nstartxref\n${xref}\n%%EOF`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, pdf, "latin1");
  return file;
}

export interface Slide {
  title: string;
  bullets: string[];
  notes?: string;
}

export function writeSlidesHtml(file: string, deckTitle: string, slides: Slide[], theme: { bg?: string; fg?: string; accent?: string } = {}) {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const bg = theme.bg ?? "#0f1115";
  const fg = theme.fg ?? "#f4f1ea";
  const ac = theme.accent ?? "#e8b04b";
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(deckTitle)}</title><style>
body{margin:0;background:${bg};color:${fg};font-family:system-ui,sans-serif}section{display:none;height:100vh;padding:8vh 10vw;box-sizing:border-box}
section.on{display:block}h1{color:${ac};font-size:3.2vw}li{font-size:1.8vw;margin:.6em 0}@media print{section{display:block;page-break-after:always}}
</style></head><body>${slides
    .map((s, i) => `<section class="${i === 0 ? "on" : ""}"><h1>${esc(s.title)}</h1><ul>${s.bullets.map((b) => `<li>${esc(b)}</li>`).join("")}</ul>${s.notes ? `<aside hidden>${esc(s.notes)}</aside>` : ""}</section>`)
    .join("")}<script>let i=0;const s=document.querySelectorAll('section');document.onkeydown=e=>{if(['ArrowRight',' ','PageDown'].includes(e.key))i=Math.min(i+1,s.length-1);if(['ArrowLeft','PageUp'].includes(e.key))i=Math.max(i-1,0);s.forEach((x,j)=>x.classList.toggle('on',j===i))}</script></body></html>`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, html);
  return file;
}

export function writeCsv(file: string, rows: (string | number)[][]) {
  const cell = (v: string | number) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, rows.map((r) => r.map(cell).join(",")).join("\n"));
  return file;
}

/** Excel-compatible spreadsheet (SpreadsheetML 2003 XML). Opens in Excel, Numbers, LibreOffice. */
export function writeSpreadsheet(file: string, sheets: Record<string, (string | number)[][]>) {
  const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  const xml = `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">${Object.entries(sheets)
    .map(
      ([name, rows]) =>
        `<Worksheet ss:Name="${esc(name).slice(0, 31)}"><Table>${rows
          .map((r) => `<Row>${r.map((v) => `<Cell><Data ss:Type="${typeof v === "number" ? "Number" : "String"}">${esc(String(v))}</Data></Cell>`).join("")}</Row>`)
          .join("")}</Table></Worksheet>`,
    )
    .join("")}</Workbook>`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, xml);
  return file;
}

export async function extractText(file: string): Promise<string> {
  const ext = path.extname(file).toLowerCase();
  if (ext === ".pdf") {
    const pdfParse = optionalRequire<any>("pdf-parse");
    return (await pdfParse(fs.readFileSync(file))).text;
  }
  const raw = fs.readFileSync(file, "utf-8");
  if (ext === ".html" || ext === ".htm") return raw.replace(/<(script|style)[\s\S]*?<\/\1>/gi, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ");
  return raw;
}

export async function analyzeDocument(file: string, question = "Summarise the key points, numbers and action items.") {
  const text = await extractText(file);
  return complete(`${question}\n\nDocument (${path.basename(file)}):\n${text.slice(0, 60_000)}`);
}

/** LLM writes the content, then it is rendered into the requested format. */
export async function generateDocument(kind: "pdf" | "slides" | "spreadsheet" | "markdown", brief: string, outFile: string) {
  if (kind === "slides") {
    const deck = await completeJson<{ title: string; slides: Slide[] }>(`Create a slide deck for: ${brief}\nReturn {"title":"","slides":[{"title":"","bullets":[""],"notes":""}]}`, { title: brief, slides: [{ title: brief, bullets: [] }] });
    return writeSlidesHtml(outFile, deck.title, deck.slides);
  }
  if (kind === "spreadsheet") {
    const data = await completeJson<{ sheets: Record<string, (string | number)[][]> }>(`Create spreadsheet data for: ${brief}\nReturn {"sheets":{"Sheet1":[["Header"],[1]]}}`, { sheets: { Sheet1: [[brief]] } });
    return writeSpreadsheet(outFile, data.sheets);
  }
  const text = await complete(`Write a well-structured document: ${brief}`);
  if (kind === "markdown") {
    fs.writeFileSync(outFile, text);
    return outFile;
  }
  return writePdf(outFile, brief.slice(0, 80), text.replace(/[#*_`]/g, ""));
}
