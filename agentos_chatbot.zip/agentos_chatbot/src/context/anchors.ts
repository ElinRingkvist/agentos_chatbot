import * as fs from "fs";
import * as path from "path";
import { runSandboxed } from "../security/sandbox";
import { walkFiles } from "../utils/fsx";
import { WebSearchEngine } from "../search/webSearch";

export type Anchor =
  | { type: "file"; path: string; startLine?: number; endLine?: number }
  | { type: "folder"; path: string; maxFiles?: number }
  | { type: "git-diff"; repo: string; ref?: string; staged?: boolean }
  | { type: "url"; url: string }
  | { type: "web-search"; query: string; limit?: number }
  | { type: "text"; label: string; content: string };

/**
 * Context anchors: resolve files, folders, git diffs, documentation links
 * and web search results into a single prompt block (`@file`, `@folder`,
 * `@git`, `@url`, `@web` mentions are parsed by `parseMentions`).
 */
export async function resolveAnchor(a: Anchor, maxChars = 40_000): Promise<string> {
  switch (a.type) {
    case "file": {
      const lines = fs.readFileSync(a.path, "utf-8").split("\n");
      const s = (a.startLine ?? 1) - 1;
      const e = a.endLine ?? lines.length;
      return `<file path="${a.path}" lines="${s + 1}-${e}">\n${lines.slice(s, e).join("\n").slice(0, maxChars)}\n</file>`;
    }
    case "folder": {
      const files = walkFiles(a.path, { maxFiles: a.maxFiles ?? 200 });
      const tree = files.map((f) => path.relative(a.path, f)).join("\n");
      return `<folder path="${a.path}">\n${tree.slice(0, maxChars)}\n</folder>`;
    }
    case "git-diff": {
      const cmd = a.staged ? "git diff --staged" : `git diff ${a.ref ?? "HEAD"}`;
      const r = await runSandboxed(cmd, { cwd: a.repo, timeoutMs: 20_000 });
      return `<git-diff repo="${a.repo}" ref="${a.ref ?? (a.staged ? "staged" : "HEAD")}">\n${r.stdout.slice(0, maxChars)}\n</git-diff>`;
    }
    case "url":
      return `<doc url="${a.url}">\n${await WebSearchEngine.fetchText(a.url, maxChars)}\n</doc>`;
    case "web-search": {
      const results = await WebSearchEngine.search(a.query, "Google", a.limit ?? 5);
      return `<web-search query="${a.query}">\n${results.map((r, i) => `[${i + 1}] ${r.title} — ${r.url}\n${r.snippet}`).join("\n")}\n</web-search>`;
    }
    case "text":
      return `<context label="${a.label}">\n${a.content.slice(0, maxChars)}\n</context>`;
  }
}

export async function buildAnchoredPrompt(prompt: string, anchors: Anchor[]): Promise<string> {
  const blocks = await Promise.all(anchors.map((a) => resolveAnchor(a).catch((e) => `<error anchor="${a.type}">${(e as Error).message}</error>`)));
  return `${blocks.join("\n\n")}\n\n${prompt}`;
}

/** Parse inline mentions like `@file:src/a.ts#10-40 @folder:src @git @url:https://... @web:"query"`. */
export function parseMentions(prompt: string, cwd = process.cwd()): { prompt: string; anchors: Anchor[] } {
  const anchors: Anchor[] = [];
  const cleaned = prompt.replace(/@(file|folder|git|url|web):?("([^"]+)"|(\S+))?/g, (_m, kind: string, _q, quoted?: string, bare?: string) => {
    const val = quoted ?? bare ?? "";
    if (kind === "file") {
      const [p, range] = val.split("#");
      const [s, e] = (range ?? "").split("-").map(Number);
      anchors.push({ type: "file", path: path.resolve(cwd, p), startLine: s || undefined, endLine: e || undefined });
    } else if (kind === "folder") anchors.push({ type: "folder", path: path.resolve(cwd, val || ".") });
    else if (kind === "git") anchors.push({ type: "git-diff", repo: cwd, ref: val || undefined });
    else if (kind === "url") anchors.push({ type: "url", url: val });
    else if (kind === "web") anchors.push({ type: "web-search", query: val });
    return "";
  });
  return { prompt: cleaned.trim(), anchors };
}
