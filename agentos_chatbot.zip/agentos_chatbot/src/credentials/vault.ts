import * as crypto from "crypto";
import * as fs from "fs";
import { config } from "../config";
import { dataPath, readJson, writeJson } from "../utils/fsx";

export interface Credential {
  site: string;
  username: string;
  password: string;
  email?: string;
  totpSecret?: string;
  notes?: string;
  updatedAt: string;
}

interface Sealed {
  iv: string;
  tag: string;
  data: string;
}

/**
 * Encrypted credential vault (AES-256-GCM, key derived with scrypt).
 * The master key comes from AGENTOS_VAULT_KEY or a key file created with
 * 0600 permissions on first use. Plaintext credentials never touch disk.
 */
export class CredentialVault {
  private file = dataPath("vault", "vault.json");
  private keyFile = dataPath("vault", ".master.key");
  private saltFile = dataPath("vault", ".salt");
  private key: Buffer | null = null;

  private getKey(): Buffer {
    if (this.key) return this.key;
    let master = config.vault.masterKey;
    if (!master) {
      if (!fs.existsSync(this.keyFile)) fs.writeFileSync(this.keyFile, crypto.randomBytes(32).toString("hex"), { mode: 0o600 });
      master = fs.readFileSync(this.keyFile, "utf-8").trim();
    }
    if (!fs.existsSync(this.saltFile)) fs.writeFileSync(this.saltFile, crypto.randomBytes(16).toString("hex"), { mode: 0o600 });
    const salt = Buffer.from(fs.readFileSync(this.saltFile, "utf-8").trim(), "hex");
    this.key = crypto.scryptSync(master, salt, 32);
    return this.key;
  }

  private seal(obj: unknown): Sealed {
    const iv = crypto.randomBytes(12);
    const c = crypto.createCipheriv("aes-256-gcm", this.getKey(), iv);
    const data = Buffer.concat([c.update(JSON.stringify(obj), "utf-8"), c.final()]);
    return { iv: iv.toString("base64"), tag: c.getAuthTag().toString("base64"), data: data.toString("base64") };
  }

  private open<T>(s: Sealed): T {
    const d = crypto.createDecipheriv("aes-256-gcm", this.getKey(), Buffer.from(s.iv, "base64"));
    d.setAuthTag(Buffer.from(s.tag, "base64"));
    return JSON.parse(Buffer.concat([d.update(Buffer.from(s.data, "base64")), d.final()]).toString("utf-8"));
  }

  private readAll(): Record<string, Credential> {
    const sealed = readJson<Sealed | null>(this.file, null);
    return sealed ? this.open<Record<string, Credential>>(sealed) : {};
  }

  private writeAll(all: Record<string, Credential>) {
    writeJson(this.file, this.seal(all));
    try {
      fs.chmodSync(this.file, 0o600);
    } catch {
      /* windows */
    }
  }

  set(c: Omit<Credential, "updatedAt">) {
    const all = this.readAll();
    all[c.site] = { ...c, updatedAt: new Date().toISOString() };
    this.writeAll(all);
  }

  get(site: string): Credential | undefined {
    return this.readAll()[site];
  }

  /** Sites only — never exposes secrets in listings. */
  list(): { site: string; username: string; updatedAt: string }[] {
    return Object.values(this.readAll()).map(({ site, username, updatedAt }) => ({ site, username, updatedAt }));
  }

  remove(site: string) {
    const all = this.readAll();
    delete all[site];
    this.writeAll(all);
  }

  /** RFC 6238 TOTP code for 2FA-protected logins. */
  static totp(base32Secret: string, now = Date.now(), step = 30, digits = 6): string {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let bits = "";
    for (const ch of base32Secret.replace(/=+$/, "").toUpperCase().replace(/\s/g, "")) {
      const v = alphabet.indexOf(ch);
      if (v < 0) continue;
      bits += v.toString(2).padStart(5, "0");
    }
    const bytes = Buffer.from(bits.match(/.{8}/g)!.map((b) => parseInt(b, 2)));
    const counter = Buffer.alloc(8);
    counter.writeBigUInt64BE(BigInt(Math.floor(now / 1000 / step)));
    const h = crypto.createHmac("sha1", bytes).update(counter).digest();
    const off = h[h.length - 1] & 0xf;
    const code = (h.readUInt32BE(off) & 0x7fffffff) % 10 ** digits;
    return code.toString().padStart(digits, "0");
  }
}

export const vault = new CredentialVault();
