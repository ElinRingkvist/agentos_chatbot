import { config } from "../config";
import { optionalRequire } from "../utils/fsx";
import { requireConfig } from "../utils/http";
import { bus } from "../events/bus";

export interface EmailMessage {
  id: string;
  from: string;
  to: string;
  subject: string;
  date: string;
  text: string;
  unread: boolean;
}

/**
 * Dedicated assistant email address. The agent's own inbox (any IMAP/SMTP
 * provider) used to sign up for accounts, read verification codes and
 * message vendors. Requires optional deps: `npm i imapflow nodemailer mailparser`.
 */
export class AssistantEmail {
  private get imapCfg() {
    const e = config.email;
    requireConfig("Email (IMAP_HOST, EMAIL_USER, EMAIL_PASSWORD)", e.imapHost, e.user, e.password);
    return { host: e.imapHost, port: e.imapPort, secure: true, auth: { user: e.user, pass: e.password }, logger: false };
  }

  get address() {
    return config.email.address || config.email.user;
  }

  /** Plus-addressing gives each sign-up its own alias: assistant+github@domain. */
  aliasFor(service: string) {
    const [local, domain] = this.address.split("@");
    return `${local}+${service.toLowerCase().replace(/[^a-z0-9]/g, "")}@${domain}`;
  }

  async fetch(opts: { unreadOnly?: boolean; since?: Date; limit?: number; mailbox?: string } = {}): Promise<EmailMessage[]> {
    const { ImapFlow } = optionalRequire<any>("imapflow");
    const { simpleParser } = optionalRequire<any>("mailparser");
    const client = new ImapFlow(this.imapCfg);
    await client.connect();
    const out: EmailMessage[] = [];
    const lock = await client.getMailboxLock(opts.mailbox ?? "INBOX");
    try {
      const query: Record<string, unknown> = {};
      if (opts.unreadOnly) query.seen = false;
      if (opts.since) query.since = opts.since;
      const uids: number[] = (await client.search(Object.keys(query).length ? query : { all: true })) || [];
      for (const uid of uids.slice(-(opts.limit ?? 50))) {
        const msg = await client.fetchOne(uid, { source: true, flags: true });
        const parsed = await simpleParser(msg.source);
        out.push({
          id: String(uid),
          from: parsed.from?.text ?? "",
          to: parsed.to?.text ?? "",
          subject: parsed.subject ?? "",
          date: (parsed.date ?? new Date()).toISOString(),
          text: (parsed.text ?? "").slice(0, 20_000),
          unread: !msg.flags?.has("\\Seen"),
        });
      }
    } finally {
      lock.release();
      await client.logout();
    }
    return out.reverse();
  }

  async markRead(id: string) {
    const { ImapFlow } = optionalRequire<any>("imapflow");
    const client = new ImapFlow(this.imapCfg);
    await client.connect();
    const lock = await client.getMailboxLock("INBOX");
    try {
      await client.messageFlagsAdd(id, ["\\Seen"], { uid: true });
    } finally {
      lock.release();
      await client.logout();
    }
  }

  async send(to: string, subject: string, text: string, opts: { inReplyTo?: string; html?: string } = {}) {
    const e = config.email;
    requireConfig("SMTP (SMTP_HOST, EMAIL_USER, EMAIL_PASSWORD)", e.smtpHost, e.user, e.password);
    const nodemailer = optionalRequire<any>("nodemailer");
    const t = nodemailer.createTransport({ host: e.smtpHost, port: e.smtpPort, secure: e.smtpPort === 465, auth: { user: e.user, pass: e.password } });
    return t.sendMail({ from: this.address, to, subject, text, html: opts.html, inReplyTo: opts.inReplyTo });
  }

  /** Poll until a verification code / magic link arrives (e.g. after a sign-up). */
  async waitForVerification(opts: { fromContains?: string; timeoutMs?: number; pollMs?: number } = {}): Promise<{ code?: string; link?: string; message: EmailMessage } | null> {
    const deadline = Date.now() + (opts.timeoutMs ?? 5 * 60_000);
    const since = new Date(Date.now() - 60_000);
    while (Date.now() < deadline) {
      const msgs = await this.fetch({ unreadOnly: true, since, limit: 20 });
      for (const m of msgs) {
        if (opts.fromContains && !m.from.toLowerCase().includes(opts.fromContains.toLowerCase())) continue;
        const r = extractVerification(m.subject + "\n" + m.text);
        if (r.code || r.link) return { ...r, message: m };
      }
      await new Promise((r) => setTimeout(r, opts.pollMs ?? 10_000));
    }
    return null;
  }

  /** Inbox monitor: emits `trigger` events named "email.received" for routines. */
  watch(intervalMs = 120_000) {
    const seen = new Set<string>();
    const tick = async () => {
      try {
        for (const m of await this.fetch({ unreadOnly: true, limit: 25 })) {
          if (seen.has(m.id)) continue;
          seen.add(m.id);
          bus.emit("trigger", { name: "email.received", data: m });
        }
      } catch {
        /* not configured or offline */
      }
    };
    void tick();
    return setInterval(tick, intervalMs);
  }
}

export function extractVerification(text: string): { code?: string; link?: string } {
  const code = text.match(/(?:code|kod|código|verification|OTP|pin)[^0-9A-Z]{0,30}([0-9]{4,8}|[A-Z0-9]{6,8})\b/i)?.[1] ?? text.match(/\b(\d{6})\b/)?.[1];
  const link = text.match(/https?:\/\/\S*(verify|confirm|activate|magic|token)\S*/i)?.[0];
  return { code, link };
}

export const assistantEmail = new AssistantEmail();
