import { Logger } from "../utils/logger";
import { runSandboxed } from "../security/sandbox";
import { bus } from "../events/bus";

export interface MouseCoordinates {
  x: number;
  y: number;
}

/**
 * OpenMausBot: native GUI automation.
 * Linux: xdotool · macOS: cliclick (brew install cliclick) / osascript · Windows: PowerShell + user32.
 * Set MAUSBOT_DRY_RUN=1 to only log actions (CI / headless servers).
 * Every action is emitted as a `demo.action` event so the skill recorder can learn it.
 */
export class OpenMausBotConnector {
  static dryRun = process.env.MAUSBOT_DRY_RUN === "1";

  private static async sh(cmd: string) {
    const r = await runSandboxed(cmd, { cwd: process.cwd(), timeoutMs: 10_000, env: { DISPLAY: process.env.DISPLAY ?? ":0" } });
    if (r.code !== 0) throw new Error(r.stderr || `GUI command failed: ${cmd}`);
    return r.stdout;
  }

  private static q(s: string) {
    return `'${s.replace(/'/g, `'\\''`)}'`;
  }

  public static async moveAndClick(coords: MouseCoordinates, button: "left" | "right" = "left"): Promise<void> {
    Logger.info("MausBot", `GUI Action: moving cursor to (${coords.x}, ${coords.y}) and clicking [${button}]...`);
    bus.emit("demo.action", { kind: "gui.click", data: { ...coords, button } });
    if (this.dryRun) return Logger.success("MausBot", `[dry-run] click at (${coords.x}, ${coords.y}).`);
    const { x, y } = coords;
    const b = button === "left" ? 1 : 3;
    if (process.platform === "linux") await this.sh(`xdotool mousemove ${x} ${y} click ${b}`);
    else if (process.platform === "darwin") await this.sh(`cliclick ${button === "left" ? "c" : "rc"}:${x},${y}`);
    else if (process.platform === "win32") {
      const flags = button === "left" ? "0x0002,0x0004" : "0x0008,0x0010";
      const [down, up] = flags.split(",");
      await this.sh(
        `powershell -NoProfile -Command "Add-Type -Name U -Namespace W -MemberDefinition '[DllImport(\\"user32.dll\\")] public static extern bool SetCursorPos(int x,int y); [DllImport(\\"user32.dll\\")] public static extern void mouse_event(int f,int x,int y,int d,int e);'; [W.U]::SetCursorPos(${x},${y}); [W.U]::mouse_event(${down},0,0,0,0); [W.U]::mouse_event(${up},0,0,0,0)"`,
      );
    }
    Logger.success("MausBot", `Executed GUI click at (${x}, ${y}).`);
  }

  public static async typeText(text: string): Promise<void> {
    Logger.info("MausBot", `OS Keystrokes: "${text}"`);
    bus.emit("demo.action", { kind: "gui.type", data: { text } });
    if (this.dryRun) return Logger.success("MausBot", "[dry-run] keystrokes logged.");
    if (process.platform === "linux") await this.sh(`xdotool type --delay 20 ${this.q(text)}`);
    else if (process.platform === "darwin") await this.sh(`osascript -e ${this.q(`tell application "System Events" to keystroke "${text.replace(/"/g, '\\"')}"`)}`);
    else if (process.platform === "win32") await this.sh(`powershell -NoProfile -Command "(New-Object -ComObject WScript.Shell).SendKeys('${text.replace(/'/g, "''")}')"`);
    Logger.success("MausBot", "Keystrokes successfully sent to target active window.");
  }

  public static async pressKey(combo: string): Promise<void> {
    bus.emit("demo.action", { kind: "gui.key", data: { combo } });
    if (this.dryRun) return;
    if (process.platform === "linux") await this.sh(`xdotool key ${this.q(combo)}`);
    else if (process.platform === "darwin") await this.sh(`cliclick kp:${combo}`);
    else await this.sh(`powershell -NoProfile -Command "(New-Object -ComObject WScript.Shell).SendKeys('${combo}')"`);
  }

  /** Screenshot of the full screen to a PNG file. */
  public static async screenshot(file: string): Promise<string> {
    if (this.dryRun) return file;
    if (process.platform === "linux") await this.sh(`import -window root ${this.q(file)} || gnome-screenshot -f ${this.q(file)}`);
    else if (process.platform === "darwin") await this.sh(`screencapture -x ${this.q(file)}`);
    else
      await this.sh(
        `powershell -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $i=New-Object System.Drawing.Bitmap $b.Width,$b.Height; [System.Drawing.Graphics]::FromImage($i).CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size); $i.Save('${file}')"`,
      );
    return file;
  }
}
