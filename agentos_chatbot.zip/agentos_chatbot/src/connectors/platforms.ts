import { config } from "../config";
import { api, requireConfig } from "../utils/http";
import { runSandboxed } from "../security/sandbox";

/**
 * Native platform connectors: Google (Gmail, Drive), Microsoft (Outlook,
 * Teams, OneDrive via Graph) and Apple (macOS Messages, Mail, Reminders,
 * Notes via AppleScript). OAuth access tokens are provided via env/vault.
 */
export const Google = {
  async gmailList(query = "is:unread", max = 20) {
    requireConfig("GOOGLE_ACCESS_TOKEN", config.google.accessToken);
    const t = config.google.accessToken;
    const list: any = await api(`https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${max}&q=${encodeURIComponent(query)}`, { token: t });
    return Promise.all(
      (list.messages ?? []).map(async (m: any) => {
        const full: any = await api(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date`, { token: t });
        const h = (n: string) => full.payload?.headers?.find((x: any) => x.name === n)?.value ?? "";
        return { id: m.id, threadId: full.threadId, from: h("From"), subject: h("Subject"), date: h("Date"), snippet: full.snippet, unread: (full.labelIds ?? []).includes("UNREAD") };
      }),
    );
  },
  async gmailSend(to: string, subject: string, text: string, threadId?: string) {
    const raw = Buffer.from(`To: ${to}\r\nSubject: ${subject}\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\n${text}`).toString("base64url");
    return api("https://gmail.googleapis.com/gmail/v1/users/me/messages/send", { token: config.google.accessToken, body: { raw, threadId } });
  },
  async driveSearch(q: string) {
    return api(`https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(`fullText contains '${q.replace(/'/g, "\\'")}'`)}&fields=files(id,name,mimeType,webViewLink)`, { token: config.google.accessToken });
  },
};

export const Microsoft = {
  async outlookUnread(top = 20) {
    requireConfig("MS_GRAPH_ACCESS_TOKEN", config.microsoft.accessToken);
    const j: any = await api(`https://graph.microsoft.com/v1.0/me/mailFolders/inbox/messages?$filter=isRead eq false&$top=${top}&$select=id,subject,from,receivedDateTime,bodyPreview,importance`, { token: config.microsoft.accessToken });
    return (j.value ?? []).map((m: any) => ({ id: m.id, from: m.from?.emailAddress?.address, subject: m.subject, date: m.receivedDateTime, snippet: m.bodyPreview, important: m.importance === "high" }));
  },
  async outlookSend(to: string, subject: string, text: string) {
    return api("https://graph.microsoft.com/v1.0/me/sendMail", { token: config.microsoft.accessToken, body: { message: { subject, body: { contentType: "Text", content: text }, toRecipients: [{ emailAddress: { address: to } }] } } });
  },
  async teamsChats(top = 20) {
    return api(`https://graph.microsoft.com/v1.0/me/chats?$top=${top}&$expand=lastMessagePreview`, { token: config.microsoft.accessToken });
  },
  async teamsSend(chatId: string, text: string) {
    return api(`https://graph.microsoft.com/v1.0/chats/${chatId}/messages`, { token: config.microsoft.accessToken, body: { body: { content: text } } });
  },
};

function osa(script: string) {
  if (process.platform !== "darwin") throw new Error("Apple connector requires macOS");
  return runSandboxed(`osascript -e '${script.replace(/'/g, "'\\''")}'`, { cwd: process.cwd(), timeoutMs: 20_000, env: { HOME: process.env.HOME ?? "" } }).then((r) => {
    if (r.code !== 0) throw new Error(r.stderr);
    return r.stdout.trim();
  });
}
const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/"/g, '\\"');

export const Apple = {
  /** Send an iMessage/SMS through the Messages app. */
  sendMessage: (to: string, text: string) => osa(`tell application "Messages" to send "${esc(text)}" to buddy "${esc(to)}" of (service 1 whose service type is iMessage)`),
  addReminder: (title: string, list = "Reminders") => osa(`tell application "Reminders" to make new reminder at end of list "${esc(list)}" with properties {name:"${esc(title)}"}`),
  createNote: (title: string, body: string) => osa(`tell application "Notes" to make new note with properties {name:"${esc(title)}", body:"${esc(body)}"}`),
  unreadMailCount: () => osa(`tell application "Mail" to get unread count of inbox`),
  /** Recent Messages history via the local chat.db (requires Full Disk Access). */
  async recentMessages(limit = 50) {
    const db = `${process.env.HOME}/Library/Messages/chat.db`;
    const r = await runSandboxed(
      `sqlite3 -json "${db}" "SELECT m.ROWID id, h.id handle, m.text, datetime(m.date/1000000000 + 978307200,'unixepoch','localtime') date, m.is_from_me fromMe, m.is_read isRead FROM message m LEFT JOIN handle h ON m.handle_id=h.ROWID WHERE m.text IS NOT NULL ORDER BY m.date DESC LIMIT ${Number(limit)}"`,
      { cwd: process.cwd(), timeoutMs: 10_000, env: { HOME: process.env.HOME ?? "" } },
    );
    return r.code === 0 && r.stdout ? JSON.parse(r.stdout) : [];
  },
};
