import { config } from "../config";
import { api } from "../utils/http";

export interface Route {
  mode: string;
  durationMin: number;
  distanceKm: number;
  trafficDurationMin?: number;
  summary: string;
}

/**
 * Traffic & maps. Geocoding via OpenStreetMap Nominatim, routing via OSRM
 * (free) or Google Routes API with live traffic when GOOGLE_MAPS_API_KEY is set.
 */
export class MapsConnector {
  async geocode(query: string): Promise<{ lat: number; lon: number; name: string }> {
    const j: any[] = await api(`https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(query)}`, { headers: { "User-Agent": "agentic-os/1.0" } });
    if (!j.length) throw new Error(`Place not found: ${query}`);
    return { lat: Number(j[0].lat), lon: Number(j[0].lon), name: j[0].display_name };
  }

  async routes(from: string, to: string): Promise<Route[]> {
    const [a, b] = await Promise.all([this.geocode(from), this.geocode(to)]);
    if (config.maps.googleKey) {
      const modes = ["DRIVE", "TRANSIT", "BICYCLE", "WALK"];
      const res = await Promise.allSettled(
        modes.map((mode) =>
          api("https://routes.googleapis.com/directions/v2:computeRoutes", {
            headers: { "X-Goog-Api-Key": config.maps.googleKey, "X-Goog-FieldMask": "routes.duration,routes.staticDuration,routes.distanceMeters,routes.description" },
            body: {
              origin: { location: { latLng: { latitude: a.lat, longitude: a.lon } } },
              destination: { location: { latLng: { latitude: b.lat, longitude: b.lon } } },
              travelMode: mode,
              ...(mode === "DRIVE" ? { routingPreference: "TRAFFIC_AWARE" } : {}),
            },
          }).then((j: any) => ({ mode, r: j.routes?.[0] })),
        ),
      );
      return res
        .flatMap((x) => (x.status === "fulfilled" && x.value.r ? [x.value] : []))
        .map(({ mode, r }) => ({
          mode: mode.toLowerCase(),
          durationMin: Math.round(parseInt(r.staticDuration ?? r.duration, 10) / 60),
          trafficDurationMin: Math.round(parseInt(r.duration, 10) / 60),
          distanceKm: Math.round(r.distanceMeters / 100) / 10,
          summary: r.description ?? "",
        }))
        .sort((x, y) => (x.trafficDurationMin ?? x.durationMin) - (y.trafficDurationMin ?? y.durationMin));
    }
    const profiles = ["driving", "cycling", "foot"];
    const out: Route[] = [];
    for (const p of profiles) {
      try {
        const j: any = await api(`${config.maps.osrmUrl}/route/v1/${p}/${a.lon},${a.lat};${b.lon},${b.lat}?overview=false`);
        const r = j.routes?.[0];
        if (r) out.push({ mode: p, durationMin: Math.round(r.duration / 60), distanceKm: Math.round(r.distance / 100) / 10, summary: `${from} → ${to}` });
      } catch {
        /* the public demo OSRM may only support driving */
      }
    }
    return out.sort((x, y) => x.durationMin - y.durationMin);
  }

  /** When to leave to arrive on time, using the fastest route plus a buffer. */
  async departureAdvice(from: string, to: string, arriveBy: Date, bufferMin = 10) {
    const routes = await this.routes(from, to);
    if (!routes.length) throw new Error("No route found");
    const best = routes[0];
    const leave = new Date(arriveBy.getTime() - ((best.trafficDurationMin ?? best.durationMin) + bufferMin) * 60_000);
    return { best, alternatives: routes.slice(1), leaveAt: leave.toISOString() };
  }
}

export const maps = new MapsConnector();
