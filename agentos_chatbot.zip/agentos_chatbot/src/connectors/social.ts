import { config } from "../config";
import { api, requireConfig } from "../utils/http";

export interface SocialPost {
  id: string;
  network: "mastodon" | "bluesky" | "x";
  author: string;
  text: string;
  url?: string;
  ts: string;
}

/**
 * Social media: read timelines/notifications, post, comment/reply and DMs
 * on Mastodon, Bluesky and X. Posting goes through approval (social.post).
 */
export class SocialConnector {
  private bsky: { did: string; jwt: string } | null = null;

  private async bskyAuth() {
    if (this.bsky) return this.bsky;
    const s = config.social;
    requireConfig("Bluesky", s.blueskyHandle, s.blueskyAppPassword);
    const j: any = await api("https://bsky.social/xrpc/com.atproto.server.createSession", { body: { identifier: s.blueskyHandle, password: s.blueskyAppPassword } });
    this.bsky = { did: j.did, jwt: j.accessJwt };
    return this.bsky;
  }

  async notifications(network: SocialPost["network"]): Promise<SocialPost[]> {
    if (network === "mastodon") {
      const j: any[] = await api(`${config.social.mastodonUrl}/api/v1/notifications?limit=30`, { token: config.social.mastodonToken });
      return j.map((n) => ({ id: n.status?.id ?? n.id, network, author: n.account.acct, text: (n.status?.content ?? n.type).replace(/<[^>]+>/g, ""), url: n.status?.url, ts: n.created_at }));
    }
    if (network === "bluesky") {
      const a = await this.bskyAuth();
      const j: any = await api("https://bsky.social/xrpc/app.bsky.notification.listNotifications?limit=30", { token: a.jwt });
      return (j.notifications ?? []).map((n: any) => ({ id: n.uri, network, author: n.author.handle, text: n.record?.text ?? n.reason, ts: n.indexedAt }));
    }
    requireConfig("X_BEARER_TOKEN", config.social.xBearer);
    const me: any = await api("https://api.twitter.com/2/users/me", { token: config.social.xBearer });
    const j: any = await api(`https://api.twitter.com/2/users/${me.data.id}/mentions?tweet.fields=created_at,author_id`, { token: config.social.xBearer });
    return (j.data ?? []).map((t: any) => ({ id: t.id, network, author: t.author_id, text: t.text, ts: t.created_at, url: `https://x.com/i/status/${t.id}` }));
  }

  async post(network: SocialPost["network"], text: string, replyTo?: string) {
    if (network === "mastodon") return api(`${config.social.mastodonUrl}/api/v1/statuses`, { token: config.social.mastodonToken, body: { status: text, in_reply_to_id: replyTo } });
    if (network === "bluesky") {
      const a = await this.bskyAuth();
      const record: Record<string, unknown> = { $type: "app.bsky.feed.post", text, createdAt: new Date().toISOString() };
      if (replyTo) {
        const [uri, cid] = replyTo.split("|");
        record.reply = { root: { uri, cid }, parent: { uri, cid } };
      }
      return api("https://bsky.social/xrpc/com.atproto.repo.createRecord", { token: a.jwt, body: { repo: a.did, collection: "app.bsky.feed.post", record } });
    }
    return api("https://api.twitter.com/2/tweets", { token: config.social.xBearer, body: { text, ...(replyTo ? { reply: { in_reply_to_tweet_id: replyTo } } : {}) } });
  }

  async directMessage(network: "mastodon" | "x", to: string, text: string) {
    if (network === "mastodon") return api(`${config.social.mastodonUrl}/api/v1/statuses`, { token: config.social.mastodonToken, body: { status: `@${to} ${text}`, visibility: "direct" } });
    return api(`https://api.twitter.com/2/dm_conversations/with/${to}/messages`, { token: config.social.xBearer, body: { text } });
  }

  async edit(network: "mastodon", id: string, text: string) {
    return api(`${config.social.mastodonUrl}/api/v1/statuses/${id}`, { method: "PUT", token: config.social.mastodonToken, body: { status: text } });
  }
}

export const social = new SocialConnector();
