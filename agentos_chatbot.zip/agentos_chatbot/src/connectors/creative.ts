import { api, requireConfig } from "../utils/http";

const env = (k: string) => process.env[k] ?? "";

/**
 * Interactive media chat cards: create/read content on Notion, Figma, Canva
 * and hand off app ideas to Lovable. Each function returns a small "card"
 * object (title, url, preview) the companion clients can render.
 */
export interface MediaCard {
  kind: "notion" | "figma" | "canva" | "lovable" | "image" | "document";
  title: string;
  url?: string;
  preview?: string;
  data?: unknown;
}

export const Notion = {
  h: () => ({ token: env("NOTION_TOKEN"), headers: { "Notion-Version": "2022-06-28" } }),
  async search(query: string): Promise<MediaCard[]> {
    requireConfig("NOTION_TOKEN", env("NOTION_TOKEN"));
    const j: any = await api("https://api.notion.com/v1/search", { ...Notion.h(), body: { query, page_size: 10 } });
    return (j.results ?? []).map((r: any) => ({ kind: "notion", title: r.properties?.title?.title?.[0]?.plain_text ?? r.properties?.Name?.title?.[0]?.plain_text ?? r.id, url: r.url }));
  },
  async createPage(parentPageId: string, title: string, markdown: string): Promise<MediaCard> {
    const children = markdown
      .split("\n")
      .filter(Boolean)
      .slice(0, 100)
      .map((line) =>
        line.startsWith("# ")
          ? { object: "block", type: "heading_1", heading_1: { rich_text: [{ type: "text", text: { content: line.slice(2) } }] } }
          : line.startsWith("- ")
            ? { object: "block", type: "bulleted_list_item", bulleted_list_item: { rich_text: [{ type: "text", text: { content: line.slice(2) } }] } }
            : { object: "block", type: "paragraph", paragraph: { rich_text: [{ type: "text", text: { content: line.slice(0, 2000) } }] } },
      );
    const j: any = await api("https://api.notion.com/v1/pages", { ...Notion.h(), body: { parent: { page_id: parentPageId }, properties: { title: { title: [{ text: { content: title } }] } }, children } });
    return { kind: "notion", title, url: j.url };
  },
};

export const Figma = {
  async file(fileKey: string): Promise<MediaCard> {
    requireConfig("FIGMA_TOKEN", env("FIGMA_TOKEN"));
    const j: any = await api(`https://api.figma.com/v1/files/${fileKey}?depth=2`, { headers: { "X-Figma-Token": env("FIGMA_TOKEN") } });
    return { kind: "figma", title: j.name, url: `https://www.figma.com/file/${fileKey}`, preview: j.thumbnailUrl, data: j.document?.children?.map((p: any) => ({ page: p.name, frames: p.children?.map((f: any) => ({ id: f.id, name: f.name })) })) };
  },
  async exportImages(fileKey: string, nodeIds: string[], format: "png" | "svg" | "pdf" = "png") {
    return api(`https://api.figma.com/v1/images/${fileKey}?ids=${nodeIds.join(",")}&format=${format}`, { headers: { "X-Figma-Token": env("FIGMA_TOKEN") } });
  },
  comment: (fileKey: string, message: string) => api(`https://api.figma.com/v1/files/${fileKey}/comments`, { headers: { "X-Figma-Token": env("FIGMA_TOKEN") }, body: { message } }),
};

export const Canva = {
  async createDesign(title: string, type: "presentation" | "doc" | "whiteboard" = "presentation"): Promise<MediaCard> {
    requireConfig("CANVA_ACCESS_TOKEN", env("CANVA_ACCESS_TOKEN"));
    const j: any = await api("https://api.canva.com/rest/v1/designs", { token: env("CANVA_ACCESS_TOKEN"), body: { design_type: { type: "preset", name: type }, title } });
    return { kind: "canva", title, url: j.design?.urls?.edit_url, preview: j.design?.thumbnail?.url };
  },
  listDesigns: () => api("https://api.canva.com/rest/v1/designs", { token: env("CANVA_ACCESS_TOKEN") }),
};

export const Lovable = {
  /** "Build with URL": opens Lovable with a prefilled prompt that auto-submits. */
  buildLink(prompt: string, images: string[] = []): MediaCard {
    const params = new URLSearchParams({ autosubmit: "true" });
    const hash = new URLSearchParams({ prompt });
    images.slice(0, 10).forEach((i) => hash.append("images", i));
    return { kind: "lovable", title: "Build this app in Lovable", url: `https://lovable.dev/?${params}#${hash}` };
  },
};
