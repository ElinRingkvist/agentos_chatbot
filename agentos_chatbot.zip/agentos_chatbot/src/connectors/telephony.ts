import { config } from "../config";
import { api, requireConfig } from "../utils/http";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { complete } from "../ai/llm";

export interface CallPlan {
  id: string;
  to: string;
  business: string;
  goal: string; // "Book a table for 2 at 19:00 Friday", "Add me to the cancellation list", "Negotiate cable bill below 400 SEK"
  constraints: string[];
  userName: string;
  callbackNumber?: string;
  language: string;
  status: "planned" | "calling" | "completed" | "failed";
  transcript: { speaker: "agent" | "human"; text: string }[];
  outcome?: string;
  twilioSid?: string;
}

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

/**
 * Instinct Concierge — voice agent that phones real businesses (Twilio).
 * Conversation loop: Twilio <Gather input="speech"> posts what the human
 * said to /webhooks/twilio/voice/:id; the LLM produces the next line,
 * returned as TwiML <Say>. The outcome is summarised for the user at the end.
 * Placing a call always requires approval (call.place).
 */
export class VoiceConcierge {
  private file = dataPath("calls.json");

  private load(): CallPlan[] {
    return readJson<CallPlan[]>(this.file, []);
  }
  private saveOne(c: CallPlan) {
    writeJson(this.file, [...this.load().filter((x) => x.id !== c.id), c]);
  }
  get(id: string) {
    return this.load().find((c) => c.id === id);
  }
  list() {
    return this.load();
  }

  plan(input: Omit<CallPlan, "id" | "status" | "transcript" | "language"> & { language?: string }): CallPlan {
    const c: CallPlan = { ...input, id: uid("call"), status: "planned", transcript: [], language: input.language ?? "en-US" };
    this.saveOne(c);
    return c;
  }

  async place(id: string) {
    const t = config.twilio;
    requireConfig("Twilio (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER, PUBLIC_BASE_URL)", t.sid, t.token, t.from, t.publicUrl);
    const c = this.get(id);
    if (!c) throw new Error("Unknown call plan");
    const res: any = await api(`https://api.twilio.com/2010-04-01/Accounts/${t.sid}/Calls.json`, {
      basic: [t.sid, t.token],
      form: { To: c.to, From: t.from, Url: `${t.publicUrl}/webhooks/twilio/voice/${c.id}`, StatusCallback: `${t.publicUrl}/webhooks/twilio/status/${c.id}`, Record: "false" },
    });
    c.status = "calling";
    c.twilioSid = res.sid;
    this.saveOne(c);
    return c;
  }

  private async nextLine(c: CallPlan): Promise<{ say: string; done: boolean }> {
    const text = await complete(
      `You are a polite phone assistant calling ${c.business} on behalf of ${c.userName}. Goal: ${c.goal}. Constraints: ${c.constraints.join("; ") || "none"}. ` +
        `${c.callbackNumber ? `Callback number: ${c.callbackNumber}. ` : ""}Disclose you are an AI assistant if asked. Keep each turn to 1-2 sentences.\n` +
        `Transcript so far:\n${c.transcript.map((t) => `${t.speaker}: ${t.text}`).join("\n") || "(call just connected)"}\n` +
        `Reply with your next spoken line only. If the goal is achieved or impossible, end with [END].`,
    );
    return { say: text.replace("[END]", "").trim(), done: text.includes("[END]") };
  }

  /** Handles Twilio voice webhooks; returns TwiML. */
  async handleVoiceWebhook(id: string, params: Record<string, string>): Promise<string> {
    const c = this.get(id);
    if (!c) return `<?xml version="1.0" encoding="UTF-8"?><Response><Hangup/></Response>`;
    if (params.SpeechResult) c.transcript.push({ speaker: "human", text: params.SpeechResult });
    const { say, done } = await this.nextLine(c);
    c.transcript.push({ speaker: "agent", text: say });
    if (done) {
      c.status = "completed";
      c.outcome = await complete(`Summarise the outcome of this call for the user in one or two sentences:\n${c.transcript.map((t) => `${t.speaker}: ${t.text}`).join("\n")}`);
    }
    this.saveOne(c);
    const voice = `<Say language="${c.language}">${esc(say)}</Say>`;
    return done
      ? `<?xml version="1.0" encoding="UTF-8"?><Response>${voice}<Hangup/></Response>`
      : `<?xml version="1.0" encoding="UTF-8"?><Response><Gather input="speech" language="${c.language}" speechTimeout="auto" action="${config.twilio.publicUrl}/webhooks/twilio/voice/${c.id}">${voice}</Gather><Redirect>${config.twilio.publicUrl}/webhooks/twilio/voice/${c.id}</Redirect></Response>`;
  }

  handleStatusWebhook(id: string, params: Record<string, string>) {
    const c = this.get(id);
    if (!c) return;
    if (["failed", "busy", "no-answer", "canceled"].includes(params.CallStatus)) c.status = "failed";
    if (params.CallStatus === "completed" && c.status === "calling") c.status = "completed";
    this.saveOne(c);
    return c;
  }
}

export const concierge = new VoiceConcierge();
