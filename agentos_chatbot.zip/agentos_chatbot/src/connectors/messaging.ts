import { config } from "../config";
import { api, requireConfig } from "../utils/http";
import { completeJson } from "../ai/llm";
import { bus } from "../events/bus";
import { Apple } from "./platforms";

export interface ChatMsg {
  id: string;
  chatId: string;
  from: string;
  text: string;
  ts: string;
  isGroup: boolean;
  unread?: boolean;
}

export interface ExtractedPlan {
  summary: string;
  decisions: string[];
  openQuestions: string[];
  actionItems: { owner: string; task: string; due?: string }[];
  proposedEvents: { title: string; when?: string; where?: string }[];
}

/**
 * Group DM integration. The bot joins group threads (Telegram groups, SMS
 * via Twilio, iMessage on macOS), listens to cross-talk and resolves plans:
 * decisions, action items with owners, and proposed events.
 */
export class Messaging {
  private offset = 0;

  async telegramPoll(): Promise<ChatMsg[]> {
    requireConfig("TELEGRAM_BOT_TOKEN", config.notify.telegramToken);
    const j: any = await api(`https://api.telegram.org/bot${config.notify.telegramToken}/getUpdates?timeout=0&offset=${this.offset}`);
    const out: ChatMsg[] = [];
    for (const u of j.result ?? []) {
      this.offset = u.update_id + 1;
      const m = u.message ?? u.edited_message;
      if (!m?.text) continue;
      out.push({ id: String(m.message_id), chatId: String(m.chat.id), from: m.from?.username ?? m.from?.first_name ?? "?", text: m.text, ts: new Date(m.date * 1000).toISOString(), isGroup: m.chat.type !== "private", unread: true });
    }
    return out;
  }

  async telegramSend(chatId: string, text: string) {
    return api(`https://api.telegram.org/bot${config.notify.telegramToken}/sendMessage`, { body: { chat_id: chatId, text } });
  }

  async smsSend(to: string, text: string) {
    const t = config.twilio;
    requireConfig("Twilio", t.sid, t.token, t.from);
    return api(`https://api.twilio.com/2010-04-01/Accounts/${t.sid}/Messages.json`, { basic: [t.sid, t.token], form: { To: to, From: t.from, Body: text } });
  }

  async send(channel: "telegram" | "sms" | "imessage", to: string, text: string) {
    if (channel === "telegram") return this.telegramSend(to, text);
    if (channel === "sms") return this.smsSend(to, text);
    return Apple.sendMessage(to, text);
  }

  /** Parse group cross-talk into a structured plan. */
  async resolvePlan(messages: ChatMsg[]): Promise<ExtractedPlan> {
    const transcript = messages.map((m) => `${m.ts} ${m.from}: ${m.text}`).join("\n");
    return completeJson<ExtractedPlan>(
      `Read this group chat and organise the plan.\n${transcript}\n\nReturn {"summary":"","decisions":[],"openQuestions":[],"actionItems":[{"owner":"","task":"","due":""}],"proposedEvents":[{"title":"","when":"","where":""}]}`,
      { summary: transcript.slice(0, 300), decisions: [], openQuestions: [], actionItems: [], proposedEvents: [] },
    );
  }

  /** Long-poll Telegram and forward messages that mention the bot or are DMs. */
  watchTelegram(onMessage: (m: ChatMsg) => void, intervalMs = 3000) {
    return setInterval(async () => {
      try {
        for (const m of await this.telegramPoll()) {
          bus.emit("trigger", { name: "message.received", data: m });
          onMessage(m);
        }
      } catch {
        /* not configured */
      }
    }, intervalMs);
  }
}

export const messaging = new Messaging();
