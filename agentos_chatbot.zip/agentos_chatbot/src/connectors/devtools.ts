import * as crypto from "crypto";
import { config } from "../config";
import { api, requireConfig } from "../utils/http";

/** Verify an HMAC-SHA256 signature in constant time. */
export function verifyHmac(secret: string, payload: string, signature: string, prefix = ""): boolean {
  const expected = prefix + crypto.createHmac("sha256", secret).update(payload).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/** GitHub: repos, pull requests, reviews, issues, checks. */
export const GitHub = {
  base: "https://api.github.com",
  h: () => ({ token: config.github.token, headers: { "X-GitHub-Api-Version": "2022-11-28" } }),
  pr: (repo: string, n: number) => api(`${GitHub.base}/repos/${repo}/pulls/${n}`, GitHub.h()),
  async prDiff(repo: string, n: number): Promise<string> {
    const r = await fetch(`${GitHub.base}/repos/${repo}/pulls/${n}`, { headers: { Authorization: `Bearer ${config.github.token}`, Accept: "application/vnd.github.v3.diff" } });
    return r.text();
  },
  openPRs: (repo: string) => api(`${GitHub.base}/repos/${repo}/pulls?state=open`, GitHub.h()),
  comment: (repo: string, n: number, body: string) => api(`${GitHub.base}/repos/${repo}/issues/${n}/comments`, { ...GitHub.h(), body: { body } }),
  review: (repo: string, n: number, body: string, event: "COMMENT" | "REQUEST_CHANGES" | "APPROVE", comments: { path: string; line: number; body: string }[] = []) =>
    api(`${GitHub.base}/repos/${repo}/pulls/${n}/reviews`, { ...GitHub.h(), body: { body, event, comments: comments.map((c) => ({ ...c, side: "RIGHT" })) } }),
  createPR: (repo: string, head: string, base: string, title: string, body: string) => api(`${GitHub.base}/repos/${repo}/pulls`, { ...GitHub.h(), body: { head, base, title, body } }),
  createIssue: (repo: string, title: string, body: string) => api(`${GitHub.base}/repos/${repo}/issues`, { ...GitHub.h(), body: { title, body } }),
  verifyWebhook: (raw: string, sig: string) => !!config.github.webhookSecret && verifyHmac(config.github.webhookSecret, raw, sig, "sha256="),
};

/** Linear: issues and comments via GraphQL. */
export const Linear = {
  async gql<T = any>(query: string, variables: Record<string, unknown> = {}): Promise<T> {
    requireConfig("LINEAR_API_KEY", config.linear.apiKey);
    const j: any = await api("https://api.linear.app/graphql", { headers: { Authorization: config.linear.apiKey }, body: { query, variables } });
    if (j.errors) throw new Error(JSON.stringify(j.errors));
    return j.data;
  },
  issue: (id: string) => Linear.gql(`query($id:String!){ issue(id:$id){ id identifier title description url state{name} team{key} } }`, { id }),
  comment: (issueId: string, body: string) => Linear.gql(`mutation($i:String!,$b:String!){ commentCreate(input:{issueId:$i, body:$b}){ success } }`, { i: issueId, b: body }),
  myIssues: () => Linear.gql(`{ viewer { assignedIssues(first:50, filter:{state:{type:{nin:["completed","canceled"]}}}){ nodes{ id identifier title priority url } } } }`),
  verifyWebhook: (raw: string, sig: string) => !!config.linear.webhookSecret && verifyHmac(config.linear.webhookSecret, raw, sig),
};

/** Slack: post, read threads, verify request signatures. */
export const Slack = {
  post: (channel: string, text: string, thread_ts?: string) => api("https://slack.com/api/chat.postMessage", { token: config.slack.botToken, body: { channel, text, thread_ts } }),
  thread: (channel: string, ts: string) => api(`https://slack.com/api/conversations.replies?channel=${channel}&ts=${ts}`, { token: config.slack.botToken }),
  unreadDMs: () => api("https://slack.com/api/conversations.list?types=im,mpim&exclude_archived=true", { token: config.slack.botToken }),
  verify(raw: string, timestamp: string, signature: string): boolean {
    if (!config.slack.signingSecret || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return false;
    return verifyHmac(config.slack.signingSecret, `v0:${timestamp}:${raw}`, signature, "v0=");
  },
};

/** CI/CD & monitoring: Vercel, Cloudflare, Sentry, Supabase. */
export const DevOps = {
  vercelDeployments: (limit = 10) => api(`https://api.vercel.com/v6/deployments?limit=${limit}`, { token: config.vercel.token }),
  vercelRedeploy: (deploymentId: string, name: string) => api("https://api.vercel.com/v13/deployments", { token: config.vercel.token, body: { name, deploymentId, target: "production" } }),
  cloudflareWorkers: () => api(`https://api.cloudflare.com/client/v4/accounts/${config.cloudflare.accountId}/workers/scripts`, { token: config.cloudflare.token }),
  cloudflarePages: () => api(`https://api.cloudflare.com/client/v4/accounts/${config.cloudflare.accountId}/pages/projects`, { token: config.cloudflare.token }),
  sentryIssues: (project: string, query = "is:unresolved") => api(`https://sentry.io/api/0/projects/${config.sentry.org}/${project}/issues/?query=${encodeURIComponent(query)}`, { token: config.sentry.token }),
  sentryResolve: (issueId: string) => api(`https://sentry.io/api/0/issues/${issueId}/`, { method: "PUT", token: config.sentry.token, body: { status: "resolved" } }),
  supabaseQuery: (table: string, query = "select=*&limit=50") =>
    api(`${config.supabase.url}/rest/v1/${table}?${query}`, { headers: { apikey: config.supabase.serviceKey, Authorization: `Bearer ${config.supabase.serviceKey}` } }),
  supabaseInsert: (table: string, rows: unknown) =>
    api(`${config.supabase.url}/rest/v1/${table}`, { headers: { apikey: config.supabase.serviceKey, Authorization: `Bearer ${config.supabase.serviceKey}`, Prefer: "return=representation" }, body: rows }),
};
