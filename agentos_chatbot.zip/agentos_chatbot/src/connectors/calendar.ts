import { config } from "../config";
import { api } from "../utils/http";

export interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  location?: string;
  description?: string;
  source: "ics" | "google" | "microsoft";
}

/** Parse an iCalendar (.ics) feed. Works with Google, iCloud, Outlook "secret address" feeds. */
export function parseICS(ics: string): CalendarEvent[] {
  const unfolded = ics.replace(/\r?\n[ \t]/g, "");
  const events: CalendarEvent[] = [];
  for (const block of unfolded.split("BEGIN:VEVENT").slice(1)) {
    const body = block.split("END:VEVENT")[0];
    const get = (k: string) => body.match(new RegExp(`^${k}(?:;[^:\\n]*)?:(.*)$`, "m"))?.[1]?.trim();
    const toIso = (v?: string) => {
      if (!v) return "";
      const m = v.match(/^(\d{4})(\d{2})(\d{2})(?:T(\d{2})(\d{2})(\d{2})(Z)?)?/);
      if (!m) return v;
      const [, y, mo, d, h = "00", mi = "00", s = "00", z] = m;
      const str = `${y}-${mo}-${d}T${h}:${mi}:${s}${z ? "Z" : ""}`;
      return new Date(str).toISOString();
    };
    const unescape = (s?: string) => s?.replace(/\\n/g, "\n").replace(/\\,/g, ",").replace(/\\;/g, ";");
    events.push({
      id: get("UID") ?? `${get("DTSTART")}-${get("SUMMARY")}`,
      title: unescape(get("SUMMARY")) ?? "(no title)",
      start: toIso(get("DTSTART")),
      end: toIso(get("DTEND") ?? get("DTSTART")),
      location: unescape(get("LOCATION")),
      description: unescape(get("DESCRIPTION")),
      source: "ics",
    });
  }
  return events.sort((a, b) => a.start.localeCompare(b.start));
}

/** Calendar sweeps across ICS feeds, Google Calendar and Microsoft 365. */
export class CalendarConnector {
  async eventsBetween(from: Date, to: Date): Promise<CalendarEvent[]> {
    const out: CalendarEvent[] = [];
    const jobs: Promise<void>[] = [];
    if (config.google.calendarIcsUrl)
      jobs.push(
        fetch(config.google.calendarIcsUrl)
          .then((r) => r.text())
          .then((t) => void out.push(...parseICS(t).filter((e) => e.start >= from.toISOString() && e.start <= to.toISOString()))),
      );
    if (config.google.accessToken)
      jobs.push(
        api(`https://www.googleapis.com/calendar/v3/calendars/primary/events?singleEvents=true&orderBy=startTime&timeMin=${from.toISOString()}&timeMax=${to.toISOString()}`, { token: config.google.accessToken }).then(
          (j: any) =>
            void out.push(
              ...(j.items ?? []).map((e: any) => ({ id: e.id, title: e.summary ?? "", start: e.start?.dateTime ?? e.start?.date, end: e.end?.dateTime ?? e.end?.date, location: e.location, description: e.description, source: "google" as const })),
            ),
        ),
      );
    if (config.microsoft.accessToken)
      jobs.push(
        api(`https://graph.microsoft.com/v1.0/me/calendarView?startDateTime=${from.toISOString()}&endDateTime=${to.toISOString()}`, { token: config.microsoft.accessToken }).then(
          (j: any) =>
            void out.push(
              ...(j.value ?? []).map((e: any) => ({ id: e.id, title: e.subject, start: new Date(e.start.dateTime + "Z").toISOString(), end: new Date(e.end.dateTime + "Z").toISOString(), location: e.location?.displayName, source: "microsoft" as const })),
            ),
        ),
      );
    await Promise.allSettled(jobs);
    return out.sort((a, b) => a.start.localeCompare(b.start));
  }

  today() {
    const s = new Date();
    s.setHours(0, 0, 0, 0);
    const e = new Date(s.getTime() + 86_400_000);
    return this.eventsBetween(s, e);
  }

  async createGoogleEvent(title: string, start: Date, end: Date, description?: string) {
    return api("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
      token: config.google.accessToken,
      body: { summary: title, description, start: { dateTime: start.toISOString() }, end: { dateTime: end.toISOString() } },
    });
  }
}

export const calendar = new CalendarConnector();
