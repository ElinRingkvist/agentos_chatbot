import * as fs from "fs";
import * as path from "path";

/**
 * Central configuration. Values come from environment variables (optionally
 * loaded from a local `.env` file) so secrets never live in source control.
 */
function loadDotEnv(file = path.join(process.cwd(), ".env")) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf-8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (!m || line.trim().startsWith("#")) continue;
    const value = m[2].replace(/^["']|["']$/g, "");
    if (process.env[m[1]] === undefined) process.env[m[1]] = value;
  }
}
loadDotEnv();

const env = (key: string, fallback = ""): string => process.env[key] ?? fallback;
const num = (key: string, fallback: number): number => {
  const v = Number(process.env[key]);
  return Number.isFinite(v) && process.env[key] !== "" && process.env[key] !== undefined ? v : fallback;
};

const home = path.resolve(env("AGENTOS_HOME", path.join(process.cwd(), ".agentos")));

export const config = {
  home,
  language: env("AGENTOS_LANG", "sv"),
  workspaceRoot: path.resolve(env("AGENTOS_WORKSPACES", path.join(home, "workspaces"))),

  llm: {
    /** "openai" = any OpenAI-compatible server (Ollama, llama.cpp, LM Studio, vLLM, OpenAI). "huggingface" = HF router. "offline" = deterministic stub. */
    provider: env("LLM_PROVIDER", process.env.HF_TOKEN ? "huggingface" : "openai"),
    baseUrl: env("LLM_BASE_URL", "http://localhost:11434/v1"),
    apiKey: env("LLM_API_KEY", "ollama"),
    model: env("LLM_MODEL", "qwen2.5-coder:7b"),
    hfToken: env("HF_TOKEN"),
    hfModel: env("HF_MODEL", "Qwen/Qwen2.5-Coder-7B-Instruct"),
    timeoutMs: num("LLM_TIMEOUT_MS", 120_000),
  },

  server: {
    port: num("AGENTOS_PORT", 7717),
    host: env("AGENTOS_HOST", "127.0.0.1"),
    /** Bearer token required by the remote-control API. Generated on first start when empty. */
    token: env("AGENTOS_API_TOKEN"),
  },

  vault: { masterKey: env("AGENTOS_VAULT_KEY") },

  heartbeat: {
    intervalMs: num("HEARTBEAT_INTERVAL_MS", 3 * 60 * 60 * 1000),
    digestTime: env("DIGEST_TIME", "07:00"),
    digestSections: env("DIGEST_SECTIONS", "email,calendar,messages,news,tasks,suggestions").split(","),
    newsTopics: env("DIGEST_NEWS_TOPICS", "AI agents").split(","),
  },

  search: {
    braveKey: env("BRAVE_SEARCH_API_KEY"),
    googleKey: env("GOOGLE_CSE_KEY"),
    googleCx: env("GOOGLE_CSE_ID"),
  },

  notify: {
    ntfyTopic: env("NTFY_TOPIC"),
    ntfyServer: env("NTFY_SERVER", "https://ntfy.sh"),
    webhookUrl: env("NOTIFY_WEBHOOK_URL"),
    telegramToken: env("TELEGRAM_BOT_TOKEN"),
    telegramChatId: env("TELEGRAM_CHAT_ID"),
    slackWebhook: env("SLACK_WEBHOOK_URL"),
  },

  email: {
    imapHost: env("IMAP_HOST"),
    imapPort: num("IMAP_PORT", 993),
    smtpHost: env("SMTP_HOST"),
    smtpPort: num("SMTP_PORT", 465),
    user: env("EMAIL_USER"),
    password: env("EMAIL_PASSWORD"),
    address: env("ASSISTANT_EMAIL_ADDRESS"),
  },

  google: { accessToken: env("GOOGLE_ACCESS_TOKEN"), calendarIcsUrl: env("CALENDAR_ICS_URL") },
  microsoft: { accessToken: env("MS_GRAPH_ACCESS_TOKEN") },
  slack: { botToken: env("SLACK_BOT_TOKEN"), signingSecret: env("SLACK_SIGNING_SECRET") },
  linear: { apiKey: env("LINEAR_API_KEY"), webhookSecret: env("LINEAR_WEBHOOK_SECRET") },
  github: { token: env("GITHUB_TOKEN"), webhookSecret: env("GITHUB_WEBHOOK_SECRET") },
  vercel: { token: env("VERCEL_TOKEN") },
  cloudflare: { token: env("CLOUDFLARE_API_TOKEN"), accountId: env("CLOUDFLARE_ACCOUNT_ID") },
  sentry: { token: env("SENTRY_AUTH_TOKEN"), org: env("SENTRY_ORG") },
  supabase: { url: env("SUPABASE_URL"), serviceKey: env("SUPABASE_SERVICE_ROLE_KEY") },
  twilio: { sid: env("TWILIO_ACCOUNT_SID"), token: env("TWILIO_AUTH_TOKEN"), from: env("TWILIO_FROM_NUMBER"), publicUrl: env("PUBLIC_BASE_URL") },
  social: {
    mastodonUrl: env("MASTODON_URL"),
    mastodonToken: env("MASTODON_TOKEN"),
    blueskyHandle: env("BLUESKY_HANDLE"),
    blueskyAppPassword: env("BLUESKY_APP_PASSWORD"),
    xBearer: env("X_BEARER_TOKEN"),
  },
  maps: { googleKey: env("GOOGLE_MAPS_API_KEY"), osrmUrl: env("OSRM_URL", "https://router.project-osrm.org") },
};

export type AgentOSConfig = typeof config;
