import * as fs from "fs";
import * as os from "os";
import * as path from "path";

/**
 * Laptop-closed / 24/7 execution: generates an OS service definition so the
 * daemon starts at boot and restarts on failure (systemd user unit on Linux,
 * launchd agent on macOS, a Scheduled Task script on Windows). For true
 * "laptop closed" operation run the same daemon on a VPS/cloud VM.
 */
export function installService(projectDir = process.cwd()): string {
  const node = process.execPath;
  const entry = path.join(projectDir, "dist", "cli.js");
  if (process.platform === "linux") {
    const dir = path.join(os.homedir(), ".config", "systemd", "user");
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, "agentic-os.service");
    fs.writeFileSync(
      file,
      `[Unit]\nDescription=Agentic OS daemon\nAfter=network-online.target\n\n[Service]\nWorkingDirectory=${projectDir}\nExecStart=${node} ${entry} daemon\nRestart=always\nRestartSec=5\nEnvironment=AGENTOS_APPROVAL_MODE=api\n\n[Install]\nWantedBy=default.target\n`,
    );
    return `Wrote ${file}\nEnable with:\n  systemctl --user daemon-reload && systemctl --user enable --now agentic-os\n  loginctl enable-linger $USER   # keep running after logout`;
  }
  if (process.platform === "darwin") {
    const file = path.join(os.homedir(), "Library", "LaunchAgents", "dev.agentic-os.daemon.plist");
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(
      file,
      `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>\n<key>Label</key><string>dev.agentic-os.daemon</string>\n<key>ProgramArguments</key><array><string>${node}</string><string>${entry}</string><string>daemon</string></array>\n<key>WorkingDirectory</key><string>${projectDir}</string>\n<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>\n<key>EnvironmentVariables</key><dict><key>AGENTOS_APPROVAL_MODE</key><string>api</string></dict>\n<key>StandardOutPath</key><string>${projectDir}/.agentos/daemon.log</string>\n<key>StandardErrorPath</key><string>${projectDir}/.agentos/daemon.err</string>\n</dict></plist>\n`,
    );
    return `Wrote ${file}\nLoad with:\n  launchctl load -w ${file}\nTip: "caffeinate -s" or Energy settings keep a closed Mac awake on power.`;
  }
  const file = path.join(projectDir, "install-agentic-os-task.ps1");
  fs.writeFileSync(
    file,
    `$action = New-ScheduledTaskAction -Execute "${node}" -Argument '"${entry}" daemon' -WorkingDirectory "${projectDir}"\n$trigger = New-ScheduledTaskTrigger -AtLogOn\n$settings = New-ScheduledTaskSettingsSet -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries\nRegister-ScheduledTask -TaskName "AgenticOS" -Action $action -Trigger $trigger -Settings $settings -Force\n`,
  );
  return `Wrote ${file}\nRun it in an elevated PowerShell: powershell -ExecutionPolicy Bypass -File "${file}"`;
}
