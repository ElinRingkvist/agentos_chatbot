import { AgenticOS } from "./core/engine";
import { OpenMausBotConnector } from "./connectors/mausBot";
import { HuggingFaceConnector } from "./ai/huggingFace";
import { Logger } from "./utils/logger";
import { ApiServer } from "./server/api";

/**
 * Demo entry point (`npm start`). For 24/7 operation use `npm run daemon`.
 * Set AGENTOS_APPROVAL_MODE=auto to auto-approve the demo's approval cards.
 */
async function main() {
  console.log("\n==================================================================");
  console.log("   AGENTIC OS: MULTI-AGENT, GUI AUTOMATION & HF ENGINE            ");
  console.log("==================================================================\n");

  const os = new AgenticOS("sv");
  await os.start({ heartbeatMs: Number(process.env.HEARTBEAT_INTERVAL_MS) || 15_000 });
  new ApiServer(os).start();

  const hf = new HuggingFaceConnector();
  Logger.agent("HF", await hf.runInference("Analysera skärmgränssnittet och lokalisera källkoden."));

  Logger.info("System", "Triggering GUI Automation via OpenMausBot...");
  OpenMausBotConnector.dryRun = OpenMausBotConnector.dryRun || process.env.MAUSBOT_DRY_RUN !== "0";
  await OpenMausBotConnector.moveAndClick({ x: 640, y: 480 }, "left");
  await OpenMausBotConnector.typeText("Automated workspace command");

  await os.executeMultiAgentWorkflow("Automated Desktop & Web Task", [
    { agentName: "WebResearcher", task: "Sök efter senaste trenderna inom offline AI-agenter på internet", useWeb: true },
    { agentName: "DevBot", task: "Bygg lokal anslutning för Cursor och filsystemet.", useWeb: false },
  ]);

  Logger.info("System", "Engine running in background. Press Ctrl+C to exit.");
}

if (require.main === module) {
  main().catch((err) => {
    console.error("Fatal Engine Error:", err);
  });
}

export { AgenticOS } from "./core/engine";
export { Agent } from "./core/agent";
export { PersistentMemory } from "./core/memory";
export { ApiServer } from "./server/api";
