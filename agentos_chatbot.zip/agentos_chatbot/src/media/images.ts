import * as fs from "fs";
import * as path from "path";
import { optionalRequire } from "../utils/fsx";
import { HuggingFaceConnector } from "../ai/huggingFace";

/**
 * Local image manipulation. SVG logos are transformed natively (colour
 * remapping); raster images (PNG/JPG/WebP) use the optional `sharp` package.
 * Also wraps text-to-image generation through Hugging Face.
 */

type RGB = [number, number, number];

function parseColor(c: string): RGB | null {
  const hex = c.trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (hex) {
    const h = hex[1].length === 3 ? hex[1].replace(/./g, "$&$&") : hex[1];
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  const rgb = c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  if (rgb) return [Number(rgb[1]), Number(rgb[2]), Number(rgb[3])];
  const named: Record<string, RGB> = { white: [255, 255, 255], black: [0, 0, 0], red: [255, 0, 0], blue: [0, 0, 255], green: [0, 128, 0] };
  return named[c.toLowerCase()] ?? null;
}
const toHex = ([r, g, b]: RGB) => "#" + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
const luminance = ([r, g, b]: RGB) => 0.2126 * r + 0.7152 * g + 0.0722 * b;

function rgbToHsl([r, g, b]: RGB): [number, number, number] {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b),
    min = Math.min(r, g, b);
  let h = 0,
    s = 0;
  const l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h /= 6;
  }
  return [h, s, l];
}
function hslToRgb([h, s, l]: [number, number, number]): RGB {
  if (s === 0) return [l * 255, l * 255, l * 255];
  const hue = (p: number, q: number, t: number) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1 / 6) return p + (q - p) * 6 * t;
    if (t < 1 / 2) return q;
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
    return p;
  };
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  return [hue(p, q, h + 1 / 3) * 255, hue(p, q, h) * 255, hue(p, q, h - 1 / 3) * 255];
}

export type Variant = "dark" | "light" | "mono" | "inverted" | "minimal" | { hueShift: number } | { brand: string };

export function transformColor(c: RGB, v: Variant): RGB {
  const [h, s, l] = rgbToHsl(c);
  if (v === "inverted") return [255 - c[0], 255 - c[1], 255 - c[2]];
  if (v === "mono") {
    const y = luminance(c);
    return [y, y, y];
  }
  if (v === "dark") return hslToRgb([h, s, l > 0.5 ? 1 - l * 0.9 : Math.min(1, 1 - l + 0.1)]);
  if (v === "light") return hslToRgb([h, s * 0.9, Math.min(1, l + (1 - l) * 0.5)]);
  if (v === "minimal") return luminance(c) > 128 ? [255, 255, 255] : [17, 17, 17];
  if ("hueShift" in v) return hslToRgb([(h + v.hueShift / 360) % 1, s, l]);
  const brand = parseColor(v.brand) ?? c;
  const [bh, bs] = rgbToHsl(brand);
  return hslToRgb([bh, Math.max(bs, s), l]);
}

export function svgVariant(svg: string, v: Variant): string {
  return svg.replace(/(#[0-9a-f]{6}\b|#[0-9a-f]{3}\b|rgba?\([^)]+\))/gi, (m) => {
    const c = parseColor(m);
    return c ? toHex(transformColor(c, v)) : m;
  });
}

const VARIANT_NAME = (v: Variant) => (typeof v === "string" ? v : "hueShift" in v ? `hue${v.hueShift}` : `brand-${v.brand.replace("#", "")}`);

/** Generate multiple variants of a dropped logo file. Returns written paths. */
export async function logoVariants(file: string, variants: Variant[] = ["dark", "light", "mono", "inverted", "minimal", { hueShift: 120 }, { hueShift: 240 }], outDir = path.join(path.dirname(file), "variants")): Promise<string[]> {
  fs.mkdirSync(outDir, { recursive: true });
  const ext = path.extname(file).toLowerCase();
  const base = path.basename(file, ext);
  const out: string[] = [];
  if (ext === ".svg") {
    const svg = fs.readFileSync(file, "utf-8");
    for (const v of variants) {
      const p = path.join(outDir, `${base}-${VARIANT_NAME(v)}.svg`);
      fs.writeFileSync(p, svgVariant(svg, v));
      out.push(p);
    }
    return out;
  }
  const sharp = optionalRequire<any>("sharp");
  const { data, info } = await sharp(file).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  for (const v of variants) {
    const buf = Buffer.from(data);
    for (let i = 0; i < buf.length; i += 4) {
      if (buf[i + 3] === 0) continue;
      const [r, g, b] = transformColor([buf[i], buf[i + 1], buf[i + 2]], v);
      buf[i] = r;
      buf[i + 1] = g;
      buf[i + 2] = b;
    }
    const p = path.join(outDir, `${base}-${VARIANT_NAME(v)}.png`);
    await sharp(buf, { raw: { width: info.width, height: info.height, channels: 4 } }).png().toFile(p);
    out.push(p);
  }
  return out;
}

export async function generateImage(prompt: string, outFile: string) {
  const bytes = await new HuggingFaceConnector().generateImage(prompt);
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, bytes);
  return outFile;
}
