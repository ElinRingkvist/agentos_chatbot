import { bus } from "../events/bus";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";
import { completeJson } from "../ai/llm";
import type { Agent } from "../core/agent";
import { notifier } from "../notifications/notifier";

export interface TaskStep {
  title: string;
  status: "pending" | "running" | "done" | "failed";
  output?: string;
  startedAt?: string;
  finishedAt?: string;
}

export interface BackgroundTask {
  id: string;
  title: string;
  goal: string;
  agent: string;
  status: "queued" | "running" | "waiting_review" | "done" | "failed" | "cancelled";
  steps: TaskStep[];
  createdAt: string;
  updatedAt: string;
  result?: string;
  error?: string;
  attempts: number;
  notifyOnDone: boolean;
}

/**
 * Multi-hour background task runner. Tasks are planned into steps, executed
 * one step at a time and checkpointed to disk after each step, so a crash,
 * reboot or closed laptop simply resumes from the last finished step when
 * the daemon starts again. The user is notified only when work is ready.
 */
export class TaskQueue {
  private file = dataPath("tasks.json");
  private running = new Set<string>();
  private agents: () => Map<string, Agent>;
  concurrency = Number(process.env.TASK_CONCURRENCY) || 3;

  constructor(agents: () => Map<string, Agent>) {
    this.agents = agents;
  }

  private load(): BackgroundTask[] {
    return readJson<BackgroundTask[]>(this.file, []);
  }
  private save(all: BackgroundTask[]) {
    writeJson(this.file, all);
  }
  private update(id: string, fn: (t: BackgroundTask) => void) {
    const all = this.load();
    const t = all.find((x) => x.id === id);
    if (!t) return;
    fn(t);
    t.updatedAt = new Date().toISOString();
    this.save(all);
    return t;
  }

  list(status?: BackgroundTask["status"]) {
    return this.load().filter((t) => !status || t.status === status);
  }

  get(id: string) {
    return this.load().find((t) => t.id === id);
  }

  async enqueue(input: { title: string; goal: string; agent: string; steps?: string[]; notifyOnDone?: boolean }): Promise<BackgroundTask> {
    const steps = input.steps ?? (await this.plan(input.goal));
    const now = new Date().toISOString();
    const task: BackgroundTask = {
      id: uid("task"),
      title: input.title,
      goal: input.goal,
      agent: input.agent,
      status: "queued",
      steps: steps.map((title) => ({ title, status: "pending" })),
      createdAt: now,
      updatedAt: now,
      attempts: 0,
      notifyOnDone: input.notifyOnDone ?? true,
    };
    const all = this.load();
    all.push(task);
    this.save(all);
    bus.emit("task.created", { taskId: task.id, title: task.title, agent: task.agent });
    void this.pump();
    return task;
  }

  /** Break a goal into concrete steps with the LLM (falls back to one step). */
  async plan(goal: string): Promise<string[]> {
    const steps = await completeJson<string[]>(
      `Break this goal into 3-12 concrete, verifiable steps an autonomous agent can execute one at a time:\n"${goal}"\nReturn a JSON array of strings.`,
      [goal],
    );
    return Array.isArray(steps) && steps.length ? steps.map(String) : [goal];
  }

  cancel(id: string) {
    return !!this.update(id, (t) => {
      if (t.status !== "done") t.status = "cancelled";
    });
  }

  approveReview(id: string) {
    return !!this.update(id, (t) => {
      if (t.status === "waiting_review") t.status = "done";
    });
  }

  /** Resume tasks interrupted by a shutdown. Call on daemon start. */
  resume() {
    const all = this.load();
    let n = 0;
    for (const t of all)
      if (t.status === "running") {
        t.status = "queued";
        t.steps.forEach((s) => s.status === "running" && (s.status = "pending"));
        n++;
      }
    this.save(all);
    if (n) Logger.info("Tasks", `Resuming ${n} interrupted background task(s).`);
    void this.pump();
  }

  private async pump() {
    const queued = this.load().filter((t) => t.status === "queued" && !this.running.has(t.id));
    for (const t of queued) {
      if (this.running.size >= this.concurrency) break;
      this.running.add(t.id);
      void this.execute(t.id).finally(() => {
        this.running.delete(t.id);
        void this.pump();
      });
    }
  }

  private async execute(id: string) {
    const task = this.update(id, (t) => {
      t.status = "running";
      t.attempts++;
    })!;
    const agent = this.agents().get(task.agent);
    if (!agent) {
      this.update(id, (t) => ((t.status = "failed"), (t.error = `Unknown agent ${task.agent}`)));
      return;
    }
    const done: string[] = task.steps.filter((s) => s.status === "done").map((s) => `${s.title}: ${s.output ?? ""}`);
    for (let i = 0; i < task.steps.length; i++) {
      const current = this.get(id);
      if (!current || current.status === "cancelled") return;
      if (current.steps[i].status === "done") continue;
      this.update(id, (t) => ((t.steps[i].status = "running"), (t.steps[i].startedAt = new Date().toISOString())));
      bus.emit("task.progress", { taskId: id, step: i + 1, total: task.steps.length, note: task.steps[i].title });
      try {
        const out = await agent.run(
          `Overall goal: ${task.goal}\nCompleted so far:\n${done.join("\n") || "(nothing yet)"}\n\nNow do step ${i + 1}/${task.steps.length}: ${task.steps[i].title}`,
          { mode: "agent", threadId: id, taskId: id },
        );
        done.push(`${task.steps[i].title}: ${out.slice(0, 500)}`);
        this.update(id, (t) => ((t.steps[i].status = "done"), (t.steps[i].output = out), (t.steps[i].finishedAt = new Date().toISOString())));
      } catch (err) {
        const msg = (err as Error).message;
        this.update(id, (t) => ((t.steps[i].status = "failed"), (t.status = "failed"), (t.error = msg)));
        bus.emit("task.failed", { taskId: id, error: msg });
        await notifier.send(`Task failed: ${task.title}`, msg, "high");
        return;
      }
    }
    const result = done.join("\n");
    this.update(id, (t) => ((t.status = "waiting_review"), (t.result = result)));
    bus.emit("task.completed", { taskId: id, result });
    if (task.notifyOnDone) await notifier.send(`Ready for review: ${task.title}`, result.slice(0, 500), "high", "loud");
  }
}
