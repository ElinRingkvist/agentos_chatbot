import * as crypto from "crypto";
import * as fs from "fs";
import * as path from "path";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { complete } from "../ai/llm";

export interface Canvas {
  id: string;
  title: string;
  agent: string;
  file: string;
  shareToken: string;
  createdAt: string;
  updatedAt: string;
  versions: number;
}

/**
 * Cloud agents & live canvases. Agents render self-contained HTML
 * artifacts (app previews, dashboards, components) that the API server
 * hosts at /canvas/:id?t=<shareToken> — a shareable link. Canvases are
 * versioned so agents can iterate on them live.
 */
export class CanvasStore {
  private index = dataPath("canvases", "index.json");

  list(): Canvas[] {
    return readJson<Canvas[]>(this.index, []);
  }
  get(id: string) {
    return this.list().find((c) => c.id === id);
  }

  save(title: string, html: string, agent: string, id?: string): Canvas {
    const all = this.list();
    let c = id ? all.find((x) => x.id === id) : undefined;
    const now = new Date().toISOString();
    if (!c) {
      const nid = uid("cnv");
      c = { id: nid, title, agent, file: dataPath("canvases", `${nid}.html`), shareToken: crypto.randomBytes(16).toString("hex"), createdAt: now, updatedAt: now, versions: 0 };
      all.push(c);
    } else if (fs.existsSync(c.file)) fs.copyFileSync(c.file, `${c.file}.v${c.versions}`);
    c.versions++;
    c.updatedAt = now;
    c.title = title;
    fs.mkdirSync(path.dirname(c.file), { recursive: true });
    fs.writeFileSync(c.file, html);
    writeJson(this.index, all);
    return c;
  }

  /** Ask the model to build or revise an interactive HTML canvas. */
  async generate(brief: string, agent: string, id?: string): Promise<Canvas> {
    const prev = id && this.get(id) ? fs.readFileSync(this.get(id)!.file, "utf-8") : "";
    let html = await complete(
      `${prev ? `Revise this HTML canvas:\n${prev.slice(0, 30_000)}\n\nChange request: ` : "Build a single self-contained HTML file (inline CSS/JS, no external requests) for: "}${brief}\nReturn only the HTML.`,
      "You generate interactive, accessible single-file HTML prototypes.",
    );
    html = html.replace(/^\s*```html?\n?/, "").replace(/\n?```\s*$/, "");
    if (!/<html/i.test(html)) html = `<!doctype html><html><head><meta charset="utf-8"><title>${brief.slice(0, 60)}</title></head><body><pre>${html.replace(/</g, "&lt;")}</pre></body></html>`;
    return this.save(brief.slice(0, 80), html, agent, id);
  }

  read(id: string, token: string): string | null {
    const c = this.get(id);
    if (!c || !crypto.timingSafeEqual(Buffer.from(c.shareToken), Buffer.from(token.padEnd(c.shareToken.length).slice(0, c.shareToken.length)))) return null;
    return fs.readFileSync(c.file, "utf-8");
  }

  shareUrl(c: Canvas, base = process.env.PUBLIC_BASE_URL ?? "http://127.0.0.1:7717") {
    return `${base}/canvas/${c.id}?t=${c.shareToken}`;
  }
}

export const canvases = new CanvasStore();
