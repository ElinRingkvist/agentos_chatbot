import { completeJson } from "../ai/llm";
import { GitHub } from "../connectors/devtools";
import { Logger } from "../utils/logger";

export interface Finding {
  file: string;
  line: number;
  severity: "critical" | "high" | "medium" | "low";
  rule: string;
  message: string;
  source: "static" | "llm";
}

interface Rule {
  id: string;
  severity: Finding["severity"];
  re: RegExp;
  message: string;
  files?: RegExp;
}

/** Static rules run on added lines only. Cheap, offline, deterministic. */
export const RULES: Rule[] = [
  { id: "secret.aws", severity: "critical", re: /AKIA[0-9A-Z]{16}/, message: "AWS access key committed" },
  { id: "secret.private-key", severity: "critical", re: /-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/, message: "Private key committed" },
  { id: "secret.generic", severity: "high", re: /(api[_-]?key|secret|password|token)\s*[:=]\s*["'][^"'\s]{12,}["']/i, message: "Hard-coded credential" },
  { id: "secret.github", severity: "critical", re: /gh[pousr]_[A-Za-z0-9]{36,}/, message: "GitHub token committed" },
  { id: "inject.eval", severity: "high", re: /\b(eval|new Function)\s*\(/, message: "Dynamic code execution", files: /\.(js|ts|jsx|tsx|mjs|cjs)$/ },
  { id: "inject.exec", severity: "high", re: /\b(exec|execSync|spawn)\s*\(\s*[`'"].*\$\{/, message: "Shell command built from interpolated input (command injection)" },
  { id: "inject.sql", severity: "high", re: /\b(query|execute|raw)\s*\(\s*[`'"]\s*(SELECT|INSERT|UPDATE|DELETE)[^`'"]*(\$\{|\+\s*\w)/i, message: "SQL built by string concatenation (SQL injection)" },
  { id: "xss.innerhtml", severity: "medium", re: /(dangerouslySetInnerHTML|\.innerHTML\s*=)/, message: "Unsanitised HTML injection (XSS)" },
  { id: "py.subprocess-shell", severity: "high", re: /subprocess\.\w+\(.*shell\s*=\s*True/, message: "subprocess with shell=True", files: /\.py$/ },
  { id: "py.pickle", severity: "medium", re: /pickle\.loads?\(/, message: "Unpickling untrusted data", files: /\.py$/ },
  { id: "crypto.weak", severity: "medium", re: /createHash\(\s*["'](md5|sha1)["']\s*\)/, message: "Weak hash for security purposes" },
  { id: "tls.disabled", severity: "high", re: /(rejectUnauthorized\s*:\s*false|verify\s*=\s*False|NODE_TLS_REJECT_UNAUTHORIZED\s*=\s*["']?0)/, message: "TLS verification disabled" },
  { id: "cors.wildcard", severity: "low", re: /Access-Control-Allow-Origin["']?\s*[:,]\s*["']\*["']/, message: "Wildcard CORS" },
  { id: "runtime.unhandled", severity: "low", re: /\.then\([^)]*\)\s*;?\s*$/, message: "Promise without catch (possible unhandled rejection)" },
  { id: "runtime.json-parse", severity: "low", re: /JSON\.parse\((req|request)\.(body|query)/, message: "JSON.parse on request input without try/catch" },
];

export interface DiffLine {
  file: string;
  line: number;
  text: string;
}

/** Extract added lines with their new-file line numbers from a unified diff. */
export function addedLines(diff: string): DiffLine[] {
  const out: DiffLine[] = [];
  let file = "";
  let line = 0;
  for (const raw of diff.split("\n")) {
    if (raw.startsWith("+++ ")) file = raw.slice(4).replace(/^b\//, "");
    else if (raw.startsWith("@@")) line = Number(raw.match(/\+(\d+)/)?.[1] ?? 1) - 1;
    else if (raw.startsWith("+") && !raw.startsWith("+++")) out.push({ file, line: ++line, text: raw.slice(1) });
    else if (!raw.startsWith("-")) line++;
  }
  return out;
}

export function staticScan(diff: string): Finding[] {
  const findings: Finding[] = [];
  for (const l of addedLines(diff)) {
    for (const r of RULES) {
      if (r.files && !r.files.test(l.file)) continue;
      if (r.re.test(l.text)) findings.push({ file: l.file, line: l.line, severity: r.severity, rule: r.id, message: r.message, source: "static" });
    }
  }
  return findings;
}

/**
 * BugBot & security review: static rules + LLM review on the diff, then
 * posts a review with inline comments on the PR.
 */
export class BugBot {
  async reviewDiff(diff: string, useLLM = true): Promise<Finding[]> {
    const findings = staticScan(diff);
    if (useLLM) {
      const llm = await completeJson<{ findings: Omit<Finding, "source">[] }>(
        `You are a security reviewer. Find exploitable vulnerabilities and likely runtime errors introduced by this diff. Only report concrete issues with file and new line number.\n` +
          `Return {"findings":[{"file":"","line":0,"severity":"critical|high|medium|low","rule":"short-id","message":""}]}\n\n${diff.slice(0, 60_000)}`,
        { findings: [] },
      );
      for (const f of llm.findings ?? []) if (f.file && f.line) findings.push({ ...f, source: "llm" });
    }
    const seen = new Set<string>();
    return findings.filter((f) => {
      const k = `${f.file}:${f.line}:${f.rule}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  }

  async reviewPullRequest(repo: string, prNumber: number, opts: { post?: boolean } = {}) {
    const diff = await GitHub.prDiff(repo, prNumber);
    const findings = await this.reviewDiff(diff);
    const blocking = findings.some((f) => f.severity === "critical" || f.severity === "high");
    const summary = findings.length
      ? `🤖 **BugBot** found ${findings.length} issue(s):\n\n${findings.map((f) => `- **${f.severity}** \`${f.file}:${f.line}\` ${f.message} _(${f.rule})_`).join("\n")}`
      : "🤖 **BugBot**: no security issues or runtime errors found.";
    if (opts.post !== false) {
      await GitHub.review(repo, prNumber, summary, blocking ? "REQUEST_CHANGES" : "COMMENT", findings.slice(0, 30).map((f) => ({ path: f.file, line: f.line, body: `**${f.severity}** ${f.message}` })));
    }
    Logger.success("BugBot", `Reviewed ${repo}#${prNumber}: ${findings.length} findings.`);
    return { findings, blocking, summary };
  }
}

export const bugbot = new BugBot();
