import * as http from "http";
import * as crypto from "crypto";
import * as fs from "fs";
import * as path from "path";
import { URL } from "url";
import type { AgenticOS } from "../core/engine";
import { config } from "../config";
import { bus } from "../events/bus";
import { approvals, ApprovalDecision } from "../approvals/approvals";
import { conversations } from "../search/conversationSearch";
import { CodeIndex } from "../indexing/codeIndex";
import { predictCompletion, inlineEdit, Composer, acceptEdit, EditProposal } from "../code/editing";
import { inbox } from "../proactive/inbox";
import { notifier } from "../notifications/notifier";
import { devices, Platform } from "../devices/devices";
import { voice } from "../voice/voice";
import { canvases } from "../canvas/canvas";
import { concierge } from "../connectors/telephony";
import { GitHub, Linear, Slack } from "../connectors/devtools";
import { bugbot } from "../review/bugbot";
import { vault } from "../credentials/vault";
import { teams } from "../multiagent/teams";
import { dataPath } from "../utils/fsx";
import { Logger } from "../utils/logger";

type Handler = (ctx: { req: http.IncomingMessage; res: http.ServerResponse; params: Record<string, string>; query: URLSearchParams; body: any; raw: string; deviceId?: string }) => Promise<unknown> | unknown;
interface RouteDef {
  method: string;
  pattern: RegExp;
  keys: string[];
  handler: Handler;
  public?: boolean;
}

function apiToken(): string {
  if (config.server.token) return config.server.token;
  const f = dataPath("api-token");
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(24).toString("base64url"), { mode: 0o600 });
  return fs.readFileSync(f, "utf-8").trim();
}

/** Twilio request signature: HMAC-SHA1(url + sorted key/value pairs). */
function verifyTwilio(url: string, params: Record<string, string>, signature: string | undefined): boolean {
  if (!config.twilio.token || !signature) return false;
  const data = url + Object.keys(params).sort().map((k) => k + params[k]).join("");
  const expected = crypto.createHmac("sha1", config.twilio.token).update(data).digest("base64");
  return expected.length === signature.length && crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

/**
 * Remote-control & companion API (JSON over HTTP + Server-Sent Events).
 * This is what desktop, tablet and phone companion apps, editor plugins,
 * Slack/Linear/GitHub/Twilio webhooks, and scripts talk to. No UI is served.
 */
export class ApiServer {
  private routes: RouteDef[] = [];
  private server: http.Server | null = null;
  private token = apiToken();
  private edits = new Map<string, EditProposal>();

  constructor(private os: AgenticOS) {
    this.registerRoutes();
  }

  private on(method: string, p: string, handler: Handler, isPublic = false) {
    const keys: string[] = [];
    const pattern = new RegExp("^" + p.replace(/:(\w+)/g, (_, k) => (keys.push(k), "([^/]+)")) + "/?$");
    this.routes.push({ method, pattern, keys, handler, public: isPublic });
  }

  private registerRoutes() {
    const os = this.os;
    this.on("GET", "/health", () => ({ ok: true, agents: os.agents.size, uptime: process.uptime() }), true);

    // Agents & multi-agent
    this.on("GET", "/agents", () => os.roster());
    this.on("POST", "/agents", ({ body }) => {
      const a = os.createAgent(body.name, body.role ?? "Custom", { profile: body.profile, systemPrompt: body.systemPrompt });
      return { name: a.name, role: a.role };
    });
    this.on("POST", "/agents/:name/run", async ({ params, body }) => {
      const a = os.agents.get(decodeURIComponent(params.name));
      if (!a) throw Object.assign(new Error("unknown agent"), { status: 404 });
      return { result: await a.run(body.prompt, { mode: body.mode ?? "agent", threadId: body.threadId }) };
    });
    this.on("POST", "/route", async ({ body }) => os.router.dispatch(body.prompt));
    this.on("POST", "/parallel", async ({ body }) => os.router.parallel(body.jobs, body.concurrency));
    this.on("POST", "/group", async ({ body }) => os.groupChat(body.agents).discuss(body.goal));

    // Background tasks & projects
    this.on("GET", "/tasks", ({ query }) => os.tasks.list((query.get("status") as any) ?? undefined));
    this.on("POST", "/tasks", async ({ body }) => os.tasks.enqueue({ title: body.title ?? body.goal.slice(0, 80), goal: body.goal, agent: body.agent ?? "DevBot", steps: body.steps }));
    this.on("GET", "/tasks/:id", ({ params }) => os.tasks.get(params.id));
    this.on("POST", "/tasks/:id/cancel", ({ params }) => ({ ok: os.tasks.cancel(params.id) }));
    this.on("POST", "/tasks/:id/approve", ({ params }) => ({ ok: os.tasks.approveReview(params.id) }));
    this.on("GET", "/projects", () => os.projects.list());
    this.on("POST", "/projects", async ({ body }) => os.projects.create(body.name, body.goal));

    // Approvals (human-in-the-loop)
    this.on("GET", "/approvals", ({ query }) => approvals.list((query.get("status") as any) ?? "pending"));
    this.on("POST", "/approvals/:id", ({ params, body, deviceId }) => ({ ok: approvals.resolve(params.id, body.decision as ApprovalDecision, body.payload, deviceId ?? "api") }));

    // Routines & skills
    this.on("GET", "/routines", () => os.routines.list());
    this.on("POST", "/routines", ({ body }) => os.routines.add(body));
    this.on("DELETE", "/routines/:id", ({ params }) => (os.routines.remove(params.id), { ok: true }));
    this.on("GET", "/skills", () => os.skills.list());
    this.on("POST", "/skills/record/start", ({ body }) => (os.skills.startRecording(body.name), { recording: body.name }));
    this.on("POST", "/skills/record/step", ({ body }) => (os.skills.recordStep(body), { ok: true }));
    this.on("POST", "/skills/record/stop", async ({ body }) => os.skills.stopRecording(body.paramHints ?? []));
    this.on("POST", "/skills/:name/run", async ({ params, body }) => {
      const a = os.agents.get(body.agent ?? "Orchestrator-Prime")!;
      return os.skills.run(decodeURIComponent(params.name), body.params ?? {}, { agent: a.name, profile: a.profile, role: "owner", workspace: a.workspace.root });
    });

    // Memory, search, code intelligence
    this.on("GET", "/memory/search", ({ query }) => os.memory.search(query.get("q") ?? "", { k: Number(query.get("k") ?? 10) }));
    this.on("POST", "/memory", ({ body }) => os.memory.addMemory(body.category ?? "preference", body.content));
    this.on("GET", "/conversations", () => conversations.threads().slice(0, 200));
    this.on("GET", "/conversations/search", ({ query }) => (query.get("regex") === "1" ? conversations.grep(query.get("q") ?? "") : conversations.search(query.get("q") ?? "")));
    this.on("GET", "/conversations/:id", ({ params }) => conversations.thread(params.id));
    this.on("POST", "/index", ({ body }) => new CodeIndex(path.resolve(body.root)).build());
    this.on("GET", "/index/search", ({ query }) => new CodeIndex(path.resolve(query.get("root") ?? ".")).search(query.get("q") ?? "", Number(query.get("k") ?? 8)));
    this.on("GET", "/index/symbol", ({ query }) => new CodeIndex(path.resolve(query.get("root") ?? ".")).findSymbol(query.get("name") ?? ""));
    this.on("POST", "/code/complete", ({ body }) => predictCompletion(body));
    this.on("POST", "/code/edit", async ({ body }) => {
      const p = await inlineEdit(body.file, body.instruction, body.range);
      this.edits.set(p.id, p);
      return { id: p.id, diff: p.diff, hunks: p.hunks.map((h) => ({ id: h.id, aStart: h.aStart + 1, removed: h.aLines, added: h.bLines })) };
    });
    this.on("POST", "/code/edit/:id/accept", ({ params, body }) => {
      const p = this.edits.get(params.id);
      if (!p) throw Object.assign(new Error("unknown edit"), { status: 404 });
      acceptEdit(p, body.hunks);
      this.edits.delete(params.id);
      return { ok: true };
    });
    this.on("POST", "/code/edit/:id/reject", ({ params }) => ({ ok: this.edits.delete(params.id) }));
    this.on("POST", "/composer/propose", ({ body }) => new Composer(path.resolve(body.root)).propose(body.instruction, { files: body.files }));
    this.on("POST", "/composer/:id/apply", ({ params, body }) => new Composer(path.resolve(body.root ?? ".")).apply(params.id));
    this.on("POST", "/composer/:id/rollback", ({ params, body }) => (new Composer(path.resolve(body.root ?? ".")).rollback(params.id), { ok: true }));

    // Inbox, digest, notifications
    this.on("GET", "/inbox", () => inbox.collect());
    this.on("GET", "/inbox/unread", () => inbox.unreadCount());
    this.on("POST", "/inbox/:id/read", ({ params }) => (inbox.markRead(decodeURIComponent(params.id)), { ok: true }));
    this.on("POST", "/inbox/draft", ({ body }) => inbox.draftReply(body.item, body.guidance));
    this.on("POST", "/inbox/reply", async ({ body }) => {
      const r = await approvals.request({ agent: "InboxManager", action: "messages.reply", payload: body.text });
      if (r.decision === "rejected") return { sent: false };
      await inbox.reply(body.item, r.payload ?? body.text);
      inbox.markRead(body.item.id);
      return { sent: true };
    });
    this.on("GET", "/digest", async () => ({ text: await os.digest.build() }));
    this.on("PUT", "/digest/settings", ({ body }) => os.digest.updateSettings(body));
    this.on("POST", "/heartbeat/sweep", () => os.sweepNow());
    this.on("GET", "/notifications", ({ query }) => notifier.list(query.get("unread") === "1"));
    this.on("POST", "/notifications/read", ({ body }) => (notifier.markRead(body?.id), { ok: true }));

    // Devices, sessions, voice
    this.on("POST", "/devices/pair-code", () => ({ code: devices.createPairingCode(), expiresInSec: 300 }));
    this.on("POST", "/devices/pair", ({ body }) => devices.pair(body.code, body.name, body.platform as Platform, body.capabilities), true);
    this.on("GET", "/devices", () => devices.list());
    this.on("DELETE", "/devices/:id", ({ params }) => (devices.revoke(params.id), { ok: true }));
    this.on("POST", "/devices/heartbeat", ({ body, deviceId }) => (deviceId && devices.heartbeat(deviceId, body), { ok: true }));
    this.on("GET", "/sessions", () => devices.sessions());
    this.on("POST", "/sessions", ({ body, deviceId }) => devices.openSession(body.agent, body.threadId, deviceId ?? null));
    this.on("POST", "/sessions/:id/handoff", ({ params, body }) => devices.handoff(params.id, body.device));
    this.on("POST", "/voice", async ({ req }) => {
      const file = dataPath("audio", `upload-${Date.now()}.${(req.headers["content-type"] ?? "").includes("webm") ? "webm" : (req.headers["content-type"] ?? "").includes("mpeg") ? "mp3" : "wav"}`);
      fs.writeFileSync(file, (req as any).rawBuffer as Buffer);
      const text = await voice.transcribe(file);
      return { transcript: text, ...(await os.router.dispatch(text)) };
    });

    // Vault & teams (admin)
    this.on("GET", "/vault", () => vault.list());
    this.on("POST", "/vault", ({ body }) => (vault.set(body), { ok: true }));
    this.on("DELETE", "/vault/:site", ({ params }) => (vault.remove(decodeURIComponent(params.site)), { ok: true }));
    this.on("GET", "/teams/:user/bots", ({ params }) => teams.botsFor(params.user));
    this.on("POST", "/teams/bots", ({ body }) => teams.createBot(body.name, body.role, body.ownerId, body.requiredPlan));
    this.on("POST", "/teams/bots/:id/grant", ({ params, body }) => (teams.grant(body.actorId, params.id, body.userId, body.permissions), { ok: true }));

    // Canvas share links (token in URL, no bearer)
    this.on(
      "GET",
      "/canvas/:id",
      ({ params, query, res }) => {
        const html = canvases.read(params.id, query.get("t") ?? "");
        if (!html) throw Object.assign(new Error("not found"), { status: 404 });
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Content-Security-Policy": "default-src 'self' 'unsafe-inline' data:; connect-src 'none'" });
        res.end(html);
        return undefined;
      },
      true,
    );

    // Webhooks (signature-verified, no bearer)
    this.on(
      "POST",
      "/webhooks/slack",
      async ({ req, raw, body }) => {
        if (!Slack.verify(raw, String(req.headers["x-slack-request-timestamp"]), String(req.headers["x-slack-signature"]))) throw Object.assign(new Error("bad signature"), { status: 401 });
        if (body.type === "url_verification") return { challenge: body.challenge };
        const ev = body.event;
        if (ev?.type === "app_mention" && ev.text) {
          void (async () => {
            const prompt = ev.text.replace(/<@[^>]+>/g, "").trim();
            const task = await os.tasks.enqueue({ title: `Slack: ${prompt.slice(0, 60)}`, goal: prompt, agent: (await os.router.route(prompt)).agent });
            await Slack.post(ev.channel, `On it — background task \`${task.id}\` started. I'll reply here when it's ready.`, ev.thread_ts ?? ev.ts);
            const off = bus.on("task.completed", (t) => {
              if (t.taskId !== task.id) return;
              off();
              void Slack.post(ev.channel, `Done ✅\n${t.result.slice(0, 3500)}`, ev.thread_ts ?? ev.ts);
            });
          })();
        }
        return { ok: true };
      },
      true,
    );
    this.on(
      "POST",
      "/webhooks/linear",
      async ({ req, raw, body }) => {
        if (!Linear.verifyWebhook(raw, String(req.headers["linear-signature"]))) throw Object.assign(new Error("bad signature"), { status: 401 });
        const label = (body.data?.labels ?? []).map((l: any) => l.name.toLowerCase());
        if (body.type === "Issue" && (body.action === "create" || body.action === "update") && label.includes("agent")) {
          const issue = body.data;
          const task = await os.tasks.enqueue({ title: `Linear ${issue.identifier}: ${issue.title}`, goal: `${issue.title}\n\n${issue.description ?? ""}`, agent: "DevBot" });
          await Linear.comment(issue.id, `🤖 Background agent started (task ${task.id}).`);
          const off = bus.on("task.completed", (t) => {
            if (t.taskId !== task.id) return;
            off();
            void Linear.comment(issue.id, `🤖 Ready for review:\n\n${t.result.slice(0, 5000)}`);
          });
        }
        return { ok: true };
      },
      true,
    );
    this.on(
      "POST",
      "/webhooks/github",
      async ({ req, raw, body }) => {
        if (!GitHub.verifyWebhook(raw, String(req.headers["x-hub-signature-256"]))) throw Object.assign(new Error("bad signature"), { status: 401 });
        const event = req.headers["x-github-event"];
        if (event === "pull_request" && ["opened", "synchronize", "reopened"].includes(body.action)) void bugbot.reviewPullRequest(body.repository.full_name, body.number).catch((e) => Logger.error("BugBot", e.message));
        bus.emit("trigger", { name: `github.${event}.${body.action}`, data: { repo: body.repository?.full_name, number: body.number } });
        return { ok: true };
      },
      true,
    );
    const twilioGuard = (req: http.IncomingMessage, body: Record<string, string>) => {
      const url = `${config.twilio.publicUrl}${req.url}`;
      if (!verifyTwilio(url, body, req.headers["x-twilio-signature"] as string)) throw Object.assign(new Error("bad signature"), { status: 401 });
    };
    this.on(
      "POST",
      "/webhooks/twilio/voice/:id",
      async ({ req, res, params, body }) => {
        twilioGuard(req, body);
        const twiml = await concierge.handleVoiceWebhook(params.id, body);
        res.writeHead(200, { "Content-Type": "text/xml" });
        res.end(twiml);
        return undefined;
      },
      true,
    );
    this.on(
      "POST",
      "/webhooks/twilio/status/:id",
      async ({ req, params, body }) => {
        twilioGuard(req, body);
        const c = concierge.handleStatusWebhook(params.id, body);
        if (c?.status === "completed") await notifier.send(`Call finished: ${c.business}`, c.outcome ?? "Call completed.", "high");
        return { ok: true };
      },
      true,
    );
  }

  private authorize(req: http.IncomingMessage): { ok: boolean; deviceId?: string } {
    const h = req.headers.authorization ?? "";
    const t = h.startsWith("Bearer ") ? h.slice(7) : "";
    if (!t) return { ok: false };
    if (t.length === this.token.length && crypto.timingSafeEqual(Buffer.from(t), Buffer.from(this.token))) return { ok: true };
    const dev = devices.authenticate(t);
    return dev ? { ok: true, deviceId: dev.id } : { ok: false };
  }

  private sse(req: http.IncomingMessage, res: http.ServerResponse) {
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
    res.write(`event: hello\ndata: ${JSON.stringify({ agents: this.os.roster() })}\n\n`);
    const off = bus.onAny((event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
    const ping = setInterval(() => res.write(": ping\n\n"), 25_000);
    req.on("close", () => {
      off();
      clearInterval(ping);
    });
  }

  start(port = config.server.port, host = config.server.host) {
    this.server = http.createServer(async (req, res) => {
      const url = new URL(req.url ?? "/", "http://local");
      try {
        if (url.pathname === "/events" && req.method === "GET") {
          if (!this.authorize(req).ok) throw Object.assign(new Error("unauthorized"), { status: 401 });
          return this.sse(req, res);
        }
        const route = this.routes.find((r) => r.method === req.method && r.pattern.test(url.pathname));
        if (!route) throw Object.assign(new Error("not found"), { status: 404 });
        const auth = route.public ? { ok: true } : this.authorize(req);
        if (!auth.ok) throw Object.assign(new Error("unauthorized"), { status: 401 });
        const chunks: Buffer[] = [];
        let size = 0;
        for await (const c of req) {
          size += (c as Buffer).length;
          if (size > 25 * 1024 * 1024) throw Object.assign(new Error("payload too large"), { status: 413 });
          chunks.push(c as Buffer);
        }
        const buf = Buffer.concat(chunks);
        (req as any).rawBuffer = buf;
        const raw = buf.toString("utf-8");
        const ct = req.headers["content-type"] ?? "";
        const body = ct.includes("application/json") && raw ? JSON.parse(raw) : ct.includes("x-www-form-urlencoded") ? Object.fromEntries(new URLSearchParams(raw)) : {};
        const m = url.pathname.match(route.pattern)!;
        const params = Object.fromEntries(route.keys.map((k, i) => [k, m[i + 1]]));
        const result = await route.handler({ req, res, params, query: url.searchParams, body, raw, deviceId: (auth as any).deviceId });
        if (!res.headersSent) {
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(result ?? null));
        }
      } catch (err) {
        const status = (err as any).status ?? 500;
        if (!res.headersSent) {
          res.writeHead(status, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: (err as Error).message }));
        }
        if (status >= 500) Logger.error("API", `${req.method} ${url.pathname}: ${(err as Error).message}`);
      }
    });
    this.server.listen(port, host, () => {
      Logger.success("API", `Remote-control API on http://${host}:${port} (token in ${config.server.token ? "AGENTOS_API_TOKEN" : dataPath("api-token")})`);
    });
    return this.server;
  }

  stop() {
    this.server?.close();
  }
}
