import * as fs from "fs";
import * as path from "path";
import { complete, completeJson, getLLM } from "../ai/llm";
import { applyHunks, hunks, Hunk, unifiedDiff } from "./diff";
import { CodeIndex } from "../indexing/codeIndex";
import { dataPath, uid, writeJson, readJson } from "../utils/fsx";

const stripFences = (s: string) => s.replace(/^\s*```[\w-]*\n?/, "").replace(/\n?```\s*$/, "");

/**
 * Smart tab completion engine (editor-agnostic). Given the text before and
 * after the cursor it predicts the next multi-line edit. Editors/LSP
 * plugins call this through the API (`POST /code/complete`).
 */
export async function predictCompletion(input: { file: string; prefix: string; suffix: string; recentEdits?: string[]; maxLines?: number }): Promise<{ insert: string; deleteAfter: number; nextCursorLine?: number }> {
  const res = await getLLM().chat(
    [
      { role: "system", content: "You are a code completion engine. Output ONLY the code to insert at <CURSOR>. No explanations, no fences." },
      {
        role: "user",
        content:
          `File: ${input.file}\n${input.recentEdits?.length ? `Recent edits:\n${input.recentEdits.slice(-5).join("\n---\n")}\n` : ""}` +
          `${input.prefix.slice(-6000)}<CURSOR>${input.suffix.slice(0, 2000)}\n\nPredict up to ${input.maxLines ?? 12} lines to insert at <CURSOR>.`,
      },
    ],
    { temperature: 0, maxTokens: 400 },
  );
  const insert = stripFences(res.content);
  // If the model re-typed text that already follows the cursor, mark it for deletion (edit prediction).
  let deleteAfter = 0;
  const firstSuffixLine = input.suffix.split("\n")[0];
  if (firstSuffixLine && insert.endsWith(firstSuffixLine)) deleteAfter = firstSuffixLine.length;
  const nextCursorLine = input.prefix.split("\n").length + insert.split("\n").length - 1;
  return { insert, deleteAfter, nextCursorLine };
}

export interface EditProposal {
  id: string;
  file: string;
  before: string;
  after: string;
  diff: string;
  hunks: Hunk[];
  instruction: string;
}

/** Inline edit: rewrite a line range from a natural-language instruction. */
export async function inlineEdit(file: string, instruction: string, range?: { start: number; end: number }): Promise<EditProposal> {
  const before = fs.readFileSync(file, "utf-8");
  const lines = before.split("\n");
  const s = (range?.start ?? 1) - 1;
  const e = range?.end ?? lines.length;
  const selected = lines.slice(s, e).join("\n");
  const rewritten = stripFences(
    await complete(
      `Instruction: ${instruction}\n\nFile ${path.basename(file)} lines ${s + 1}-${e}:\n${selected}\n\nReturn ONLY the rewritten lines, preserving indentation.`,
      "You are an expert programmer performing a precise in-place edit.",
    ),
  );
  const after = [...lines.slice(0, s), ...rewritten.split("\n"), ...lines.slice(e)].join("\n");
  return { id: uid("edit"), file, before, after, diff: unifiedDiff(before, after, path.basename(file)), hunks: hunks(before, after), instruction };
}

/** Accept all / some hunks of a proposal and write the file. */
export function acceptEdit(p: EditProposal, acceptedHunks?: number[]) {
  const content = acceptedHunks ? applyHunks(p.before, p.after, acceptedHunks) : p.after;
  fs.writeFileSync(p.file, content, "utf-8");
  return content;
}

export interface ComposerChange {
  file: string;
  action: "create" | "modify" | "delete";
  content?: string;
}

/**
 * Composer: plan and apply synchronised edits across many files. Changes are
 * staged, reviewed as diffs, and applied atomically with a snapshot so the
 * whole change set can be rolled back.
 */
export class Composer {
  constructor(private root: string) {}

  async propose(instruction: string, opts: { files?: string[]; useIndex?: boolean } = {}): Promise<{ id: string; changes: ComposerChange[]; diffs: string }> {
    let files = opts.files ?? [];
    if (!files.length && opts.useIndex !== false) {
      const idx = new CodeIndex(this.root);
      idx.build();
      files = [...new Set(idx.search(instruction, 8).map((r) => r.file))];
    }
    const ctx = files
      .filter((f) => fs.existsSync(path.join(this.root, f)))
      .map((f) => `<file path="${f}">\n${fs.readFileSync(path.join(this.root, f), "utf-8").slice(0, 15_000)}\n</file>`)
      .join("\n");
    const plan = await completeJson<{ changes: ComposerChange[] }>(
      `Make this change across the codebase: ${instruction}\n\n${ctx}\n\nReturn {"changes":[{"file":"relative/path","action":"create|modify|delete","content":"FULL new file content"}]}`,
      { changes: [] },
    );
    const changes = (plan.changes ?? []).filter((c) => c.file && !path.isAbsolute(c.file) && !c.file.includes(".."));
    const diffs = changes
      .map((c) => {
        const p = path.join(this.root, c.file);
        const before = fs.existsSync(p) ? fs.readFileSync(p, "utf-8") : "";
        return c.action === "delete" ? `--- a/${c.file}\n+++ /dev/null` : unifiedDiff(before, c.content ?? "", c.file);
      })
      .join("\n");
    const id = uid("cmp");
    writeJson(dataPath("composer", `${id}.json`), { root: this.root, instruction, changes });
    return { id, changes, diffs };
  }

  apply(id: string): { applied: number; snapshot: string } {
    const staged = readJson<{ root: string; changes: ComposerChange[] } | null>(dataPath("composer", `${id}.json`), null);
    if (!staged) throw new Error(`Unknown change set ${id}`);
    const snapshot: Record<string, string | null> = {};
    for (const c of staged.changes) {
      const p = path.join(staged.root, c.file);
      snapshot[c.file] = fs.existsSync(p) ? fs.readFileSync(p, "utf-8") : null;
    }
    const snapFile = dataPath("composer", `${id}.snapshot.json`);
    writeJson(snapFile, { root: staged.root, snapshot });
    try {
      for (const c of staged.changes) {
        const p = path.join(staged.root, c.file);
        if (c.action === "delete") fs.rmSync(p, { force: true });
        else {
          fs.mkdirSync(path.dirname(p), { recursive: true });
          fs.writeFileSync(p, c.content ?? "", "utf-8");
        }
      }
    } catch (err) {
      this.rollback(id);
      throw err;
    }
    return { applied: staged.changes.length, snapshot: snapFile };
  }

  rollback(id: string) {
    const s = readJson<{ root: string; snapshot: Record<string, string | null> } | null>(dataPath("composer", `${id}.snapshot.json`), null);
    if (!s) throw new Error(`No snapshot for ${id}`);
    for (const [file, content] of Object.entries(s.snapshot)) {
      const p = path.join(s.root, file);
      if (content === null) fs.rmSync(p, { force: true });
      else fs.writeFileSync(p, content, "utf-8");
    }
  }
}
