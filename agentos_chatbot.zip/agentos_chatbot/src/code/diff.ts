/**
 * Preserved code diffs: line-level Myers-style LCS diff, unified output,
 * side-by-side rendering, and per-hunk accept/reject.
 */
export type Op = { type: "equal" | "add" | "del"; text: string; a?: number; b?: number };

export interface Hunk {
  id: number;
  aStart: number;
  aLines: string[];
  bStart: number;
  bLines: string[];
  context: Op[];
}

export function diffLines(a: string, b: string): Op[] {
  const A = a.split("\n");
  const B = b.split("\n");
  const n = A.length;
  const m = B.length;
  // LCS table (fine for files up to a few thousand lines)
  const dp: Uint32Array[] = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i][j] = A[i] === B[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
  const ops: Op[] = [];
  let i = 0,
    j = 0;
  while (i < n && j < m) {
    if (A[i] === B[j]) ops.push({ type: "equal", text: A[i], a: i++, b: j++ });
    else if (dp[i + 1][j] >= dp[i][j + 1]) ops.push({ type: "del", text: A[i], a: i++ });
    else ops.push({ type: "add", text: B[j], b: j++ });
  }
  while (i < n) ops.push({ type: "del", text: A[i], a: i++ });
  while (j < m) ops.push({ type: "add", text: B[j], b: j++ });
  return ops;
}

export function hunks(a: string, b: string): Hunk[] {
  const ops = diffLines(a, b);
  const out: Hunk[] = [];
  let cur: Hunk | null = null;
  let ai = 0,
    bi = 0;
  for (const op of ops) {
    if (op.type === "equal") {
      cur = null;
      ai++;
      bi++;
      continue;
    }
    if (!cur) {
      cur = { id: out.length, aStart: ai, aLines: [], bStart: bi, bLines: [], context: [] };
      out.push(cur);
    }
    cur.context.push(op);
    if (op.type === "del") {
      cur.aLines.push(op.text);
      ai++;
    } else {
      cur.bLines.push(op.text);
      bi++;
    }
  }
  return out;
}

export function unifiedDiff(a: string, b: string, file = "file", context = 3): string {
  const ops = diffLines(a, b);
  const lines: string[] = [`--- a/${file}`, `+++ b/${file}`];
  const changed = ops.map((o, i) => (o.type !== "equal" ? i : -1)).filter((i) => i >= 0);
  if (!changed.length) return "";
  let start = 0;
  while (start < changed.length) {
    let end = start;
    while (end + 1 < changed.length && changed[end + 1] - changed[end] <= context * 2) end++;
    const from = Math.max(0, changed[start] - context);
    const to = Math.min(ops.length - 1, changed[end] + context);
    const slice = ops.slice(from, to + 1);
    const aStart = (slice.find((o) => o.a !== undefined)?.a ?? 0) + 1;
    const bStart = (slice.find((o) => o.b !== undefined)?.b ?? 0) + 1;
    const aLen = slice.filter((o) => o.type !== "add").length;
    const bLen = slice.filter((o) => o.type !== "del").length;
    lines.push(`@@ -${aStart},${aLen} +${bStart},${bLen} @@`);
    for (const o of slice) lines.push((o.type === "equal" ? " " : o.type === "add" ? "+" : "-") + o.text);
    start = end + 1;
  }
  return lines.join("\n");
}

export function sideBySide(a: string, b: string, width = 60): string {
  const pad = (s: string) => (s.length > width ? s.slice(0, width - 1) + "…" : s.padEnd(width));
  return diffLines(a, b)
    .map((o) => (o.type === "equal" ? `${pad(o.text)} │ ${o.text}` : o.type === "del" ? `${pad("- " + o.text)} │` : `${pad("")} │ + ${o.text}`))
    .join("\n");
}

/** Apply only the accepted hunks from (a -> b). Rejected hunks keep the original lines. */
export function applyHunks(a: string, b: string, accepted: number[]): string {
  const A = a.split("\n");
  const hs = hunks(a, b);
  const out: string[] = [];
  let ai = 0;
  for (const h of hs) {
    while (ai < h.aStart) out.push(A[ai++]);
    if (accepted.includes(h.id)) out.push(...h.bLines);
    else out.push(...h.aLines);
    ai += h.aLines.length;
  }
  while (ai < A.length) out.push(A[ai++]);
  return out.join("\n");
}
