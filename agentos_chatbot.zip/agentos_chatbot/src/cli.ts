#!/usr/bin/env node
import * as fs from "fs";
import * as path from "path";
import { AgenticOS } from "./core/engine";
import { ApiServer } from "./server/api";
import { approvals, ApprovalCenter } from "./approvals/approvals";
import { conversations } from "./search/conversationSearch";
import { CodeIndex } from "./indexing/codeIndex";
import { vault, CredentialVault } from "./credentials/vault";
import { bugbot } from "./review/bugbot";
import { runSandboxed } from "./security/sandbox";
import { devices } from "./devices/devices";
import { inbox } from "./proactive/inbox";
import { policy } from "./security/policy";
import { dataPath } from "./utils/fsx";
import { Logger } from "./utils/logger";
import { naturalToCron } from "./scheduler/cron";
import { installService } from "./daemon/service";
import { logoVariants } from "./media/images";
import { generateDocument } from "./documents/documents";

const HELP = `Agentic OS CLI

  agentos daemon                         Run 24/7: heartbeat, routines, tasks, API server
  agentos ask <agent> <prompt...>        Ask mode (explain only, no tools)
  agentos run <agent> <prompt...>        Agent mode (uses tools until done)
  agentos route <prompt...>              Auto-route to the best agent
  agentos group <a,b,c> <goal...>        Multi-agent group chat
  agentos task <agent> <goal...>         Queue a multi-hour background task
  agentos tasks                          List background tasks
  agentos project <name> <goal...>       Start a multi-milestone project
  agentos agents                         Roster with live status
  agentos agent:create <name> <role> [profile]
  agentos approvals                      List pending approval cards
  agentos approve|reject <id>            Resolve an approval card
  agentos routine "<schedule>" <agent> <prompt...>   e.g. "every friday morning"
  agentos routines
  agentos skill:record <name> / skill:stop / skills / skill:run <name> [k=v...]
  agentos index <dir>                    Build semantic code index
  agentos code:search <dir> <query...>   Semantic code search
  agentos search <query...>              Search all past conversations
  agentos grep <regex>                   Instant grep across conversations
  agentos memory <query...>              Search long-term memory
  agentos remember <category> <text...>  Save to long-term memory
  agentos digest                         Build the morning digest now
  agentos sweep                          Run a proactive heartbeat sweep now
  agentos inbox                          Unified unread inbox
  agentos review <diff-file|owner/repo#PR>  BugBot security review
  agentos vault:set <site> <user> <pass> | vault:list | vault:totp <secret>
  agentos pair                           Show a pairing code for a phone/tablet
  agentos devices
  agentos profiles                       Security profiles (allow/deny lists)
  agentos logo <file>                    Generate logo colour variants
  agentos doc <pdf|slides|spreadsheet|markdown> <out> <brief...>
  agentos install-service                Install as systemd/launchd/Windows service
`;

async function main() {
  const [cmd, ...args] = process.argv.slice(2);
  if (!cmd || cmd === "help" || cmd === "--help") return console.log(HELP);
  const needsOS = !["approvals", "approve", "reject", "search", "grep", "index", "code:search", "vault:set", "vault:list", "vault:totp", "pair", "devices", "profiles", "logo", "install-service"].includes(cmd);
  const os = needsOS ? new AgenticOS() : null;
  const agent = (n: string) => {
    const a = os!.agents.get(n);
    if (!a) throw new Error(`Unknown agent "${n}". Try: ${[...os!.agents.keys()].join(", ")}`);
    return a;
  };
  const out = (x: unknown) => console.log(typeof x === "string" ? x : JSON.stringify(x, null, 2));

  switch (cmd) {
    case "daemon": {
      fs.writeFileSync(dataPath("daemon.pid"), String(process.pid));
      await os!.start();
      const api = new ApiServer(os!);
      api.start();
      const shutdown = () => {
        Logger.info("Daemon", "Shutting down; tasks will resume on next start.");
        os!.stop();
        api.stop();
        process.exit(0);
      };
      process.on("SIGINT", shutdown);
      process.on("SIGTERM", shutdown);
      return;
    }
    case "ask":
      return out(await agent(args[0]).run(args.slice(1).join(" "), { mode: "ask" }));
    case "run":
      return out(await agent(args[0]).run(args.slice(1).join(" "), { mode: "agent" }));
    case "route":
      return out(await os!.router.dispatch(args.join(" ")));
    case "group":
      return out((await os!.groupChat(args[0].split(",")).discuss(args.slice(1).join(" "))).answer);
    case "task": {
      const t = await os!.tasks.enqueue({ title: args.slice(1).join(" ").slice(0, 80), goal: args.slice(1).join(" "), agent: args[0] });
      out(`Queued ${t.id} with ${t.steps.length} steps. Run "agentos daemon" to keep working while you're away.`);
      return;
    }
    case "tasks":
      return out(os!.tasks.list().map((t) => ({ id: t.id, status: t.status, title: t.title, progress: `${t.steps.filter((s) => s.status === "done").length}/${t.steps.length}` })));
    case "project":
      return out(await os!.projects.create(args[0], args.slice(1).join(" ")));
    case "agents":
      return out(os!.roster());
    case "agent:create":
      return out(os!.createAgent(args[0], (args[1] as any) ?? "Custom", { profile: args[2] }).name);
    case "approvals":
      return approvals.list("pending").forEach((c) => console.log(ApprovalCenter.render(c)));
    case "approve":
    case "reject":
      return out({ ok: approvals.resolve(args[0], cmd === "approve" ? "approved" : "rejected", undefined, "cli") });
    case "routine": {
      const expr = naturalToCron(args[0]) ?? args[0];
      return out(os!.routines.add({ name: args.slice(2).join(" ").slice(0, 60), trigger: { type: "cron", expr }, action: { kind: "task", agent: args[1], prompt: args.slice(2).join(" ") } }));
    }
    case "routines":
      return out(os!.routines.list());
    case "skill:record":
      os!.skills.startRecording(args[0]);
      console.log("Recording. Perform the task (GUI/browser/tool actions are captured). Press Enter to stop.");
      process.stdin.once("data", async () => {
        out(await os!.skills.stopRecording(args.slice(1)));
        process.exit(0);
      });
      return;
    case "skills":
      return out(os!.skills.list().map((s) => ({ name: s.name, steps: s.steps.length, params: s.params, description: s.description })));
    case "skill:run": {
      const a = agent("Orchestrator-Prime");
      const params = Object.fromEntries(args.slice(1).map((kv) => kv.split("=") as [string, string]));
      return out(await os!.skills.run(args[0], params, { agent: a.name, profile: a.profile, role: "owner", workspace: a.workspace.root }));
    }
    case "index":
      return out(new CodeIndex(path.resolve(args[0] ?? ".")).build());
    case "code:search":
      return out(new CodeIndex(path.resolve(args[0])).search(args.slice(1).join(" ")));
    case "search":
      return out(conversations.search(args.join(" ")).map((r) => `${r.ts} [${r.agent}/${r.threadId}] ${r.text.slice(0, 160)}`).join("\n"));
    case "grep":
      return out(conversations.grep(args[0]).map((r) => `${r.record.ts} [${r.record.agent}] …${r.match}…`).join("\n"));
    case "memory":
      return out(os!.memory.search(args.join(" ")).map((m) => `${m.score.toFixed(3)} [${m.category}] ${m.content}`).join("\n"));
    case "remember":
      return out(os!.memory.addMemory(args[0] as any, args.slice(1).join(" ")).id);
    case "digest":
      return out(await os!.digest.build());
    case "sweep":
      return out(await os!.sweepNow());
    case "inbox":
      return out((await inbox.collect()).map((i) => `${i.priority === "high" ? "!" : " "} [${i.channel}] ${i.from}: ${(i.subject ?? i.text).slice(0, 100)}`).join("\n") || "Inbox zero.");
    case "review": {
      const target = args[0];
      const m = target.match(/^([\w.-]+\/[\w.-]+)#(\d+)$/);
      if (m) return out((await bugbot.reviewPullRequest(m[1], Number(m[2]), { post: args.includes("--post") })).summary);
      const diff = fs.existsSync(target) ? fs.readFileSync(target, "utf-8") : (await runSandboxed("git diff HEAD", { cwd: process.cwd() })).stdout;
      return out(await bugbot.reviewDiff(diff, !args.includes("--static")));
    }
    case "vault:set":
      vault.set({ site: args[0], username: args[1], password: args[2] });
      return out("stored (encrypted)");
    case "vault:list":
      return out(vault.list());
    case "vault:totp":
      return out(CredentialVault.totp(args[0]));
    case "pair":
      return out(`Pairing code: ${devices.createPairingCode()} (valid 5 min). Use it from the companion app: POST /devices/pair`);
    case "devices":
      return out(devices.list());
    case "profiles":
      return out(policy.listProfiles());
    case "logo":
      return out(await logoVariants(path.resolve(args[0])));
    case "doc":
      return out(await generateDocument(args[0] as any, args.slice(2).join(" "), path.resolve(args[1])));
    case "install-service":
      return out(installService());
    default:
      console.log(HELP);
      process.exitCode = 1;
  }
}

main().catch((err) => {
  Logger.error("CLI", (err as Error).message);
  process.exit(1);
});
