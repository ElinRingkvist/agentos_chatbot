import * as fs from "fs";
import * as path from "path";
import { policy, OSPermission } from "../security/policy";
import { runSandboxed } from "../security/sandbox";
import { dataPath } from "../utils/fsx";
import { OpenMausBotConnector } from "../connectors/mausBot";

/**
 * OS-level access (clipboard, screen, microphone, location). Every call
 * checks that the agent's security profile was explicitly granted the
 * capability. Implemented with standard platform tools.
 */
export class OSAccess {
  constructor(private profile: string) {}

  private require(p: OSPermission) {
    if (!policy.hasOSPermission(this.profile, p)) throw new Error(`OS permission "${p}" not granted to profile ${this.profile}`);
  }

  private async sh(cmd: string, timeoutMs = 15_000) {
    const r = await runSandboxed(cmd, { cwd: process.cwd(), timeoutMs, env: { DISPLAY: process.env.DISPLAY ?? ":0", HOME: process.env.HOME ?? "" } });
    if (r.code !== 0) throw new Error(r.stderr || `failed: ${cmd}`);
    return r.stdout;
  }

  async readClipboard(): Promise<string> {
    this.require("clipboard");
    if (process.platform === "darwin") return this.sh("pbpaste");
    if (process.platform === "win32") return this.sh('powershell -NoProfile -Command "Get-Clipboard"');
    return this.sh("xclip -selection clipboard -o || wl-paste");
  }

  async writeClipboard(text: string) {
    this.require("clipboard");
    const cmd = process.platform === "darwin" ? "pbcopy" : process.platform === "win32" ? "clip" : "xclip -selection clipboard || wl-copy";
    await runSandboxed(cmd, { cwd: process.cwd(), stdin: text, env: { DISPLAY: process.env.DISPLAY ?? ":0" } });
  }

  async screenshot(): Promise<string> {
    this.require("screen");
    return OpenMausBotConnector.screenshot(dataPath("screens", `screen-${Date.now()}.png`));
  }

  /** Record N seconds of microphone audio to a WAV file (ffmpeg). */
  async recordAudio(seconds = 5): Promise<string> {
    this.require("microphone");
    const file = dataPath("audio", `mic-${Date.now()}.wav`);
    const input = process.platform === "darwin" ? '-f avfoundation -i ":0"' : process.platform === "win32" ? '-f dshow -i audio="default"' : "-f pulse -i default";
    await this.sh(`ffmpeg -y ${input} -t ${Number(seconds)} -ac 1 -ar 16000 "${file}"`, (seconds + 10) * 1000);
    return file;
  }

  /** Approximate location from IP (no GPS on servers); mobile companions can push precise location to /devices/:id/location. */
  async location(): Promise<{ lat: number; lon: number; city?: string; source: string }> {
    this.require("location");
    const last = path.join(path.dirname(dataPath("devices.json")), "last-location.json");
    if (fs.existsSync(last)) {
      const l = JSON.parse(fs.readFileSync(last, "utf-8"));
      if (Date.now() - new Date(l.ts).getTime() < 15 * 60_000) return { ...l, source: "device" };
    }
    const j: any = await (await fetch("https://ipapi.co/json/")).json();
    return { lat: j.latitude, lon: j.longitude, city: j.city, source: "ip" };
  }
}
