import * as readline from "readline";
import { bus } from "../events/bus";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";
import { I18n } from "../utils/i18n";

export type ApprovalDecision = "approved" | "rejected" | "edited";

export interface ApprovalCard {
  id: string;
  agent: string;
  action: string;
  payload: string;
  createdAt: string;
  status: "pending" | ApprovalDecision | "expired";
  resolvedAt?: string;
  resolvedBy?: string;
  finalPayload?: string;
}

type Mode = "interactive" | "api" | "auto";

/**
 * Human-in-the-loop approvals. Sensitive actions pause and produce a
 * plain-text approval card. The user can approve, reject, or edit the payload
 * before it is sent — from the terminal, the remote-control API, Slack, or a
 * phone notification action.
 */
export class ApprovalCenter {
  private file = dataPath("approvals.json");
  private waiters = new Map<string, (r: { decision: ApprovalDecision; payload?: string }) => void>();
  mode: Mode = (process.env.AGENTOS_APPROVAL_MODE as Mode) || (process.stdin.isTTY ? "interactive" : "api");
  timeoutMs = Number(process.env.AGENTOS_APPROVAL_TIMEOUT_MS) || 24 * 60 * 60 * 1000;

  private load(): ApprovalCard[] {
    return readJson<ApprovalCard[]>(this.file, []);
  }
  private save(cards: ApprovalCard[]) {
    writeJson(this.file, cards.slice(-500));
  }

  list(status?: ApprovalCard["status"]): ApprovalCard[] {
    return this.load().filter((c) => !status || c.status === status);
  }

  static render(card: ApprovalCard): string {
    const line = "─".repeat(60);
    return [
      `┌${line}`,
      `│ ${I18n.t("approvalRequired")} [${card.id}]`,
      `│ Agent:  ${card.agent}`,
      `│ Action: ${card.action}`,
      `│ ${line}`,
      ...card.payload.split("\n").map((l) => `│ ${l}`),
      `│ ${line}`,
      `│ [a]pprove   [r]eject   [e]dit`,
      `└${line}`,
    ].join("\n");
  }

  async request(input: { agent: string; action: string; payload: string }): Promise<{ decision: ApprovalDecision; payload?: string }> {
    const card: ApprovalCard = { id: uid("apr"), ...input, createdAt: new Date().toISOString(), status: "pending" };
    const cards = this.load();
    cards.push(card);
    this.save(cards);
    bus.emit("approval.requested", { id: card.id, agent: card.agent, action: card.action, payload: card.payload });
    bus.emit("notification", { title: `Approval needed: ${card.action}`, body: `${card.agent} wants to run ${card.action}`, priority: "high", effect: "loud" });

    if (this.mode === "auto") {
      Logger.warn("Approvals", `[auto mode] approving ${card.id} (${card.action})`);
      this.resolve(card.id, "approved", undefined, "auto");
      return { decision: "approved" };
    }

    const result = new Promise<{ decision: ApprovalDecision; payload?: string }>((resolve) => {
      this.waiters.set(card.id, resolve);
      setTimeout(() => {
        if (this.waiters.has(card.id)) {
          this.markExpired(card.id);
          resolve({ decision: "rejected" });
        }
      }, this.timeoutMs).unref();
    });

    if (this.mode === "interactive") void this.promptTerminal(card);
    else Logger.warn("Approvals", `Waiting for approval ${card.id} via API: POST /approvals/${card.id}`);
    return result;
  }

  resolve(id: string, decision: ApprovalDecision, payload?: string, by = "user"): boolean {
    const cards = this.load();
    const card = cards.find((c) => c.id === id);
    if (!card || card.status !== "pending") return false;
    card.status = decision;
    card.resolvedAt = new Date().toISOString();
    card.resolvedBy = by;
    card.finalPayload = payload ?? card.payload;
    this.save(cards);
    bus.emit("approval.resolved", { id, decision, payload });
    const w = this.waiters.get(id);
    this.waiters.delete(id);
    w?.({ decision, payload });
    return true;
  }

  private markExpired(id: string) {
    const cards = this.load();
    const c = cards.find((x) => x.id === id);
    if (c && c.status === "pending") {
      c.status = "expired";
      this.save(cards);
    }
    this.waiters.delete(id);
  }

  private async promptTerminal(card: ApprovalCard) {
    console.log("\n" + ApprovalCenter.render(card));
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const ask = (q: string) => new Promise<string>((r) => rl.question(q, r));
    const answer = (await ask("> ")).trim().toLowerCase();
    if (answer.startsWith("a")) this.resolve(card.id, "approved");
    else if (answer.startsWith("e")) {
      const edited = await ask("New payload (single line JSON or text): ");
      this.resolve(card.id, "edited", edited);
    } else this.resolve(card.id, "rejected");
    rl.close();
  }
}

export const approvals = new ApprovalCenter();
