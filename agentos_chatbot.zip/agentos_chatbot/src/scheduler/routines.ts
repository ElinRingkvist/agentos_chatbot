import { bus } from "../events/bus";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";
import { cronMatches, naturalToCron, nextRun, parseCron } from "./cron";

export type RoutineTrigger =
  | { type: "cron"; expr: string }
  | { type: "interval"; everyMs: number }
  | { type: "event"; name: string; filter?: Record<string, unknown> };

export interface Routine {
  id: string;
  name: string;
  trigger: RoutineTrigger;
  /** What to run: a saved skill, a free-form agent task, or a built-in job (digest, heartbeat, inbox-sweep...). */
  action: { kind: "skill"; skill: string; params?: Record<string, string> } | { kind: "task"; agent: string; prompt: string } | { kind: "job"; job: string; args?: Record<string, unknown> };
  enabled: boolean;
  lastRun?: string;
  nextRun?: string;
}

export type RoutineRunner = (r: Routine, triggerData?: unknown) => Promise<void>;

/**
 * Automated routines & cron/heartbeat scheduling. Time triggers (cron or
 * natural language like "every Friday morning"), intervals and event-driven
 * triggers (e.g. "email.received", "github.pr.opened", "trigger" bus events).
 */
export class RoutineScheduler {
  private file = dataPath("routines.json");
  private timer: NodeJS.Timeout | null = null;
  private intervals = new Map<string, NodeJS.Timeout>();
  private unsub: (() => void) | null = null;

  constructor(private runner: RoutineRunner) {}

  list(): Routine[] {
    return readJson<Routine[]>(this.file, []);
  }
  private save(r: Routine[]) {
    writeJson(this.file, r);
  }

  add(input: Omit<Routine, "id" | "enabled"> & { enabled?: boolean; schedule?: string }): Routine {
    let trigger = input.trigger;
    if (input.schedule) {
      const expr = naturalToCron(input.schedule) ?? input.schedule;
      parseCron(expr);
      trigger = { type: "cron", expr };
    }
    if (trigger.type === "cron") parseCron(trigger.expr);
    const r: Routine = { ...input, trigger, id: uid("rt"), enabled: input.enabled ?? true };
    if (trigger.type === "cron") r.nextRun = nextRun(trigger.expr).toISOString();
    const all = this.list();
    all.push(r);
    this.save(all);
    if (this.timer) this.restart();
    return r;
  }

  remove(id: string) {
    this.save(this.list().filter((r) => r.id !== id));
    if (this.timer) this.restart();
  }

  setEnabled(id: string, enabled: boolean) {
    this.save(this.list().map((r) => (r.id === id ? { ...r, enabled } : r)));
    if (this.timer) this.restart();
  }

  private async fire(r: Routine, data?: unknown) {
    Logger.info("Routines", `Running routine "${r.name}"`);
    try {
      await this.runner(r, data);
    } catch (err) {
      Logger.error("Routines", `${r.name} failed: ${(err as Error).message}`);
    }
    const all = this.list();
    const cur = all.find((x) => x.id === r.id);
    if (cur) {
      cur.lastRun = new Date().toISOString();
      if (cur.trigger.type === "cron") cur.nextRun = nextRun(cur.trigger.expr).toISOString();
      this.save(all);
    }
  }

  start() {
    this.stop();
    let lastMinute = -1;
    this.timer = setInterval(() => {
      const now = new Date();
      const minuteKey = Math.floor(now.getTime() / 60_000);
      if (minuteKey === lastMinute) return;
      lastMinute = minuteKey;
      for (const r of this.list()) if (r.enabled && r.trigger.type === "cron" && cronMatches(parseCron(r.trigger.expr), now)) void this.fire(r);
    }, 5_000);
    for (const r of this.list()) {
      if (r.enabled && r.trigger.type === "interval") this.intervals.set(r.id, setInterval(() => void this.fire(r), r.trigger.everyMs));
    }
    this.unsub = bus.onAny((event, data) => {
      for (const r of this.list()) {
        if (!r.enabled || r.trigger.type !== "event") continue;
        const t = r.trigger;
        const name = event === "trigger" ? (data as { name: string }).name : event;
        if (name !== t.name) continue;
        const payload = event === "trigger" ? (data as { data?: unknown }).data : data;
        if (t.filter && !Object.entries(t.filter).every(([k, v]) => (payload as Record<string, unknown>)?.[k] === v)) continue;
        void this.fire(r, payload);
      }
    });
  }

  private restart() {
    this.start();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.intervals.forEach((t) => clearInterval(t));
    this.intervals.clear();
    this.unsub?.();
    this.unsub = null;
  }
}
