/**
 * Dependency-free 5-field cron parser: "min hour day-of-month month day-of-week".
 * Supports *, lists (1,2), ranges (1-5), steps (*\/15, 1-30/5), names (MON, JAN)
 * and aliases (@hourly, @daily, @weekly, @monthly, @yearly).
 */
const ALIASES: Record<string, string> = {
  "@yearly": "0 0 1 1 *",
  "@annually": "0 0 1 1 *",
  "@monthly": "0 0 1 * *",
  "@weekly": "0 0 * * 0",
  "@daily": "0 0 * * *",
  "@midnight": "0 0 * * *",
  "@hourly": "0 * * * *",
};
const DOW = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
const MON = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

export interface CronSpec {
  minute: Set<number>;
  hour: Set<number>;
  dom: Set<number>;
  month: Set<number>;
  dow: Set<number>;
  domStar: boolean;
  dowStar: boolean;
}

function parseField(field: string, min: number, max: number, names?: string[]): Set<number> {
  const out = new Set<number>();
  for (const part of field.split(",")) {
    const [rangePart, stepPart] = part.split("/");
    const step = stepPart ? parseInt(stepPart, 10) : 1;
    if (!Number.isFinite(step) || step < 1) throw new Error(`Bad step in "${field}"`);
    const val = (s: string) => {
      const idx = names?.indexOf(s.toUpperCase()) ?? -1;
      const n = idx >= 0 ? idx + (min === 1 ? 1 : 0) : parseInt(s, 10);
      if (!Number.isFinite(n)) throw new Error(`Bad value "${s}" in "${field}"`);
      return n;
    };
    let lo: number, hi: number;
    if (rangePart === "*") [lo, hi] = [min, max];
    else if (rangePart.includes("-")) [lo, hi] = rangePart.split("-").map(val) as [number, number];
    else {
      lo = val(rangePart);
      hi = stepPart ? max : lo;
    }
    if (lo < min || hi > max || lo > hi) throw new Error(`Out of range "${field}" (${min}-${max})`);
    for (let i = lo; i <= hi; i += step) out.add(i);
  }
  return out;
}

export function parseCron(expr: string): CronSpec {
  const e = ALIASES[expr.trim()] ?? expr.trim();
  const f = e.split(/\s+/);
  if (f.length !== 5) throw new Error(`Cron needs 5 fields: "${expr}"`);
  const dow = parseField(f[4], 0, 7, DOW);
  if (dow.has(7)) {
    dow.delete(7);
    dow.add(0);
  }
  return {
    minute: parseField(f[0], 0, 59),
    hour: parseField(f[1], 0, 23),
    dom: parseField(f[2], 1, 31),
    month: parseField(f[3], 1, 12, MON),
    dow,
    domStar: f[2] === "*",
    dowStar: f[4] === "*",
  };
}

export function cronMatches(spec: CronSpec, d: Date): boolean {
  if (!spec.minute.has(d.getMinutes()) || !spec.hour.has(d.getHours()) || !spec.month.has(d.getMonth() + 1)) return false;
  const domOk = spec.dom.has(d.getDate());
  const dowOk = spec.dow.has(d.getDay());
  // Vixie-cron semantics: if both restricted, either may match.
  if (!spec.domStar && !spec.dowStar) return domOk || dowOk;
  return domOk && dowOk;
}

/** Next fire time strictly after `from` (local time). */
export function nextRun(expr: string, from = new Date()): Date {
  const spec = parseCron(expr);
  const d = new Date(from.getTime());
  d.setSeconds(0, 0);
  d.setMinutes(d.getMinutes() + 1);
  for (let i = 0; i < 366 * 24 * 60; i++) {
    if (cronMatches(spec, d)) return d;
    d.setMinutes(d.getMinutes() + 1);
  }
  throw new Error(`No run time within a year for "${expr}"`);
}

/** Natural-language schedule helper: "every friday morning", "every day at 7:30", "every 15 minutes". */
export function naturalToCron(text: string): string | null {
  const t = text.toLowerCase().trim();
  const days: Record<string, number> = { sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6, söndag: 0, måndag: 1, tisdag: 2, onsdag: 3, torsdag: 4, fredag: 5, lördag: 6 };
  const parts: Record<string, [number, number]> = { morning: [8, 0], morgon: [8, 0], noon: [12, 0], afternoon: [14, 0], evening: [18, 0], kväll: [18, 0], night: [22, 0] };
  let m = t.match(/every (\d+) (minute|minutes|hour|hours)/);
  if (m) return m[2].startsWith("minute") ? `*/${m[1]} * * * *` : `0 */${m[1]} * * *`;
  let hour = 9,
    minute = 0;
  m = t.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
  if (m) {
    hour = parseInt(m[1], 10) % 24;
    minute = m[2] ? parseInt(m[2], 10) : 0;
    if (m[3] === "pm" && hour < 12) hour += 12;
    if (m[3] === "am" && hour === 12) hour = 0;
  } else
    for (const [k, v] of Object.entries(parts))
      if (t.includes(k)) {
        [hour, minute] = v;
        break;
      }
  for (const [name, n] of Object.entries(days)) if (t.includes(name)) return `${minute} ${hour} * * ${n}`;
  if (/weekday|vardag/.test(t)) return `${minute} ${hour} * * 1-5`;
  if (/every (day|morning|evening|night)|daily|varje dag/.test(t)) return `${minute} ${hour} * * *`;
  if (/every hour|hourly/.test(t)) return "0 * * * *";
  if (/every month|monthly/.test(t)) return `${minute} ${hour} 1 * *`;
  return null;
}
