/** Small JSON HTTP helper used by every connector. */
export async function api<T = any>(
  url: string,
  opts: { method?: string; token?: string; body?: unknown; headers?: Record<string, string>; form?: Record<string, string>; basic?: [string, string] } = {},
): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json", ...(opts.headers ?? {}) };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  if (opts.basic) headers.Authorization = `Basic ${Buffer.from(`${opts.basic[0]}:${opts.basic[1]}`).toString("base64")}`;
  let body: string | undefined;
  if (opts.form) {
    headers["Content-Type"] = "application/x-www-form-urlencoded";
    body = new URLSearchParams(opts.form).toString();
  } else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  const res = await fetch(url, { method: opts.method ?? (body ? "POST" : "GET"), headers, body, signal: AbortSignal.timeout(30_000) });
  const text = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}: ${text.slice(0, 300)}`);
  try {
    return JSON.parse(text) as T;
  } catch {
    return text as unknown as T;
  }
}

export function requireConfig(name: string, ...values: (string | undefined)[]) {
  if (values.some((v) => !v)) throw new Error(`${name} is not configured. See .env.example.`);
}
