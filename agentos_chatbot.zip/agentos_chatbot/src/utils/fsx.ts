import * as fs from "fs";
import * as path from "path";
import * as crypto from "crypto";
import { config } from "../config";

/** Absolute path inside the AgentOS data directory; parent dirs are created. */
export function dataPath(...parts: string[]): string {
  const p = path.join(config.home, ...parts);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  return p;
}

export function readJson<T>(file: string, fallback: T): T {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf-8")) as T;
  } catch {
    return fallback;
  }
}

/** Atomic write: write a temp file then rename, so a crash never leaves half a file. */
export function writeJson(file: string, data: unknown): void {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf-8");
  fs.renameSync(tmp, file);
}

export function appendJsonl(file: string, row: unknown): void {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.appendFileSync(file, JSON.stringify(row) + "\n", "utf-8");
}

export function readJsonl<T>(file: string): T[] {
  if (!fs.existsSync(file)) return [];
  return fs
    .readFileSync(file, "utf-8")
    .split("\n")
    .filter(Boolean)
    .flatMap((l) => {
      try {
        return [JSON.parse(l) as T];
      } catch {
        return [];
      }
    });
}

export function uid(prefix = "id"): string {
  return `${prefix}_${Date.now().toString(36)}${crypto.randomBytes(4).toString("hex")}`;
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Resolve `target` inside `root`, refusing any path that escapes it (../, symlink-free check). */
export function safeJoin(root: string, target: string): string {
  const resolved = path.resolve(root, target);
  const rel = path.relative(root, resolved);
  if (rel.startsWith("..") || path.isAbsolute(rel)) {
    throw new Error(`Path escapes workspace: ${target}`);
  }
  return resolved;
}

export function walkFiles(root: string, opts: { ignore?: RegExp; maxFiles?: number } = {}): string[] {
  const ignore = opts.ignore ?? /(^|[\\/])(node_modules|\.git|dist|build|\.next|\.agentos|coverage)([\\/]|$)/;
  const out: string[] = [];
  const stack = [root];
  while (stack.length && out.length < (opts.maxFiles ?? 50_000)) {
    const dir = stack.pop()!;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (ignore.test(path.relative(root, full))) continue;
      if (e.isDirectory()) stack.push(full);
      else if (e.isFile()) out.push(full);
    }
  }
  return out;
}

/**
 * Load an optional dependency at runtime. Keeps the core install tiny: heavy
 * integrations (Playwright, nodemailer, imapflow, pdf-parse, sharp) are only
 * required when the feature is used.
 */
export function optionalRequire<T = any>(name: string): T {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    return require(name) as T;
  } catch {
    throw new Error(`Optional dependency "${name}" is not installed. Run: npm install ${name}`);
  }
}
