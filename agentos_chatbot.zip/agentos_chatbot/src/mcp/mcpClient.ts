import { spawn, ChildProcessWithoutNullStreams } from "child_process";
import { tools } from "../tools/registry";
import { Logger } from "../utils/logger";
import { dataPath, readJson } from "../utils/fsx";

export interface MCPServerConfig {
  name: string;
  /** stdio transport */
  command?: string;
  args?: string[];
  env?: Record<string, string>;
  /** Streamable HTTP transport */
  url?: string;
  headers?: Record<string, string>;
}

/**
 * Model Context Protocol client (JSON-RPC 2.0 over stdio or streamable HTTP).
 * Connects external tools, database schemas and enterprise skills; every MCP
 * tool is registered as `mcp.<server>.<tool>` and goes through the security policy.
 * Servers are configured in `.agentos/mcp.json` (same shape as Claude/Cursor configs).
 */
export class MCPClient {
  private proc: ChildProcessWithoutNullStreams | null = null;
  private nextId = 1;
  private pending = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void }>();
  private buffer = "";
  private sessionId?: string;

  constructor(public readonly cfg: MCPServerConfig) {}

  async connect() {
    if (this.cfg.command) {
      this.proc = spawn(this.cfg.command, this.cfg.args ?? [], { env: { ...process.env, ...(this.cfg.env ?? {}) }, stdio: ["pipe", "pipe", "pipe"] });
      this.proc.stdout.on("data", (d) => this.onData(d.toString()));
      this.proc.stderr.on("data", (d) => Logger.info(`MCP:${this.cfg.name}`, d.toString().trim().slice(0, 300)));
      this.proc.on("exit", () => this.pending.forEach((p) => p.reject(new Error("MCP server exited"))));
    }
    await this.request("initialize", { protocolVersion: "2025-06-18", capabilities: {}, clientInfo: { name: "agentic-os", version: "1.2.0" } });
    await this.notify("notifications/initialized", {});
    return this;
  }

  private onData(chunk: string) {
    this.buffer += chunk;
    let i: number;
    while ((i = this.buffer.indexOf("\n")) >= 0) {
      const line = this.buffer.slice(0, i).trim();
      this.buffer = this.buffer.slice(i + 1);
      if (!line) continue;
      try {
        this.handle(JSON.parse(line));
      } catch {
        /* non-JSON log line */
      }
    }
  }

  private handle(msg: any) {
    if (msg.id !== undefined && this.pending.has(msg.id)) {
      const p = this.pending.get(msg.id)!;
      this.pending.delete(msg.id);
      msg.error ? p.reject(new Error(msg.error.message)) : p.resolve(msg.result);
    }
  }

  private async http(body: unknown): Promise<any> {
    const res = await fetch(this.cfg.url!, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json, text/event-stream", ...(this.cfg.headers ?? {}), ...(this.sessionId ? { "Mcp-Session-Id": this.sessionId } : {}) },
      body: JSON.stringify(body),
    });
    this.sessionId = res.headers.get("mcp-session-id") ?? this.sessionId;
    const text = await res.text();
    if (res.headers.get("content-type")?.includes("text/event-stream")) {
      const data = text
        .split("\n")
        .filter((l) => l.startsWith("data:"))
        .map((l) => l.slice(5).trim());
      return data.length ? JSON.parse(data[data.length - 1]) : null;
    }
    return text ? JSON.parse(text) : null;
  }

  request(method: string, params: unknown): Promise<any> {
    const id = this.nextId++;
    const msg = { jsonrpc: "2.0", id, method, params };
    if (this.cfg.url) {
      return this.http(msg).then((r) => {
        if (r?.error) throw new Error(r.error.message);
        return r?.result;
      });
    }
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.proc!.stdin.write(JSON.stringify(msg) + "\n");
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`MCP ${method} timed out`));
        }
      }, 60_000).unref();
    });
  }

  async notify(method: string, params: unknown) {
    const msg = { jsonrpc: "2.0", method, params };
    if (this.cfg.url) await this.http(msg).catch(() => undefined);
    else this.proc!.stdin.write(JSON.stringify(msg) + "\n");
  }

  async listTools(): Promise<{ name: string; description?: string; inputSchema: Record<string, unknown> }[]> {
    return (await this.request("tools/list", {}))?.tools ?? [];
  }

  async callTool(name: string, args: Record<string, unknown>) {
    const r = await this.request("tools/call", { name, arguments: args });
    return (r?.content ?? []).map((c: any) => (c.type === "text" ? c.text : c)).join("\n");
  }

  async listResources() {
    return (await this.request("resources/list", {}))?.resources ?? [];
  }

  async readResource(uri: string) {
    return this.request("resources/read", { uri });
  }

  /** Register every remote tool into the AgentOS tool registry. */
  async registerTools() {
    const list = await this.listTools();
    for (const t of list) {
      tools.register({
        name: `mcp.${this.cfg.name}.${t.name}`,
        description: `[MCP ${this.cfg.name}] ${t.description ?? t.name}`,
        parameters: t.inputSchema ?? { type: "object", properties: {} },
        run: (args) => this.callTool(t.name, args),
      });
    }
    Logger.success("MCP", `Connected ${this.cfg.name}: ${list.length} tools.`);
    return list.length;
  }

  close() {
    this.proc?.kill();
  }
}

export async function connectConfiguredMCPServers(): Promise<MCPClient[]> {
  const cfg = readJson<{ mcpServers?: Record<string, Omit<MCPServerConfig, "name">> }>(dataPath("mcp.json"), {});
  const clients: MCPClient[] = [];
  for (const [name, c] of Object.entries(cfg.mcpServers ?? {})) {
    try {
      const client = await new MCPClient({ name, ...c }).connect();
      await client.registerTools();
      clients.push(client);
    } catch (err) {
      Logger.error("MCP", `Failed to connect ${name}: ${(err as Error).message}`);
    }
  }
  return clients;
}
