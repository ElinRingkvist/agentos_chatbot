import * as path from "path";
import { PersistentMemory } from "./memory";
import { Agent, AgentRole, AgentOptions } from "./agent";
import { ProactiveHeartbeat } from "../proactive/heartbeat";
import { MorningDigest } from "../proactive/digest";
import { Logger } from "../utils/logger";
import { I18n, SupportedLanguage } from "../utils/i18n";
import { approvals } from "../approvals/approvals";
import { registerBuiltinTools } from "../tools/builtin";
import { registerIntegrationTools } from "../tools/integrations";
import { TaskQueue } from "../tasks/taskQueue";
import { RoutineScheduler, Routine } from "../scheduler/routines";
import { skills } from "../skills/skills";
import { AgentRouter } from "../multiagent/router";
import { GroupChat } from "../multiagent/groupChat";
import { ProjectOrchestrator } from "../projects/orchestrator";
import { connectConfiguredMCPServers, MCPClient } from "../mcp/mcpClient";
import { devices } from "../devices/devices";
import { dataPath, readJson, writeJson } from "../utils/fsx";
import { config } from "../config";

interface AgentDef {
  name: string;
  role: AgentRole;
  opts?: AgentOptions;
}

/**
 * The Agentic OS kernel: wires memory, agents, tools, security, background
 * tasks, routines, proactive heartbeat, digest, projects and MCP together.
 */
export class AgenticOS {
  public memory: PersistentMemory;
  public agents: Map<string, Agent> = new Map();
  public tasks: TaskQueue;
  public routines: RoutineScheduler;
  public router: AgentRouter;
  public projects: ProjectOrchestrator;
  public digest: MorningDigest;
  public skills = skills;
  private heartbeat: ProactiveHeartbeat;
  private mcp: MCPClient[] = [];
  private timers: NodeJS.Timeout[] = [];
  private agentsFile = dataPath("agents.json");

  constructor(lang: SupportedLanguage = (config.language as SupportedLanguage) ?? "sv") {
    I18n.setLanguage(lang);
    this.memory = new PersistentMemory();
    registerBuiltinTools(this.memory);
    registerIntegrationTools();

    const defaults: AgentDef[] = [
      { name: "Orchestrator-Prime", role: "Orchestrator" },
      { name: "WebResearcher", role: "ResearchAgent" },
      { name: "DevBot", role: "CodeEngineer" },
      { name: "InboxManager", role: "InboxManager" },
      { name: "Concierge", role: "VoiceConcierge" },
      { name: "BugBot", role: "SecurityReviewer" },
    ];
    for (const d of [...defaults, ...readJson<AgentDef[]>(this.agentsFile, [])]) this.agents.set(d.name, new Agent(d.name, d.role, this.memory, d.opts));

    this.tasks = new TaskQueue(() => this.agents);
    this.router = new AgentRouter(() => this.agents);
    this.projects = new ProjectOrchestrator(this.tasks, () => [...this.agents.keys()]);
    this.digest = new MorningDigest(this.memory, this.tasks);
    this.heartbeat = new ProactiveHeartbeat(this.memory, this.agents.get("Orchestrator-Prime")!);
    this.routines = new RoutineScheduler((r, data) => this.runRoutine(r, data));
  }

  /** Spin up a new dedicated agent (persisted), e.g. "Talent Scout", "Expense Manager". */
  createAgent(name: string, role: AgentRole, opts: AgentOptions = {}): Agent {
    if (this.agents.has(name)) throw new Error(`Agent ${name} already exists`);
    const a = new Agent(name, role, this.memory, opts);
    this.agents.set(name, a);
    writeJson(this.agentsFile, [...readJson<AgentDef[]>(this.agentsFile, []), { name, role, opts }]);
    return a;
  }

  roster() {
    return [...this.agents.values()].map((a) => ({ name: a.name, role: a.role, status: a.status, detail: a.statusDetail, profile: a.profile, workspace: a.workspace.root }));
  }

  groupChat(agentNames: string[]) {
    return new GroupChat(agentNames.map((n) => this.agents.get(n)).filter((a): a is Agent => !!a));
  }

  private async runRoutine(r: Routine, data?: unknown) {
    const a = r.action;
    if (a.kind === "task") {
      const agent = this.agents.get(a.agent);
      if (agent) await agent.run(`${a.prompt}${data ? `\n\nTrigger data:\n${JSON.stringify(data).slice(0, 4000)}` : ""}`);
    } else if (a.kind === "skill") {
      const agent = this.agents.get("Orchestrator-Prime")!;
      await this.skills.run(a.skill, a.params ?? {}, { agent: agent.name, profile: agent.profile, role: "owner", workspace: agent.workspace.root });
    } else if (a.job === "digest") await this.digest.deliver();
    else if (a.job === "heartbeat") await this.heartbeat.runBackgroundSweep();
    else if (a.job === "index") {
      const { CodeIndex } = await import("../indexing/codeIndex");
      new CodeIndex(path.resolve(String(a.args?.root ?? process.cwd()))).build();
    }
  }

  private ensureDefaultRoutines() {
    const existing = this.routines.list();
    if (!existing.some((r) => r.action.kind === "job" && r.action.job === "digest"))
      this.routines.add({ name: "Morning digest", trigger: { type: "cron", expr: this.digest.cronExpr() }, action: { kind: "job", job: "digest" } });
  }

  public async requestHumanApproval(actionDescription: string, agent = "System"): Promise<boolean> {
    const r = await approvals.request({ agent, action: "workflow.step", payload: actionDescription });
    return r.decision !== "rejected";
  }

  public async executeMultiAgentWorkflow(workflowName: string, tasks: { agentName: string; task: string; useWeb?: boolean }[]) {
    Logger.info("Workflow", `Executing Multi-Agent Workflow: ${workflowName}`);
    for (const item of tasks) {
      const agent = this.agents.get(item.agentName);
      if (!agent) continue;
      const approved = await this.requestHumanApproval(`Allow ${agent.name} to execute: ${item.task}`, agent.name);
      if (approved) {
        const res = await agent.executeTask(item.task, item.useWeb || false);
        Logger.success("Workflow", res);
      }
    }
  }

  /** Start background services: heartbeat, routines, task resume, MCP, device presence. */
  public async start(opts: { heartbeatMs?: number; mcp?: boolean } = {}) {
    Logger.success("System", `Agentic OS Engine initialized successfully [Language: ${I18n.getLanguage().toUpperCase()}].`);
    this.heartbeat.startHeartbeat(opts.heartbeatMs ?? config.heartbeat.intervalMs);
    this.ensureDefaultRoutines();
    this.routines.start();
    this.tasks.resume();
    this.timers.push(devices.startPresenceMonitor());
    if (opts.mcp !== false) this.mcp = await connectConfiguredMCPServers();
  }

  public stop() {
    this.heartbeat.stopHeartbeat();
    this.routines.stop();
    this.timers.forEach((t) => clearInterval(t));
    this.mcp.forEach((m) => m.close());
  }

  public sweepNow() {
    return this.heartbeat.runBackgroundSweep();
  }
}
