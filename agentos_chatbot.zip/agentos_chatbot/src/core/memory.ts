import * as fs from "fs";
import * as path from "path";
import { Logger } from "../utils/logger";
import { I18n } from "../utils/i18n";
import { cosine, embed } from "../ai/embeddings";

export type MemoryCategory =
  | "preference"
  | "code_context"
  | "history"
  | "skill"
  | "profile"
  | "file"
  | "communication"
  | "browser_session"
  | "business";

export interface MemoryEntry {
  id: string;
  category: MemoryCategory;
  content: string;
  timestamp: string;
  agent?: string;
  tags?: string[];
  /** How many times this memory was recalled; used to rank compounding memories. */
  hits?: number;
}

/**
 * Compounding long-term memory. Keeps every task, preference, uploaded file
 * note and browser session across chats, and supports semantic + keyword
 * search. Backwards compatible with the original `.agent_memory.json` file.
 */
export class PersistentMemory {
  private memoryFilePath: string;
  private entries: MemoryEntry[] = [];
  private vectors = new Map<string, Float32Array>();

  constructor(filePath: string = process.env.AGENTOS_MEMORY_FILE ?? path.join(process.cwd(), ".agent_memory.json")) {
    this.memoryFilePath = filePath;
    this.loadMemory();
  }

  private loadMemory() {
    if (fs.existsSync(this.memoryFilePath)) {
      try {
        const raw = fs.readFileSync(this.memoryFilePath, "utf-8");
        this.entries = JSON.parse(raw);
        Logger.info("Memory", `${I18n.t("memoryLoaded")} (${this.entries.length} items)`);
      } catch (err) {
        Logger.error("Memory", "Failed to parse persistent memory file.");
      }
    } else {
      this.entries = [
        {
          id: "init-1",
          category: "preference",
          content: "User prefers offline-first, multi-language execution with local GUI automation and HuggingFace LLMs.",
          timestamp: new Date().toISOString(),
        },
      ];
      this.saveMemory();
    }
  }

  public saveMemory() {
    const tmp = `${this.memoryFilePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.entries, null, 2), "utf-8");
    fs.renameSync(tmp, this.memoryFilePath);
  }

  public addMemory(category: MemoryCategory, content: string, extra: Partial<Pick<MemoryEntry, "agent" | "tags">> = {}): MemoryEntry {
    const entry: MemoryEntry = { id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, category, content, timestamp: new Date().toISOString(), ...extra };
    this.entries.push(entry);
    this.saveMemory();
    Logger.success("Memory", `Added persistent record [${category}]: ${content.slice(0, 120)}`);
    return entry;
  }

  public remove(id: string): boolean {
    const before = this.entries.length;
    this.entries = this.entries.filter((e) => e.id !== id);
    this.vectors.delete(id);
    if (this.entries.length !== before) this.saveMemory();
    return this.entries.length !== before;
  }

  public all(category?: MemoryCategory): MemoryEntry[] {
    return this.entries.filter((e) => !category || e.category === category);
  }

  private vec(e: MemoryEntry) {
    let v = this.vectors.get(e.id);
    if (!v) {
      v = embed(e.content);
      this.vectors.set(e.id, v);
    }
    return v;
  }

  /** Hybrid semantic + keyword search with a small recency boost. */
  public search(query: string, opts: { k?: number; category?: MemoryCategory; agent?: string } = {}): (MemoryEntry & { score: number })[] {
    const q = embed(query);
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    const now = Date.now();
    const scored = this.entries
      .filter((e) => (!opts.category || e.category === opts.category) && (!opts.agent || !e.agent || e.agent === opts.agent))
      .map((e) => {
        const kw = terms.filter((t) => e.content.toLowerCase().includes(t)).length / (terms.length || 1);
        const ageDays = (now - new Date(e.timestamp).getTime()) / 86_400_000;
        const recency = 1 / (1 + ageDays / 30);
        return { ...e, score: cosine(q, this.vec(e)) * 0.6 + kw * 0.3 + recency * 0.1 + Math.min(e.hits ?? 0, 10) * 0.005 };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, opts.k ?? 8);
    for (const s of scored) {
      const e = this.entries.find((x) => x.id === s.id);
      if (e) e.hits = (e.hits ?? 0) + 1;
    }
    return scored;
  }

  /** Context block for prompts: profile + preferences + most relevant memories. */
  public buildContext(query: string, k = 8): string {
    const pinned = this.entries.filter((e) => e.category === "preference" || e.category === "profile" || e.category === "business").slice(-10);
    const relevant = this.search(query, { k }).filter((e) => !pinned.some((p) => p.id === e.id));
    return [...pinned, ...relevant].map((e) => `[${e.category.toUpperCase()}] ${e.content}`).join("\n");
  }

  public getContextDump(): string {
    return this.entries.map((e) => `[${e.category.toUpperCase()}] ${e.content}`).join("\n");
  }
}
