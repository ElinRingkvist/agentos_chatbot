import { Logger } from "../utils/logger";
import { PersistentMemory } from "./memory";
import { WebSearchEngine, SearchResult } from "../search/webSearch";
import { I18n } from "../utils/i18n";
import { ChatMessage, getLLM } from "../ai/llm";
import { tools as registry, ToolRegistry } from "../tools/registry";
import { bus, AgentStatus } from "../events/bus";
import { conversations } from "../search/conversationSearch";
import { workspaceFor, AgentWorkspace } from "../workspace/workspace";
import { IdentityRole } from "../security/policy";
import { buildAnchoredPrompt, parseMentions } from "../context/anchors";
import { uid } from "../utils/fsx";

export type AgentRole =
  | "Orchestrator"
  | "CodeEngineer"
  | "ResearchAgent"
  | "InboxManager"
  | "TalentScout"
  | "ExpenseManager"
  | "VoiceConcierge"
  | "SecurityReviewer"
  | "Custom";

/** "ask" = answer/explain only, no tools. "agent" = plan, call tools, iterate until done. */
export type AgentMode = "ask" | "agent";

export interface AgentOptions {
  profile?: string;
  systemPrompt?: string;
  skills?: string[];
  maxSteps?: number;
  owner?: string;
}

const ROLE_PROMPTS: Record<AgentRole, string> = {
  Orchestrator: "You coordinate other agents, break work into steps and assign them. Be concise.",
  CodeEngineer: "You are a senior software engineer. You read, write, test and debug code in your workspace using tools until the task is complete.",
  ResearchAgent: "You research topics on the web, cite sources as [n] with URLs, and summarise findings.",
  InboxManager: "You triage email and messages, draft replies, and flag what needs the user's attention.",
  TalentScout: "You source and evaluate candidates against role requirements and summarise fit.",
  ExpenseManager: "You categorise expenses, reconcile receipts and flag anomalies.",
  VoiceConcierge: "You plan and place phone calls on the user's behalf, following a clear script and confirming outcomes.",
  SecurityReviewer: "You review code changes for exploitable vulnerabilities and runtime errors.",
  Custom: "You are a helpful autonomous agent.",
};

const DEFAULT_PROFILE: Record<AgentRole, string> = {
  Orchestrator: "admin",
  CodeEngineer: "developer",
  ResearchAgent: "readonly",
  InboxManager: "assistant",
  TalentScout: "assistant",
  ExpenseManager: "assistant",
  VoiceConcierge: "assistant",
  SecurityReviewer: "readonly",
  Custom: "assistant",
};

export class Agent {
  public name: string;
  public role: AgentRole;
  public status: AgentStatus = "Idle";
  public statusDetail = "";
  public profile: string;
  public readonly workspace: AgentWorkspace;
  private memory: PersistentMemory;
  private opts: AgentOptions;
  private registry: ToolRegistry;

  constructor(name: string, role: AgentRole, memory: PersistentMemory, opts: AgentOptions = {}, toolRegistry: ToolRegistry = registry) {
    this.name = name;
    this.role = role;
    this.memory = memory;
    this.opts = opts;
    this.profile = opts.profile ?? DEFAULT_PROFILE[role];
    this.registry = toolRegistry;
    this.workspace = workspaceFor(name);
  }

  setStatus(status: AgentStatus, detail = "", taskId?: string) {
    this.status = status;
    this.statusDetail = detail;
    bus.emit("agent.status", { agent: this.name, status, detail, taskId });
  }

  private systemPrompt(mode: AgentMode, query: string): string {
    return [
      this.opts.systemPrompt ?? ROLE_PROMPTS[this.role],
      `Your name is ${this.name}. Reply in the user's language (current UI language: ${I18n.getLanguage()}).`,
      mode === "ask" ? "ASK MODE: explain and answer only. Do not take actions." : "AGENT MODE: use tools to act. When finished, reply with a final summary starting with 'DONE:'.",
      this.opts.skills?.length ? `Available skills: ${this.opts.skills.join(", ")}` : "",
      "Shared memory and user context:\n" + this.memory.buildContext(query),
    ]
      .filter(Boolean)
      .join("\n\n");
  }

  /** Backwards-compatible entry point used by the original engine. */
  public async executeTask(taskDescription: string, useWebSearch: boolean = false): Promise<string> {
    let prompt = taskDescription;
    let searchData: SearchResult[] = [];
    if (useWebSearch || /\b(search|sök|buscar|recherche|suche)\b/i.test(taskDescription)) {
      searchData = await WebSearchEngine.search(taskDescription, "Google");
      prompt += "\n\nWeb results:\n" + searchData.map((r, i) => `[${i + 1}] ${r.title} (${r.url}) — ${r.snippet}`).join("\n");
    }
    const answer = await this.run(prompt, { mode: "agent" });
    return `${I18n.t("taskCompleted")} (${this.name}). ${answer}`;
  }

  /**
   * Tool-using agent loop. Stops when the model replies without tool calls,
   * or after maxSteps. Every turn is stored in the searchable conversation log.
   */
  public async run(input: string, opts: { mode?: AgentMode; threadId?: string; role?: IdentityRole; history?: ChatMessage[]; taskId?: string } = {}): Promise<string> {
    const mode = opts.mode ?? "agent";
    const threadId = opts.threadId ?? uid("thr");
    const { prompt, anchors } = parseMentions(input, this.workspace.root);
    const userPrompt = anchors.length ? await buildAnchoredPrompt(prompt, anchors) : prompt;

    this.setStatus("Working", input.slice(0, 80), opts.taskId);
    Logger.agent(this.name, `Starting task: "${input.slice(0, 120)}"`);
    conversations.add({ threadId, agent: this.name, role: "user", text: input });

    const messages: ChatMessage[] = [{ role: "system", content: this.systemPrompt(mode, prompt) }, ...(opts.history ?? []), { role: "user", content: userPrompt }];
    const specs = mode === "agent" ? this.registry.specsFor(this.profile, opts.role) : [];
    const llm = getLLM();
    let final = "";
    try {
      for (let step = 0; step < (this.opts.maxSteps ?? 12); step++) {
        const res = await llm.chat(messages, { tools: specs });
        if (!res.toolCalls.length) {
          final = res.content;
          break;
        }
        messages.push({ role: "assistant", content: res.content || `Calling ${res.toolCalls.map((t) => t.name).join(", ")}` });
        for (const call of res.toolCalls) {
          this.setStatus("Working", `tool ${call.name}`, opts.taskId);
          const out = await this.registry.invoke(call.name, call.arguments, { agent: this.name, profile: this.profile, role: opts.role ?? "owner", workspace: this.workspace.root, threadId });
          const text = JSON.stringify(out).slice(0, 12_000);
          messages.push({ role: "tool", tool_call_id: call.id, name: call.name, content: text });
          conversations.add({ threadId, agent: this.name, role: "tool", text: `${call.name}: ${text.slice(0, 2000)}` });
        }
        final = res.content;
      }
      conversations.add({ threadId, agent: this.name, role: "assistant", text: final });
      this.memory.addMemory("history", `Task executed by ${this.name}: ${input.slice(0, 300)}`, { agent: this.name });
      bus.emit("agent.message", { agent: this.name, threadId, text: final });
      this.setStatus("Done", final.slice(0, 80), opts.taskId);
      return final;
    } catch (err) {
      this.setStatus("Error", (err as Error).message, opts.taskId);
      throw err;
    }
  }
}
