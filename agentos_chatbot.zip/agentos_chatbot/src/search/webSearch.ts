import { Logger } from "../utils/logger";
import { I18n } from "../utils/i18n";
import { config } from "../config";

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export type SearchEngine = "Google" | "Brave" | "Edge" | "Safari" | "Chrome" | "DuckDuckGo";

const UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36";

const decode = (s: string) =>
  s
    .replace(/<[^>]+>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();

/**
 * Real web search. Browser names map to their default engines
 * (Chrome -> Google, Edge -> Bing-compatible, Safari -> Google). Providers:
 * Google Programmable Search (GOOGLE_CSE_KEY/ID), Brave Search API
 * (BRAVE_SEARCH_API_KEY), and a key-less DuckDuckGo HTML fallback.
 * For literal in-browser searching use the CloudBrowser tool with Chromium, WebKit (Safari) or msedge channel.
 */
export class WebSearchEngine {
  public static async search(query: string, engine: SearchEngine = "Google", limit = 8): Promise<SearchResult[]> {
    Logger.info("WebSearch", `${I18n.t("searchExecuting")} [Engine: ${engine}] Query: "${query}"`);
    try {
      if ((engine === "Google" || engine === "Chrome" || engine === "Safari") && config.search.googleKey && config.search.googleCx) {
        return await this.google(query, limit);
      }
      if (config.search.braveKey && engine !== "DuckDuckGo") return await this.brave(query, limit);
      return await this.duckduckgo(query, limit);
    } catch (err) {
      Logger.error("WebSearch", `Search failed: ${(err as Error).message}`);
      return [];
    }
  }

  static async google(query: string, limit: number): Promise<SearchResult[]> {
    const u = `https://www.googleapis.com/customsearch/v1?key=${config.search.googleKey}&cx=${config.search.googleCx}&num=${Math.min(limit, 10)}&q=${encodeURIComponent(query)}`;
    const json: any = await (await fetch(u)).json();
    return (json.items ?? []).map((i: any) => ({ title: i.title, url: i.link, snippet: i.snippet ?? "" }));
  }

  static async brave(query: string, limit: number): Promise<SearchResult[]> {
    const res = await fetch(`https://api.search.brave.com/res/v1/web/search?count=${limit}&q=${encodeURIComponent(query)}`, {
      headers: { Accept: "application/json", "X-Subscription-Token": config.search.braveKey },
    });
    const json: any = await res.json();
    return (json.web?.results ?? []).map((r: any) => ({ title: r.title, url: r.url, snippet: decode(r.description ?? "") }));
  }

  static async duckduckgo(query: string, limit: number): Promise<SearchResult[]> {
    const res = await fetch("https://html.duckduckgo.com/html/", {
      method: "POST",
      headers: { "User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded" },
      body: `q=${encodeURIComponent(query)}`,
    });
    const html = await res.text();
    const out: SearchResult[] = [];
    const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) && out.length < limit) {
      let url = m[1];
      const uddg = url.match(/uddg=([^&]+)/);
      if (uddg) url = decodeURIComponent(uddg[1]);
      out.push({ title: decode(m[2]), url, snippet: decode(m[3]) });
    }
    return out;
  }

  /** Fetch a page and return readable text (scripts/styles stripped). */
  public static async fetchText(url: string, maxChars = 20_000): Promise<string> {
    const res = await fetch(url, { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(20_000) });
    const html = await res.text();
    return decode(html.replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, " ")).slice(0, maxChars);
  }
}
