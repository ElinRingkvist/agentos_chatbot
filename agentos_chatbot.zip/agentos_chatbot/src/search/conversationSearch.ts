import * as fs from "fs";
import { appendJsonl, dataPath, readJsonl, uid } from "../utils/fsx";
import { tokenize } from "../ai/embeddings";

export interface ChatRecord {
  id: string;
  threadId: string;
  agent: string;
  role: "user" | "assistant" | "system" | "tool";
  text: string;
  ts: string;
}

/**
 * Conversation history across thousands of agent chats with an inverted
 * index for sub-second keyword search and a regex "instant grep".
 */
export class ConversationStore {
  private file = dataPath("conversations.jsonl");
  private records: ChatRecord[] = [];
  private index = new Map<string, Set<number>>();
  private loadedSize = -1;

  private ensureLoaded() {
    const size = fs.existsSync(this.file) ? fs.statSync(this.file).size : 0;
    if (size === this.loadedSize) return;
    this.records = readJsonl<ChatRecord>(this.file);
    this.index.clear();
    this.records.forEach((r, i) => this.indexRecord(r, i));
    this.loadedSize = size;
  }

  private indexRecord(r: ChatRecord, i: number) {
    for (const t of new Set(tokenize(r.text))) {
      if (!this.index.has(t)) this.index.set(t, new Set());
      this.index.get(t)!.add(i);
    }
  }

  add(r: Omit<ChatRecord, "id" | "ts">): ChatRecord {
    this.ensureLoaded();
    const rec: ChatRecord = { ...r, id: uid("msg"), ts: new Date().toISOString() };
    appendJsonl(this.file, rec);
    this.records.push(rec);
    this.indexRecord(rec, this.records.length - 1);
    this.loadedSize = fs.statSync(this.file).size;
    return rec;
  }

  thread(threadId: string): ChatRecord[] {
    this.ensureLoaded();
    return this.records.filter((r) => r.threadId === threadId);
  }

  threads(): { threadId: string; last: string; count: number; agents: string[] }[] {
    this.ensureLoaded();
    const map = new Map<string, { threadId: string; last: string; count: number; agents: Set<string> }>();
    for (const r of this.records) {
      const t = map.get(r.threadId) ?? { threadId: r.threadId, last: r.ts, count: 0, agents: new Set<string>() };
      t.count++;
      t.last = r.ts;
      t.agents.add(r.agent);
      map.set(r.threadId, t);
    }
    return [...map.values()].map((t) => ({ ...t, agents: [...t.agents] })).sort((a, b) => b.last.localeCompare(a.last));
  }

  /** Ranked keyword search (all terms must match, prefix match on last term). */
  search(query: string, limit = 20): ChatRecord[] {
    this.ensureLoaded();
    const terms = tokenize(query);
    if (!terms.length) return [];
    let hits: Set<number> | null = null;
    terms.forEach((term, idx) => {
      const matching = new Set<number>();
      if (idx === terms.length - 1) {
        for (const [tok, ids] of this.index) if (tok.startsWith(term)) ids.forEach((i) => matching.add(i));
      } else this.index.get(term)?.forEach((i) => matching.add(i));
      hits = hits ? new Set([...hits].filter((i) => matching.has(i))) : matching;
    });
    return [...(hits ?? new Set<number>())]
      .sort((a, b) => b - a)
      .slice(0, limit)
      .map((i) => this.records[i]);
  }

  /** Regex grep across all history. */
  grep(pattern: string, flags = "i", limit = 100): { record: ChatRecord; match: string }[] {
    this.ensureLoaded();
    const re = new RegExp(pattern, flags);
    const out: { record: ChatRecord; match: string }[] = [];
    for (let i = this.records.length - 1; i >= 0 && out.length < limit; i--) {
      const m = this.records[i].text.match(re);
      if (m) out.push({ record: this.records[i], match: m[0] });
    }
    return out;
  }
}

export const conversations = new ConversationStore();
