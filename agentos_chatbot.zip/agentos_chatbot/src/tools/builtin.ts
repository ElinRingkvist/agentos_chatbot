import * as path from "path";
import { tools } from "./registry";
import { workspaceFor } from "../workspace/workspace";
import { WebSearchEngine } from "../search/webSearch";
import { conversations } from "../search/conversationSearch";
import { CodeIndex } from "../indexing/codeIndex";
import { PersistentMemory } from "../core/memory";
import { notifier } from "../notifications/notifier";
import { cms } from "../cms/workingMemory";
import { runSandboxed } from "../security/sandbox";
import { CloudBrowser } from "../browser/cloudBrowser";

const browsers = new Map<string, CloudBrowser>();
const browserFor = (agent: string) => {
  if (!browsers.has(agent)) browsers.set(agent, new CloudBrowser(workspaceFor(agent).browserProfileDir));
  return browsers.get(agent)!;
};

const obj = (props: Record<string, unknown>, required: string[] = []) => ({ type: "object", properties: props, required });
const str = (description: string) => ({ type: "string", description });

/** Registers the core tool set. Integrations register more tools on enable. */
export function registerBuiltinTools(memory: PersistentMemory) {
  tools
    .register({
      name: "fs.read",
      description: "Read a file from your workspace.",
      parameters: obj({ path: str("Relative path") }, ["path"]),
      run: async (a, c) => workspaceFor(c.agent).read(a.path),
    })
    .register({
      name: "fs.write",
      description: "Create or overwrite a file in your workspace.",
      parameters: obj({ path: str("Relative path"), content: str("File content") }, ["path", "content"]),
      run: async (a, c) => (workspaceFor(c.agent).write(a.path, a.content), "written"),
    })
    .register({
      name: "fs.modify",
      description: "Replace an exact snippet inside a workspace file.",
      parameters: obj({ path: str("Relative path"), find: str("Exact text to find"), replace: str("Replacement") }, ["path", "find", "replace"]),
      run: async (a, c) => (workspaceFor(c.agent).modify(a.path, a.find, a.replace) ? "modified" : "snippet not found"),
    })
    .register({
      name: "fs.list",
      description: "List files in your workspace.",
      parameters: obj({ path: str("Relative directory, default .") }),
      run: async (a, c) => workspaceFor(c.agent).list(a.path ?? "."),
    })
    .register({
      name: "fs.delete",
      description: "Delete a file or folder in your workspace.",
      parameters: obj({ path: str("Relative path") }, ["path"]),
      run: async (a, c) => (workspaceFor(c.agent).delete(a.path), "deleted"),
    })
    .register({
      name: "shell.run",
      description: "Run a shell command in your sandboxed workspace terminal.",
      parameters: obj({ command: str("Command"), timeoutMs: { type: "number" } }, ["command"]),
      run: async (a, c) => {
        const r = await workspaceFor(c.agent).exec(a.command, a.timeoutMs);
        return { code: r.code, stdout: r.stdout.slice(-8000), stderr: r.stderr.slice(-4000), timedOut: r.timedOut };
      },
    })
    .register({
      name: "git.diff",
      description: "Show git diff of the workspace.",
      parameters: obj({ ref: str("Ref, default HEAD") }),
      run: async (a, c) => (await runSandboxed(`git diff ${a.ref ?? "HEAD"}`, { cwd: c.workspace })).stdout,
    })
    .register({
      name: "git.push",
      description: "Push the current branch.",
      parameters: obj({ remote: str("Remote"), branch: str("Branch") }),
      run: async (a, c) => (await runSandboxed(`git push ${a.remote ?? "origin"} ${a.branch ?? "HEAD"}`, { cwd: c.workspace, network: true })).stdout,
    })
    .register({
      name: "web.search",
      description: "Search the internet.",
      parameters: obj({ query: str("Query"), engine: { type: "string", enum: ["Google", "Brave", "Edge", "Safari", "Chrome", "DuckDuckGo"] } }, ["query"]),
      run: async (a) => WebSearchEngine.search(a.query, a.engine ?? "Google"),
    })
    .register({
      name: "web.fetch",
      description: "Fetch a web page as readable text.",
      parameters: obj({ url: str("URL") }, ["url"]),
      run: async (a) => WebSearchEngine.fetchText(a.url),
    })
    .register({
      name: "browser.goto",
      description: "Open a URL in your persistent browser.",
      parameters: obj({ url: str("URL") }, ["url"]),
      run: async (a, c) => browserFor(c.agent).goto(a.url),
    })
    .register({
      name: "browser.click",
      description: "Click an element by CSS selector or visible text.",
      parameters: obj({ target: str("Selector or text") }, ["target"]),
      run: async (a, c) => (await browserFor(c.agent).click(a.target), "clicked"),
    })
    .register({
      name: "browser.fill",
      description: "Fill an input.",
      parameters: obj({ selector: str("CSS selector"), value: str("Value") }, ["selector", "value"]),
      run: async (a, c) => (await browserFor(c.agent).fill(a.selector, a.value), "filled"),
    })
    .register({
      name: "browser.submit",
      description: "Submit a form (requires approval).",
      parameters: obj({ selector: str("Form selector") }),
      run: async (a, c) => (await browserFor(c.agent).submit(a.selector), "submitted"),
    })
    .register({
      name: "browser.read",
      description: "Read visible text of the current page.",
      parameters: obj({}),
      run: async (_a, c) => browserFor(c.agent).text(),
    })
    .register({
      name: "memory.search",
      description: "Search long-term memory.",
      parameters: obj({ query: str("Query") }, ["query"]),
      run: async (a) => memory.search(a.query).map((m) => ({ category: m.category, content: m.content, ts: m.timestamp })),
    })
    .register({
      name: "memory.add",
      description: "Save a fact, preference, or note to long-term memory.",
      parameters: obj({ category: str("preference|profile|business|history|skill|file|communication"), content: str("Content") }, ["category", "content"]),
      run: async (a, c) => memory.addMemory(a.category, a.content, { agent: c.agent }).id,
    })
    .register({
      name: "search.conversations",
      description: "Search past agent conversations.",
      parameters: obj({ query: str("Query"), regex: { type: "boolean" } }, ["query"]),
      run: async (a) => (a.regex ? conversations.grep(a.query) : conversations.search(a.query)),
    })
    .register({
      name: "code.search",
      description: "Semantic search over an indexed repository.",
      parameters: obj({ query: str("What to find"), root: str("Repo root, default workspace") }, ["query"]),
      run: async (a, c) => new CodeIndex(path.resolve(a.root ?? c.workspace)).search(a.query),
    })
    .register({
      name: "code.symbol",
      description: "Find a class/function/type by name in an indexed repository.",
      parameters: obj({ name: str("Symbol name"), root: str("Repo root") }, ["name"]),
      run: async (a, c) => new CodeIndex(path.resolve(a.root ?? c.workspace)).findSymbol(a.name),
    })
    .register({
      name: "cms.get",
      description: "Read a shared document from the working-memory CMS.",
      parameters: obj({ key: str("Document key") }, ["key"]),
      run: async (a) => cms.get(a.key),
    })
    .register({
      name: "cms.put",
      description: "Write a shared document to the working-memory CMS.",
      parameters: obj({ key: str("Key"), content: str("Content"), expectedVersion: { type: "number" } }, ["key", "content"]),
      run: async (a, c) => cms.put(a.key, a.content, c.agent, a.expectedVersion),
    })
    .register({
      name: "notify.send",
      description: "Send the user a notification.",
      parameters: obj({ title: str("Title"), body: str("Body"), priority: { type: "string", enum: ["low", "normal", "high", "critical"] } }, ["title", "body"]),
      run: async (a) => notifier.send(a.title, a.body, a.priority ?? "normal"),
    });
}
