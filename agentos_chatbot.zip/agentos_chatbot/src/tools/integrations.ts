import * as path from "path";
import { tools } from "./registry";
import { assistantEmail } from "../connectors/email";
import { calendar } from "../connectors/calendar";
import { messaging } from "../connectors/messaging";
import { social } from "../connectors/social";
import { concierge } from "../connectors/telephony";
import { maps } from "../connectors/maps";
import { inbox } from "../proactive/inbox";
import { generateDocument, analyzeDocument } from "../documents/documents";
import { logoVariants, generateImage } from "../media/images";
import { canvases } from "../canvas/canvas";
import { Notion, Lovable } from "../connectors/creative";
import { bugbot } from "../review/bugbot";
import { workspaceFor } from "../workspace/workspace";

const obj = (props: Record<string, unknown>, required: string[] = []) => ({ type: "object", properties: props, required });
const s = (description: string) => ({ type: "string", description });

/** Exposes connectors to agents as policy-checked tools. */
export function registerIntegrationTools() {
  tools
    .register({ name: "email.inbox", description: "List unread messages across all connected inboxes and chats.", parameters: obj({}), run: async () => inbox.collect() })
    .register({
      name: "email.send",
      description: "Send an email from the assistant's own address (requires approval).",
      parameters: obj({ to: s("Recipient"), subject: s("Subject"), text: s("Body") }, ["to", "subject", "text"]),
      run: async (a) => assistantEmail.send(a.to, a.subject, a.text),
    })
    .register({
      name: "email.alias",
      description: "Get a unique assistant email alias to sign up for a service.",
      parameters: obj({ service: s("Service name") }, ["service"]),
      run: async (a) => assistantEmail.aliasFor(a.service),
    })
    .register({
      name: "email.waitForCode",
      description: "Wait for a verification code or magic link to arrive in the assistant inbox.",
      parameters: obj({ from: s("Sender contains"), timeoutMs: { type: "number" } }),
      run: async (a) => assistantEmail.waitForVerification({ fromContains: a.from, timeoutMs: a.timeoutMs }),
    })
    .register({ name: "calendar.today", description: "Today's calendar events.", parameters: obj({}), run: async () => calendar.today() })
    .register({
      name: "messages.send",
      description: "Send a chat message via telegram, sms or imessage (requires approval).",
      parameters: obj({ channel: { type: "string", enum: ["telegram", "sms", "imessage"] }, to: s("Chat id / phone / handle"), text: s("Message") }, ["channel", "to", "text"]),
      run: async (a) => messaging.send(a.channel, a.to, a.text),
    })
    .register({
      name: "social.read",
      description: "Read social notifications/mentions.",
      parameters: obj({ network: { type: "string", enum: ["mastodon", "bluesky", "x"] } }, ["network"]),
      run: async (a) => social.notifications(a.network),
    })
    .register({
      name: "social.post",
      description: "Post or reply on social media (requires approval).",
      parameters: obj({ network: { type: "string", enum: ["mastodon", "bluesky", "x"] }, text: s("Text"), replyTo: s("Post id to reply to") }, ["network", "text"]),
      run: async (a) => social.post(a.network, a.text, a.replyTo),
    })
    .register({
      name: "call.place",
      description: "Phone a business to book, join a waitlist, or negotiate (requires approval).",
      parameters: obj({ to: s("E.164 phone number"), business: s("Business name"), goal: s("What to achieve"), userName: s("Caller is acting for"), constraints: { type: "array", items: { type: "string" } } }, ["to", "business", "goal", "userName"]),
      run: async (a) => concierge.place(concierge.plan({ to: a.to, business: a.business, goal: a.goal, userName: a.userName, constraints: a.constraints ?? [] }).id),
    })
    .register({
      name: "maps.route",
      description: "Fastest routes between two places, with live traffic when available.",
      parameters: obj({ from: s("Origin"), to: s("Destination"), arriveBy: s("ISO time to arrive by (optional)") }, ["from", "to"]),
      run: async (a) => (a.arriveBy ? maps.departureAdvice(a.from, a.to, new Date(a.arriveBy)) : maps.routes(a.from, a.to)),
    })
    .register({
      name: "docs.generate",
      description: "Generate a PDF, HTML slide deck, spreadsheet or markdown file in the workspace.",
      parameters: obj({ kind: { type: "string", enum: ["pdf", "slides", "spreadsheet", "markdown"] }, brief: s("What it should contain"), file: s("Output path relative to workspace") }, ["kind", "brief", "file"]),
      run: async (a, c) => generateDocument(a.kind, a.brief, workspaceFor(c.agent).resolve(a.file)),
    })
    .register({
      name: "docs.analyze",
      description: "Read and analyse a document in the workspace.",
      parameters: obj({ file: s("Path"), question: s("Question") }, ["file"]),
      run: async (a, c) => analyzeDocument(workspaceFor(c.agent).resolve(a.file), a.question),
    })
    .register({
      name: "docs.logoVariants",
      description: "Create dark, light, mono, inverted, minimal and colour variants of a logo file.",
      parameters: obj({ file: s("Logo path in workspace") }, ["file"]),
      run: async (a, c) => (await logoVariants(workspaceFor(c.agent).resolve(a.file))).map((p) => path.relative(workspaceFor(c.agent).root, p)),
    })
    .register({
      name: "docs.image",
      description: "Generate an image from a prompt.",
      parameters: obj({ prompt: s("Prompt"), file: s("Output path") }, ["prompt", "file"]),
      run: async (a, c) => generateImage(a.prompt, workspaceFor(c.agent).resolve(a.file)),
    })
    .register({
      name: "docs.canvas",
      description: "Create or revise a live interactive HTML canvas and get a shareable link.",
      parameters: obj({ brief: s("What to build / change"), id: s("Existing canvas id to revise") }, ["brief"]),
      run: async (a, c) => {
        const cv = await canvases.generate(a.brief, c.agent, a.id);
        return { id: cv.id, url: canvases.shareUrl(cv), version: cv.versions };
      },
    })
    .register({
      name: "docs.notion",
      description: "Create a Notion page.",
      parameters: obj({ parent: s("Parent page id"), title: s("Title"), markdown: s("Content") }, ["parent", "title", "markdown"]),
      run: async (a) => Notion.createPage(a.parent, a.title, a.markdown),
    })
    .register({ name: "docs.lovable", description: "Create a link that builds an app in Lovable from a prompt.", parameters: obj({ prompt: s("App description") }, ["prompt"]), run: async (a) => Lovable.buildLink(a.prompt) })
    .register({
      name: "code.review",
      description: "Security/bug review of a GitHub pull request.",
      parameters: obj({ repo: s("owner/name"), pr: { type: "number" }, post: { type: "boolean" } }, ["repo", "pr"]),
      run: async (a) => bugbot.reviewPullRequest(a.repo, a.pr, { post: a.post }),
    });
}
