import { ToolSpec } from "../ai/llm";
import { bus } from "../events/bus";
import { policy, IdentityRole } from "../security/policy";
import { approvals } from "../approvals/approvals";

export interface ToolContext {
  agent: string;
  profile: string;
  role: IdentityRole;
  workspace: string;
  threadId?: string;
}

export interface Tool {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
  run(args: Record<string, any>, ctx: ToolContext): Promise<unknown>;
}

/**
 * Central tool registry. Every invocation goes through the security policy
 * first (allow/deny lists, roles, profiles), then optional human approval.
 */
export class ToolRegistry {
  private tools = new Map<string, Tool>();

  register(tool: Tool) {
    this.tools.set(tool.name, tool);
    return this;
  }

  unregister(name: string) {
    this.tools.delete(name);
  }

  list(): Tool[] {
    return [...this.tools.values()];
  }

  get(name: string) {
    return this.tools.get(name);
  }

  /** Tool specs the model is allowed to see for this profile (pre-model filtering). */
  specsFor(profile: string, role: IdentityRole = "owner"): ToolSpec[] {
    return this.list()
      .filter((t) => policy.checkTool(profile, t.name, role).allowed)
      .map((t) => ({ name: toWireName(t.name), description: t.description, parameters: t.parameters }));
  }

  async invoke(name: string, args: Record<string, any>, ctx: ToolContext): Promise<{ ok: boolean; result?: unknown; error?: string }> {
    const realName = fromWireName(name, this.tools);
    const tool = this.tools.get(realName);
    if (!tool) return { ok: false, error: `Unknown tool ${name}` };
    const decision = policy.checkTool(ctx.profile, realName, ctx.role, args);
    bus.emit("tool.called", { agent: ctx.agent, tool: realName, args, allowed: decision.allowed });
    if (!decision.allowed) return { ok: false, error: `Blocked by security policy: ${decision.reason}` };
    if (decision.needsApproval) {
      const res = await approvals.request({ agent: ctx.agent, action: realName, payload: JSON.stringify(args, null, 2) });
      if (res.decision === "rejected") return { ok: false, error: "User rejected the action." };
      if (res.decision === "edited" && res.payload) {
        try {
          args = JSON.parse(res.payload);
        } catch {
          return { ok: false, error: "Edited payload was not valid JSON." };
        }
      }
    }
    try {
      return { ok: true, result: await tool.run(args, ctx) };
    } catch (err) {
      return { ok: false, error: (err as Error).message };
    }
  }
}

/** OpenAI function names cannot contain dots. */
const toWireName = (n: string) => n.replace(/\./g, "__");
function fromWireName(n: string, tools: Map<string, Tool>) {
  if (tools.has(n)) return n;
  return n.replace(/__/g, ".");
}

export const tools = new ToolRegistry();
