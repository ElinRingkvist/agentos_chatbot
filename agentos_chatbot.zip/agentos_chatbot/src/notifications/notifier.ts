import * as fs from "fs";
import { config } from "../config";
import { bus } from "../events/bus";
import { appendJsonl, dataPath, readJsonl, uid } from "../utils/fsx";
import { Logger } from "../utils/logger";

export type Priority = "low" | "normal" | "high" | "critical";

export interface Notification {
  id: string;
  title: string;
  body: string;
  priority: Priority;
  /**
   * Attention effect hint for native clients: "loud" (iMessage-style slam /
   * Android heads-up), "gentle", "typing" (the "loading dots" effect) or "none".
   */
  effect: "loud" | "gentle" | "typing" | "none";
  ts: string;
  read: boolean;
  actions?: { label: string; url: string }[];
}

/**
 * Multi-channel notifier. Push to iOS/Android via ntfy (free, self-hostable,
 * supports priorities, tags and action buttons), Telegram, Slack, generic
 * webhook, and the local OS notification centre.
 */
export class Notifier {
  private file = dataPath("notifications.jsonl");

  constructor() {
    bus.on("notification", (n) => void this.send(n.title, n.body, n.priority, (n.effect as Notification["effect"]) ?? undefined));
  }

  list(unreadOnly = false): Notification[] {
    return readJsonl<Notification>(this.file).filter((n) => !unreadOnly || !n.read).reverse();
  }

  markRead(id?: string) {
    const all = readJsonl<Notification>(this.file).map((n) => (!id || n.id === id ? { ...n, read: true } : n));
    fs.writeFileSync(this.file, all.map((n) => JSON.stringify(n)).join("\n") + (all.length ? "\n" : ""));
  }

  async send(title: string, body: string, priority: Priority = "normal", effect?: Notification["effect"], actions?: Notification["actions"]): Promise<Notification> {
    const n: Notification = {
      id: uid("ntf"),
      title,
      body,
      priority,
      effect: effect ?? (priority === "critical" || priority === "high" ? "loud" : "gentle"),
      ts: new Date().toISOString(),
      read: false,
      actions,
    };
    appendJsonl(this.file, n);
    Logger.info("Notify", `[${priority}] ${title} — ${body.slice(0, 140)}`);
    await Promise.allSettled([this.ntfy(n), this.telegram(n), this.slack(n), this.webhook(n), this.desktop(n)]);
    return n;
  }

  private async ntfy(n: Notification) {
    if (!config.notify.ntfyTopic) return;
    const prio = { low: "2", normal: "3", high: "4", critical: "5" }[n.priority];
    await fetch(`${config.notify.ntfyServer}/${config.notify.ntfyTopic}`, {
      method: "POST",
      headers: {
        Title: encodeURIComponent(n.title),
        Priority: prio,
        Tags: n.effect === "loud" ? "rotating_light" : "robot",
        ...(n.actions?.length ? { Actions: n.actions.map((a) => `view, ${a.label}, ${a.url}`).join("; ") } : {}),
      },
      body: n.body,
    });
  }

  private async telegram(n: Notification) {
    const { telegramToken, telegramChatId } = config.notify;
    if (!telegramToken || !telegramChatId) return;
    await fetch(`https://api.telegram.org/bot${telegramToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: telegramChatId, text: `*${n.title}*\n${n.body}`, parse_mode: "Markdown", disable_notification: n.priority === "low" }),
    });
  }

  private async slack(n: Notification) {
    if (!config.notify.slackWebhook) return;
    await fetch(config.notify.slackWebhook, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: `*${n.title}*\n${n.body}` }) });
  }

  private async webhook(n: Notification) {
    if (!config.notify.webhookUrl) return;
    await fetch(config.notify.webhookUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(n) });
  }

  private async desktop(n: Notification) {
    if (process.env.DESKTOP_NOTIFICATIONS !== "1") return;
    const { runSandboxed } = await import("../security/sandbox");
    const t = n.title.replace(/["'`$]/g, "");
    const b = n.body.replace(/["'`$]/g, "").slice(0, 200);
    const cmd =
      process.platform === "darwin"
        ? `osascript -e 'display notification "${b}" with title "${t}"'`
        : process.platform === "linux"
          ? `notify-send ${n.priority === "critical" ? "-u critical" : ""} "${t}" "${b}"`
          : `powershell -NoProfile -Command "New-BurntToastNotification -Text '${t}','${b}'"`;
    await runSandboxed(cmd, { cwd: process.cwd(), timeoutMs: 5000, env: { DISPLAY: process.env.DISPLAY ?? ":0", DBUS_SESSION_BUS_ADDRESS: process.env.DBUS_SESSION_BUS_ADDRESS ?? "" } });
  }
}

export const notifier = new Notifier();
