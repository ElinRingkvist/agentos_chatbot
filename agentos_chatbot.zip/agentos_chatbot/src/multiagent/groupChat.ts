import type { Agent } from "../core/agent";
import { ChatMessage } from "../ai/llm";
import { conversations } from "../search/conversationSearch";
import { uid } from "../utils/fsx";
import { Logger } from "../utils/logger";

export interface GroupMessage {
  from: string;
  text: string;
  citations: string[];
}

/**
 * Multi-agent group chat. Several bots share one thread. Each turn the
 * current owner answers; mentioning "@AgentName" or writing
 * "HANDOFF: AgentName" passes task ownership. URLs/[n] citations from every
 * agent are merged and deduplicated into the final answer.
 */
export class GroupChat {
  readonly threadId = uid("grp");
  private transcript: GroupMessage[] = [];

  constructor(private members: Agent[], private maxTurns = 8) {
    if (!members.length) throw new Error("Group chat needs at least one agent");
  }

  private extractCitations(text: string): string[] {
    return [...new Set(text.match(/https?:\/\/[^\s)\]]+/g) ?? [])];
  }

  private nextOwner(text: string, current: Agent): Agent | null {
    const m = text.match(/HANDOFF:\s*@?([\w-]+)/i) ?? text.match(/@([\w-]+)/);
    if (!m) return null;
    return this.members.find((a) => a.name.toLowerCase() === m[1].toLowerCase() && a !== current) ?? null;
  }

  async discuss(goal: string, from = "user"): Promise<{ answer: string; citations: string[]; transcript: GroupMessage[] }> {
    this.transcript.push({ from, text: goal, citations: [] });
    conversations.add({ threadId: this.threadId, agent: from, role: "user", text: goal });
    let owner = this.members[0];
    const roster = this.members.map((a) => `@${a.name} (${a.role})`).join(", ");
    for (let turn = 0; turn < this.maxTurns; turn++) {
      const history: ChatMessage[] = this.transcript.map((m) => ({ role: m.from === owner.name ? "assistant" : "user", content: `${m.from}: ${m.text}` }));
      const prompt =
        `You are in a group chat with ${roster}. Goal: ${goal}\n` +
        `Contribute using your speciality. If another member is better suited for the next part, end with "HANDOFF: @Name". ` +
        `When the goal is fully achieved, start your reply with "FINAL:".`;
      const text = await owner.run(prompt, { threadId: this.threadId, history, mode: "agent" });
      const msg = { from: owner.name, text, citations: this.extractCitations(text) };
      this.transcript.push(msg);
      Logger.agent(owner.name, `[group ${this.threadId}] ${text.slice(0, 160)}`);
      if (/^\s*FINAL:/i.test(text)) break;
      const nxt = this.nextOwner(text, owner);
      if (nxt) owner = nxt;
      else if (turn > 0) break;
      else owner = this.members[(this.members.indexOf(owner) + 1) % this.members.length];
    }
    const citations = [...new Set(this.transcript.flatMap((m) => m.citations))];
    const last = this.transcript[this.transcript.length - 1].text.replace(/^\s*FINAL:\s*/i, "");
    const answer = citations.length ? `${last}\n\nSources:\n${citations.map((c, i) => `[${i + 1}] ${c}`).join("\n")}` : last;
    return { answer, citations, transcript: this.transcript };
  }
}
