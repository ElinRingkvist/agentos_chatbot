import { dataPath, readJson, uid, writeJson } from "../utils/fsx";

export type BotPermission = "use" | "modify" | "deploy" | "admin";

export interface TeamBot {
  id: string;
  name: string;
  role: string;
  ownerId: string;
  /** userId -> permissions */
  acl: Record<string, BotPermission[]>;
  deployed: boolean;
  /** Optional subscription plan required to use the bot ("prenumeration"). */
  requiredPlan?: string;
  createdAt: string;
}

export interface TeamUser {
  id: string;
  name: string;
  email: string;
  plan: string;
}

/**
 * Team bots & access lists. Shared bots with per-user permissions
 * (use / modify / deploy / admin) and optional plan gating.
 */
export class TeamDirectory {
  private file = dataPath("teams.json");

  private load(): { users: TeamUser[]; bots: TeamBot[] } {
    return readJson(this.file, { users: [], bots: [] });
  }
  private save(d: { users: TeamUser[]; bots: TeamBot[] }) {
    writeJson(this.file, d);
  }

  addUser(u: Omit<TeamUser, "id"> & { id?: string }): TeamUser {
    const d = this.load();
    const user = { ...u, id: u.id ?? uid("usr") };
    d.users = d.users.filter((x) => x.id !== user.id).concat(user);
    this.save(d);
    return user;
  }

  createBot(name: string, role: string, ownerId: string, requiredPlan?: string): TeamBot {
    const d = this.load();
    const bot: TeamBot = { id: uid("bot"), name, role, ownerId, acl: { [ownerId]: ["admin"] }, deployed: false, requiredPlan, createdAt: new Date().toISOString() };
    d.bots.push(bot);
    this.save(d);
    return bot;
  }

  can(userId: string, botId: string, perm: BotPermission): boolean {
    const d = this.load();
    const bot = d.bots.find((b) => b.id === botId);
    if (!bot) return false;
    const perms = bot.acl[userId] ?? [];
    if (perms.includes("admin")) return true;
    if (perm === "use" && bot.requiredPlan) {
      const user = d.users.find((u) => u.id === userId);
      if (!user || user.plan !== bot.requiredPlan) return false;
    }
    if (perm === "use") return perms.length > 0;
    return perms.includes(perm);
  }

  grant(actorId: string, botId: string, userId: string, perms: BotPermission[]) {
    if (!this.can(actorId, botId, "admin")) throw new Error("Only bot admins can change access lists");
    const d = this.load();
    const bot = d.bots.find((b) => b.id === botId)!;
    bot.acl[userId] = [...new Set([...(bot.acl[userId] ?? []), ...perms])];
    this.save(d);
  }

  revoke(actorId: string, botId: string, userId: string) {
    if (!this.can(actorId, botId, "admin")) throw new Error("Only bot admins can change access lists");
    const d = this.load();
    const bot = d.bots.find((b) => b.id === botId)!;
    if (userId === bot.ownerId) throw new Error("Cannot revoke the owner");
    delete bot.acl[userId];
    this.save(d);
  }

  deploy(actorId: string, botId: string, deployed = true) {
    if (!this.can(actorId, botId, "deploy")) throw new Error("Missing deploy permission");
    const d = this.load();
    d.bots.find((b) => b.id === botId)!.deployed = deployed;
    this.save(d);
  }

  botsFor(userId: string): TeamBot[] {
    return this.load().bots.filter((b) => this.can(userId, b.id, "use"));
  }
}

export const teams = new TeamDirectory();
