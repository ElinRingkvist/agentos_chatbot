import type { Agent, AgentRole } from "../core/agent";
import { completeJson } from "../ai/llm";
import { uid } from "../utils/fsx";

export interface RouteDecision {
  agent: string;
  reason: string;
  sessionId: string;
}

const KEYWORDS: Partial<Record<AgentRole, RegExp>> = {
  CodeEngineer: /\b(code|bug|fix|build|deploy|refactor|test|repo|pull request|pr|typescript|python|api|kod)\b/i,
  ResearchAgent: /\b(research|search|find out|compare|news|trend|sök|undersök)\b/i,
  InboxManager: /\b(email|e-mail|mail|inbox|reply|message|slack|meddelande)\b/i,
  ExpenseManager: /\b(expense|receipt|invoice|budget|cost|kvitto|faktura|utgift)\b/i,
  TalentScout: /\b(candidate|hire|recruit|resume|cv|talent|rekryter)\b/i,
  VoiceConcierge: /\b(call|phone|book a table|reservation|dentist|ring|boka)\b/i,
  SecurityReviewer: /\b(security|vulnerab|cve|exploit|audit|säkerhet)\b/i,
};

/**
 * Multi-agent routing. Classifies an inbound request and sends it to an
 * isolated, specialised session. A per-agent lock queue guarantees one task
 * per session at a time, preventing task overlap.
 */
export class AgentRouter {
  private locks = new Map<string, Promise<unknown>>();

  constructor(private agents: () => Map<string, Agent>) {}

  async route(request: string, useLLM = true): Promise<RouteDecision> {
    const list = [...this.agents().values()];
    for (const a of list) {
      const re = KEYWORDS[a.role];
      if (re?.test(request)) return { agent: a.name, reason: `keyword match for ${a.role}`, sessionId: uid("sess") };
    }
    if (useLLM && list.length > 1) {
      const pick = await completeJson<{ agent?: string; reason?: string }>(
        `Pick the best agent for this request.\nRequest: "${request}"\nAgents:\n${list.map((a) => `- ${a.name} (${a.role})`).join("\n")}\nReturn {"agent": "<name>", "reason": "..."}`,
        {},
      );
      if (pick.agent && this.agents().has(pick.agent)) return { agent: pick.agent, reason: pick.reason ?? "llm", sessionId: uid("sess") };
    }
    const fallback = list.find((a) => a.role === "Orchestrator") ?? list[0];
    return { agent: fallback.name, reason: "fallback", sessionId: uid("sess") };
  }

  /** Run with an exclusive per-agent lock (serialises overlapping work). */
  async dispatch(request: string): Promise<{ decision: RouteDecision; result: string }> {
    const decision = await this.route(request);
    const agent = this.agents().get(decision.agent)!;
    const prev = this.locks.get(agent.name) ?? Promise.resolve();
    const run = prev.catch(() => undefined).then(() => agent.run(request, { threadId: decision.sessionId }));
    this.locks.set(agent.name, run);
    return { decision, result: await run };
  }

  /** Parallel multi-bot tasks: independent workloads on different agents at the same time. */
  async parallel(jobs: { agent: string; prompt: string }[], concurrency = 4): Promise<{ agent: string; ok: boolean; result: string }[]> {
    const results: { agent: string; ok: boolean; result: string }[] = new Array(jobs.length);
    let next = 0;
    const worker = async () => {
      while (next < jobs.length) {
        const i = next++;
        const j = jobs[i];
        const agent = this.agents().get(j.agent);
        if (!agent) {
          results[i] = { agent: j.agent, ok: false, result: "unknown agent" };
          continue;
        }
        try {
          results[i] = { agent: j.agent, ok: true, result: await agent.run(j.prompt) };
        } catch (err) {
          results[i] = { agent: j.agent, ok: false, result: (err as Error).message };
        }
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, jobs.length) }, worker));
    return results;
  }
}
