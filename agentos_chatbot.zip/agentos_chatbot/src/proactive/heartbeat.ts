import { Logger } from "../utils/logger";
import { PersistentMemory } from "../core/memory";
import { Agent } from "../core/agent";
import { I18n } from "../utils/i18n";
import { inbox } from "./inbox";
import { calendar } from "../connectors/calendar";
import { config } from "../config";
import { DevOps, Linear } from "../connectors/devtools";
import { notifier } from "../notifications/notifier";
import { completeJson } from "../ai/llm";
import { dataPath, readJson, writeJson } from "../utils/fsx";

export interface AttentionItem {
  key: string;
  source: string;
  title: string;
  detail: string;
  priority: "normal" | "high" | "critical";
}

export type Scanner = () => Promise<AttentionItem[]>;

/**
 * Proactive heartbeat ("messages you first"). Every few hours it sweeps all
 * connected apps (inbox, calendar, Linear, Sentry, Vercel, custom scanners),
 * decides what actually needs the user's attention, and notifies them —
 * without being asked. Already-notified items are remembered to avoid spam.
 */
export class ProactiveHeartbeat {
  private memory: PersistentMemory;
  private orchestrator: Agent;
  private timer: NodeJS.Timeout | null = null;
  private scanners = new Map<string, Scanner>();
  private seenFile = dataPath("heartbeat-seen.json");

  constructor(memory: PersistentMemory, orchestrator: Agent) {
    this.memory = memory;
    this.orchestrator = orchestrator;
    this.registerDefaultScanners();
  }

  registerScanner(name: string, s: Scanner) {
    this.scanners.set(name, s);
  }

  public startHeartbeat(intervalMs: number = config.heartbeat.intervalMs) {
    Logger.info("Heartbeat", `Starting proactive background heartbeat scanner (every ${Math.round(intervalMs / 60000)} min)...`);
    this.stopHeartbeat();
    this.timer = setInterval(() => void this.runBackgroundSweep(), intervalMs);
  }

  public stopHeartbeat() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private registerDefaultScanners() {
    this.registerScanner("inbox", async () =>
      (await inbox.collect())
        .filter((i) => i.priority === "high")
        .map((i) => ({ key: i.id, source: i.channel, title: `${i.from}: ${i.subject ?? i.text.slice(0, 60)}`, detail: i.text.slice(0, 300), priority: "high" as const })),
    );
    this.registerScanner("calendar", async () => {
      const soon = await calendar.eventsBetween(new Date(), new Date(Date.now() + 2 * 3600_000));
      return soon.map((e) => ({ key: `cal:${e.id}:${e.start}`, source: "calendar", title: `Upcoming: ${e.title}`, detail: `${new Date(e.start).toLocaleString()}${e.location ? ` @ ${e.location}` : ""}`, priority: "normal" as const }));
    });
    if (config.linear.apiKey)
      this.registerScanner("linear", async () => {
        const d: any = await Linear.myIssues();
        return (d.viewer?.assignedIssues?.nodes ?? []).filter((i: any) => i.priority === 1).map((i: any) => ({ key: `linear:${i.id}`, source: "linear", title: `Urgent issue ${i.identifier}: ${i.title}`, detail: i.url, priority: "high" as const }));
      });
    if (config.sentry.token && process.env.SENTRY_PROJECT)
      this.registerScanner("sentry", async () => {
        const issues: any[] = await DevOps.sentryIssues(process.env.SENTRY_PROJECT!, "is:unresolved is:for_review");
        return issues.slice(0, 10).map((i) => ({ key: `sentry:${i.id}`, source: "sentry", title: `New error: ${i.title}`, detail: `${i.count} events — ${i.permalink}`, priority: i.level === "fatal" ? ("critical" as const) : ("high" as const) }));
      });
    if (config.vercel.token)
      this.registerScanner("vercel", async () => {
        const d: any = await DevOps.vercelDeployments(5);
        return (d.deployments ?? []).filter((x: any) => x.state === "ERROR").map((x: any) => ({ key: `vercel:${x.uid}`, source: "vercel", title: `Deployment failed: ${x.name}`, detail: x.url, priority: "high" as const }));
      });
  }

  /** One sweep. Public so routines/CLI can trigger it on demand. */
  public async runBackgroundSweep(): Promise<AttentionItem[]> {
    Logger.info("Heartbeat", "Performing routine background sweep...");
    const seen = new Set(readJson<string[]>(this.seenFile, []));
    const found: AttentionItem[] = [];
    for (const [name, scan] of this.scanners) {
      try {
        found.push(...(await scan()));
      } catch (err) {
        Logger.warn("Heartbeat", `${name} scanner skipped: ${(err as Error).message.slice(0, 120)}`);
      }
    }
    const fresh = found.filter((f) => !seen.has(f.key));
    if (!fresh.length) {
      Logger.info("Heartbeat", "Nothing needs your attention right now.");
      return [];
    }
    // Let the orchestrator decide which items are truly worth interrupting the user for.
    const ranked = await completeJson<{ notify: string[]; message: string }>(
      `You are ${this.orchestrator.name}. Decide which of these items deserve proactively messaging the user now, given their preferences:\n` +
        `${this.memory.buildContext("notification preferences priorities", 5)}\n\nItems:\n${fresh.map((f) => `${f.key} | ${f.priority} | ${f.title} | ${f.detail}`).join("\n")}\n` +
        `Return {"notify":["key",...],"message":"short friendly message to the user in ${I18n.getLanguage()}"}`,
      { notify: fresh.filter((f) => f.priority !== "normal").map((f) => f.key), message: fresh.map((f) => f.title).join("\n") },
    );
    const toNotify = fresh.filter((f) => ranked.notify?.includes(f.key));
    if (toNotify.length) {
      const top = toNotify.some((f) => f.priority === "critical") ? "critical" : "high";
      await notifier.send(`${this.orchestrator.name}: ${toNotify.length} item(s) need you`, ranked.message || toNotify.map((f) => `• ${f.title}`).join("\n"), top);
      Logger.agent(this.orchestrator.name, ranked.message);
    }
    writeJson(this.seenFile, [...seen, ...fresh.map((f) => f.key)].slice(-10_000));
    return toNotify;
  }
}
