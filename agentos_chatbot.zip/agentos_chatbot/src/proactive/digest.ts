import { config } from "../config";
import { complete } from "../ai/llm";
import { calendar } from "../connectors/calendar";
import { inbox } from "./inbox";
import { WebSearchEngine } from "../search/webSearch";
import { I18n } from "../utils/i18n";
import { dataPath, readJson, writeJson } from "../utils/fsx";
import type { PersistentMemory } from "../core/memory";
import type { TaskQueue } from "../tasks/taskQueue";
import { notifier } from "../notifications/notifier";
import { maps } from "../connectors/maps";

export interface DigestSettings {
  time: string; // "07:00"
  sections: string[]; // email, calendar, messages, news, tasks, suggestions, commute
  newsTopics: string[];
  home?: string;
  language?: string;
}

/**
 * Morning digest / overnight summarisation: overnight events, missed
 * high-priority messages, today's schedule, news on chosen topics,
 * background task results and proactive suggestions for the workday.
 * Time and contents are configurable via settings (persisted).
 */
export class MorningDigest {
  private settingsFile = dataPath("digest-settings.json");
  private lastFile = dataPath("digest-last.json");

  constructor(private memory: PersistentMemory, private tasks?: TaskQueue) {}

  settings(): DigestSettings {
    return readJson<DigestSettings>(this.settingsFile, { time: config.heartbeat.digestTime, sections: config.heartbeat.digestSections, newsTopics: config.heartbeat.newsTopics });
  }

  updateSettings(patch: Partial<DigestSettings>) {
    const s = { ...this.settings(), ...patch };
    if (!/^\d{1,2}:\d{2}$/.test(s.time)) throw new Error("time must be HH:MM");
    writeJson(this.settingsFile, s);
    return s;
  }

  cronExpr() {
    const [h, m] = this.settings().time.split(":").map(Number);
    return `${m} ${h} * * *`;
  }

  async build(): Promise<string> {
    const s = this.settings();
    const since = new Date(readJson<{ at?: string }>(this.lastFile, {}).at ?? Date.now() - 12 * 3600_000);
    const sections: string[] = [];
    const want = (k: string) => s.sections.includes(k);

    if (want("email") || want("messages")) {
      const items = (await inbox.collect().catch(() => [])).filter((i) => new Date(i.ts) >= since);
      const high = items.filter((i) => i.priority === "high");
      sections.push(`UNREAD SINCE ${since.toISOString()}: ${items.length} (${high.length} high priority)\n` + high.slice(0, 10).map((i) => `- [${i.channel}] ${i.from}: ${i.subject ?? i.text.slice(0, 120)}`).join("\n"));
      if (items.length) sections.push("OTHER MESSAGES:\n" + items.filter((i) => i.priority !== "high").slice(0, 20).map((i) => `- [${i.channel}] ${i.from}: ${(i.subject ?? i.text).slice(0, 100)}`).join("\n"));
    }
    if (want("calendar")) {
      const events = await calendar.today().catch(() => []);
      sections.push("TODAY'S SCHEDULE:\n" + (events.map((e) => `- ${new Date(e.start).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} ${e.title}${e.location ? ` @ ${e.location}` : ""}`).join("\n") || "(no events)"));
      if (want("commute") && s.home) {
        const first = events.find((e) => e.location);
        if (first) {
          const adv = await maps.departureAdvice(s.home, first.location!, new Date(first.start)).catch(() => null);
          if (adv) sections.push(`COMMUTE: leave at ${new Date(adv.leaveAt).toLocaleTimeString()} (${adv.best.mode}, ${adv.best.trafficDurationMin ?? adv.best.durationMin} min) for "${first.title}"`);
        }
      }
    }
    if (want("news")) {
      for (const topic of s.newsTopics.slice(0, 3)) {
        const r = await WebSearchEngine.search(`${topic} news today`, "Google", 4);
        if (r.length) sections.push(`NEWS — ${topic}:\n` + r.map((x) => `- ${x.title} (${x.url})`).join("\n"));
      }
    }
    if (want("tasks") && this.tasks) {
      const ready = this.tasks.list("waiting_review");
      const failed = this.tasks.list("failed").filter((t) => new Date(t.updatedAt) >= since);
      sections.push(`BACKGROUND WORK: ${ready.length} ready for review, ${failed.length} failed overnight\n` + [...ready, ...failed].map((t) => `- ${t.status}: ${t.title}`).join("\n"));
    }
    const raw = sections.join("\n\n");
    const body = want("suggestions")
      ? await complete(
          `${I18n.t("morningDigestTitle")}\nWrite a concise personalised morning briefing in language "${s.language ?? I18n.getLanguage()}" from the data below. ` +
            `Start with the 3 most important things, then the schedule, then proactive suggestions for the workday.\n\nUser context:\n${this.memory.buildContext("morning routine priorities", 5)}\n\nData:\n${raw}`,
        )
      : raw;
    writeJson(this.lastFile, { at: new Date().toISOString() });
    return `${I18n.t("morningDigestTitle")}\n\n${body}`;
  }

  async deliver() {
    const text = await this.build();
    this.memory.addMemory("history", `Morning digest delivered (${text.length} chars)`);
    await notifier.send(I18n.t("morningDigestTitle"), text.slice(0, 3500), "normal", "gentle");
    return text;
  }
}
