import { assistantEmail } from "../connectors/email";
import { Google, Microsoft, Apple } from "../connectors/platforms";
import { messaging } from "../connectors/messaging";
import { social } from "../connectors/social";
import { config } from "../config";
import { complete } from "../ai/llm";
import { dataPath, readJson, writeJson } from "../utils/fsx";

export interface InboxItem {
  id: string;
  channel: "email" | "gmail" | "outlook" | "imessage" | "telegram" | "mastodon" | "bluesky" | "x";
  from: string;
  subject?: string;
  text: string;
  ts: string;
  unread: boolean;
  priority: "high" | "normal" | "low";
  replyTo?: string;
}

const URGENT = /\b(urgent|asap|immediately|important|deadline|today|overdue|invoice|payment|security|password|brådskande|viktigt|idag)\b/i;

/**
 * Unified "unread messages" inbox across email, chat and social. Reads,
 * prioritises, drafts answers and sends replies (sending needs approval
 * when invoked through the agent tool layer).
 */
export class UnifiedInbox {
  private stateFile = dataPath("inbox-state.json");

  private readState(): { read: string[] } {
    return readJson(this.stateFile, { read: [] });
  }

  async collect(): Promise<InboxItem[]> {
    const items: InboxItem[] = [];
    const tasks: Promise<void>[] = [];
    const push = (xs: InboxItem[]) => void items.push(...xs);
    if (config.email.imapHost)
      tasks.push(assistantEmail.fetch({ unreadOnly: true, limit: 30 }).then((ms) => push(ms.map((m) => ({ id: `email:${m.id}`, channel: "email", from: m.from, subject: m.subject, text: m.text.slice(0, 2000), ts: m.date, unread: true, priority: "normal", replyTo: m.from })))));
    if (config.google.accessToken)
      tasks.push(Google.gmailList("is:unread", 25).then((ms: any[]) => push(ms.map((m) => ({ id: `gmail:${m.id}`, channel: "gmail", from: m.from, subject: m.subject, text: m.snippet, ts: new Date(m.date).toISOString(), unread: true, priority: "normal", replyTo: m.threadId })))));
    if (config.microsoft.accessToken)
      tasks.push(Microsoft.outlookUnread(25).then((ms: any[]) => push(ms.map((m) => ({ id: `outlook:${m.id}`, channel: "outlook", from: m.from, subject: m.subject, text: m.snippet, ts: m.date, unread: true, priority: m.important ? "high" : "normal", replyTo: m.from })))));
    if (process.platform === "darwin" && process.env.IMESSAGE_ENABLED === "1")
      tasks.push(Apple.recentMessages(50).then((ms: any[]) => push(ms.filter((m) => !m.fromMe && !m.isRead).map((m) => ({ id: `imessage:${m.id}`, channel: "imessage", from: m.handle, text: m.text, ts: new Date(m.date).toISOString(), unread: true, priority: "normal", replyTo: m.handle })))));
    if (config.notify.telegramToken)
      tasks.push(messaging.telegramPoll().then((ms) => push(ms.map((m) => ({ id: `telegram:${m.chatId}:${m.id}`, channel: "telegram", from: m.from, text: m.text, ts: m.ts, unread: true, priority: "normal", replyTo: m.chatId })))));
    if (config.social.mastodonToken) tasks.push(social.notifications("mastodon").then((ps) => push(ps.map((p) => ({ id: `mastodon:${p.id}`, channel: "mastodon", from: p.author, text: p.text, ts: p.ts, unread: true, priority: "low", replyTo: p.id })))));
    if (config.social.blueskyHandle) tasks.push(social.notifications("bluesky").then((ps) => push(ps.map((p) => ({ id: `bluesky:${p.id}`, channel: "bluesky", from: p.author, text: p.text, ts: p.ts, unread: true, priority: "low", replyTo: p.id })))));
    await Promise.allSettled(tasks);
    const read = new Set(this.readState().read);
    return items
      .filter((i) => !read.has(i.id))
      .map((i) => ({ ...i, priority: i.priority === "high" || URGENT.test(`${i.subject ?? ""} ${i.text}`) ? "high" : i.priority }) as InboxItem)
      .sort((a, b) => (a.priority === b.priority ? b.ts.localeCompare(a.ts) : a.priority === "high" ? -1 : 1));
  }

  async unreadCount() {
    const items = await this.collect();
    return { total: items.length, high: items.filter((i) => i.priority === "high").length, byChannel: items.reduce<Record<string, number>>((a, i) => ((a[i.channel] = (a[i.channel] ?? 0) + 1), a), {}) };
  }

  markRead(id: string) {
    const s = this.readState();
    s.read = [...new Set([...s.read, id])].slice(-5000);
    writeJson(this.stateFile, s);
    if (id.startsWith("email:")) void assistantEmail.markRead(id.slice(6)).catch(() => undefined);
  }

  async draftReply(item: InboxItem, guidance = ""): Promise<string> {
    return complete(`Draft a short, friendly reply in the sender's language.\nFrom: ${item.from}\n${item.subject ? `Subject: ${item.subject}\n` : ""}Message:\n${item.text}\n${guidance ? `Guidance: ${guidance}` : ""}\nReply text only.`);
  }

  async reply(item: InboxItem, text: string) {
    switch (item.channel) {
      case "email":
        return assistantEmail.send(item.replyTo!, `Re: ${item.subject ?? ""}`, text);
      case "gmail":
        return Google.gmailSend(item.from, `Re: ${item.subject ?? ""}`, text, item.replyTo);
      case "outlook":
        return Microsoft.outlookSend(item.replyTo!, `Re: ${item.subject ?? ""}`, text);
      case "imessage":
        return Apple.sendMessage(item.replyTo!, text);
      case "telegram":
        return messaging.telegramSend(item.replyTo!, text);
      case "mastodon":
      case "bluesky":
      case "x":
        return social.post(item.channel, text, item.replyTo);
    }
  }
}

export const inbox = new UnifiedInbox();
