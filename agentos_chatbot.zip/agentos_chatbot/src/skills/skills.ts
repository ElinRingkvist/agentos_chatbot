import { bus } from "../events/bus";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";
import { complete } from "../ai/llm";
import { OpenMausBotConnector } from "../connectors/mausBot";
import { tools, ToolContext } from "../tools/registry";

export interface SkillStep {
  kind: string; // gui.click | gui.type | gui.key | browser.* | tool | shell
  data: Record<string, unknown>;
  delayMs?: number;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  /** Parameters referenced as {{name}} inside step data. */
  params: string[];
  steps: SkillStep[];
  createdAt: string;
  source: "demonstration" | "manual" | "generated";
}

/**
 * Skills: reusable multi-step procedures. Learned by demonstration (the
 * recorder captures GUI, browser and tool actions while the user performs a
 * task) or written manually, then replayed with parameters or scheduled
 * as routines.
 */
export class SkillLibrary {
  private file = dataPath("skills.json");
  private recording: { name: string; steps: SkillStep[]; last: number; unsub: () => void } | null = null;

  list(): Skill[] {
    return readJson<Skill[]>(this.file, []);
  }
  get(nameOrId: string) {
    return this.list().find((s) => s.id === nameOrId || s.name === nameOrId);
  }
  save(skill: Skill) {
    const all = this.list().filter((s) => s.id !== skill.id && s.name !== skill.name);
    all.push(skill);
    writeJson(this.file, all);
    return skill;
  }
  remove(nameOrId: string) {
    writeJson(this.file, this.list().filter((s) => s.id !== nameOrId && s.name !== nameOrId));
  }

  /** Start watching the user's actions ("look over your shoulder"). */
  startRecording(name: string) {
    if (this.recording) throw new Error("Already recording");
    const steps: SkillStep[] = [];
    let last = Date.now();
    const unsub1 = bus.on("demo.action", (a) => {
      const now = Date.now();
      steps.push({ kind: a.kind, data: a.data, delayMs: Math.min(now - last, 10_000) });
      last = now;
    });
    const unsub2 = bus.on("tool.called", (t) => {
      if (!t.allowed || t.tool.startsWith("browser.")) return;
      const now = Date.now();
      steps.push({ kind: "tool", data: { tool: t.tool, args: t.args as Record<string, unknown> }, delayMs: Math.min(now - last, 10_000) });
      last = now;
    });
    this.recording = { name, steps, last, unsub: () => (unsub1(), unsub2()) };
    Logger.info("Skills", `Recording demonstration "${name}"... perform the task now.`);
  }

  /** Manually record a step (e.g. from an OS input hook or companion app). */
  recordStep(step: SkillStep) {
    this.recording?.steps.push(step);
  }

  /**
   * Stop recording. Values that look like inputs (typed text, form values, URLs)
   * are turned into {{params}} so the skill generalises, and an LLM writes a description.
   */
  async stopRecording(paramHints: string[] = []): Promise<Skill> {
    if (!this.recording) throw new Error("Not recording");
    const { name, steps, unsub } = this.recording;
    unsub();
    this.recording = null;
    const params = new Set<string>();
    for (const s of steps) {
      for (const hint of paramHints) {
        for (const [k, v] of Object.entries(s.data)) {
          if (typeof v === "string" && v.includes(hint)) {
            const p = `param${params.size + 1}`;
            params.add(p);
            s.data[k] = v.split(hint).join(`{{${p}}}`);
          }
        }
      }
    }
    const description = await complete(`Describe in one sentence what this recorded workflow does:\n${JSON.stringify(steps).slice(0, 4000)}`);
    const skill: Skill = { id: uid("skill"), name, description, params: [...params], steps, createdAt: new Date().toISOString(), source: "demonstration" };
    this.save(skill);
    Logger.success("Skills", `Saved skill "${name}" with ${steps.length} steps.`);
    return skill;
  }

  async run(nameOrId: string, params: Record<string, string> = {}, ctx: ToolContext, opts: { speed?: number } = {}) {
    const skill = this.get(nameOrId);
    if (!skill) throw new Error(`Unknown skill ${nameOrId}`);
    const fill = (v: unknown): any =>
      typeof v === "string" ? v.replace(/\{\{(\w+)\}\}/g, (_, k) => params[k] ?? "") : Array.isArray(v) ? v.map(fill) : v && typeof v === "object" ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, fill(x)])) : v;
    const results: unknown[] = [];
    for (const step of skill.steps) {
      if (step.delayMs) await new Promise((r) => setTimeout(r, step.delayMs! / (opts.speed ?? 4)));
      const d = fill(step.data);
      switch (step.kind) {
        case "gui.click":
          await OpenMausBotConnector.moveAndClick({ x: d.x, y: d.y }, d.button);
          break;
        case "gui.type":
          await OpenMausBotConnector.typeText(d.text);
          break;
        case "gui.key":
          await OpenMausBotConnector.pressKey(d.combo);
          break;
        case "tool":
          results.push(await tools.invoke(d.tool, d.args ?? {}, ctx));
          break;
        default:
          if (step.kind.startsWith("browser.")) {
            const map: Record<string, [string, Record<string, unknown>]> = {
              "browser.goto": ["browser.goto", { url: d.url }],
              "browser.click": ["browser.click", { target: d.target }],
              "browser.fill": ["browser.fill", { selector: d.selector, value: d.value }],
              "browser.submit": ["browser.submit", { selector: d.selector }],
            };
            const m = map[step.kind];
            if (m) results.push(await tools.invoke(m[0], m[1], ctx));
          }
      }
    }
    return results;
  }
}

export const skills = new SkillLibrary();
