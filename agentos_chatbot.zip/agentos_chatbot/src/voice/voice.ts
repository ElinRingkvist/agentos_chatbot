import * as fs from "fs";
import { HuggingFaceConnector } from "../ai/huggingFace";
import { runSandboxed } from "../security/sandbox";
import { dataPath } from "../utils/fsx";

/**
 * Voice input/output. Speech-to-text runs locally with whisper.cpp when
 * WHISPER_CPP_BIN + WHISPER_MODEL are set (fully offline), otherwise via the
 * Hugging Face Whisper endpoint. Text-to-speech uses the OS voice (say / espeak / SAPI).
 */
export class VoiceIO {
  async transcribe(audioFile: string, language = "auto"): Promise<string> {
    const bin = process.env.WHISPER_CPP_BIN;
    const model = process.env.WHISPER_MODEL;
    if (bin && model) {
      const wav = audioFile.endsWith(".wav") ? audioFile : dataPath("audio", `conv-${Date.now()}.wav`);
      if (wav !== audioFile) await runSandboxed(`ffmpeg -y -i "${audioFile}" -ar 16000 -ac 1 "${wav}"`, { cwd: process.cwd(), timeoutMs: 60_000 });
      const r = await runSandboxed(`"${bin}" -m "${model}" -f "${wav}" -l ${language} -nt -np`, { cwd: process.cwd(), timeoutMs: 300_000 });
      if (r.code === 0) return r.stdout.trim();
    }
    return new HuggingFaceConnector().transcribe(fs.readFileSync(audioFile), undefined, audioFile.endsWith(".mp3") ? "audio/mpeg" : audioFile.endsWith(".webm") ? "audio/webm" : "audio/wav");
  }

  async speak(text: string, voice?: string) {
    const t = text.replace(/["`$\\]/g, "");
    const cmd =
      process.platform === "darwin"
        ? `say ${voice ? `-v "${voice}"` : ""} "${t}"`
        : process.platform === "win32"
          ? `powershell -NoProfile -Command "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('${t.replace(/'/g, "''")}')"`
          : `espeak-ng ${voice ? `-v ${voice}` : ""} "${t}" || espeak "${t}"`;
    await runSandboxed(cmd, { cwd: process.cwd(), timeoutMs: 120_000, env: { HOME: process.env.HOME ?? "" } });
  }
}

export const voice = new VoiceIO();
