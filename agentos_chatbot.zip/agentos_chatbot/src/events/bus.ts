import { EventEmitter } from "events";
import { appendJsonl, dataPath } from "../utils/fsx";

export type AgentStatus = "Idle" | "Working" | "Waiting" | "Done" | "Error";

/** Every event the OS emits. The remote-control API streams these over SSE. */
export interface AgentOSEvents {
  "agent.status": { agent: string; status: AgentStatus; detail?: string; taskId?: string };
  "agent.message": { agent: string; threadId?: string; text: string };
  "task.created": { taskId: string; title: string; agent: string };
  "task.progress": { taskId: string; step: number; total: number; note: string };
  "task.completed": { taskId: string; result: string };
  "task.failed": { taskId: string; error: string };
  "approval.requested": { id: string; agent: string; action: string; payload: string };
  "approval.resolved": { id: string; decision: "approved" | "rejected" | "edited"; payload?: string };
  "notification": { title: string; body: string; priority: "low" | "normal" | "high" | "critical"; effect?: string };
  "tool.called": { agent: string; tool: string; args: unknown; allowed: boolean };
  "demo.action": { kind: string; data: Record<string, unknown> };
  "device.handoff": { sessionId: string; from: string; to: string };
  "trigger": { name: string; data?: unknown };
}

type Key = keyof AgentOSEvents;

class TypedBus {
  private emitter = new EventEmitter();
  private persist = true;
  constructor() {
    this.emitter.setMaxListeners(200);
  }
  on<K extends Key>(event: K, fn: (data: AgentOSEvents[K]) => void) {
    this.emitter.on(event, fn);
    return () => this.emitter.off(event, fn);
  }
  onAny(fn: (event: Key, data: unknown) => void) {
    this.emitter.on("*", fn);
    return () => this.emitter.off("*", fn);
  }
  emit<K extends Key>(event: K, data: AgentOSEvents[K]) {
    this.emitter.emit(event, data);
    this.emitter.emit("*", event, data);
    if (this.persist) {
      try {
        appendJsonl(dataPath("events.jsonl"), { ts: new Date().toISOString(), event, data });
      } catch {
        /* event log is best-effort */
      }
    }
  }
  setPersistence(on: boolean) {
    this.persist = on;
  }
}

export const bus = new TypedBus();
