import * as crypto from "crypto";
import { bus } from "../events/bus";
import { dataPath, readJson, uid, writeJson } from "../utils/fsx";

export type Platform = "macos" | "windows" | "linux" | "ios" | "android" | "ipados" | "web";

export interface Device {
  id: string;
  name: string;
  platform: Platform;
  tokenHash: string;
  pairedAt: string;
  lastSeen: string;
  online: boolean;
  capabilities: string[]; // "notifications" | "voice" | "location" | "gui" | "browser" | "overlay"
  pushTopic?: string;
}

export interface Session {
  id: string;
  agent: string;
  threadId: string;
  activeDevice: string | null;
  state: Record<string, unknown>;
  updatedAt: string;
}

const hash = (t: string) => crypto.createHash("sha256").update(t).digest("hex");

/**
 * Cross-device layer: pairing (desktop, tablet, phone — iOS, Android,
 * Linux, macOS, Windows), presence heartbeats, and session handoff.
 * When a device goes offline (laptop closed) the session keeps running on
 * the daemon and is handed off to the next online device automatically.
 */
export class DeviceHub {
  private file = dataPath("devices.json");
  private pairCodes = new Map<string, { expires: number }>();
  offlineAfterMs = 90_000;

  private load(): { devices: Device[]; sessions: Session[] } {
    return readJson(this.file, { devices: [], sessions: [] });
  }
  private save(d: { devices: Device[]; sessions: Session[] }) {
    writeJson(this.file, d);
  }

  /** Short-lived 6-digit code shown on the host (or as QR) for pairing a phone. */
  createPairingCode(): string {
    const code = String(crypto.randomInt(0, 1_000_000)).padStart(6, "0");
    this.pairCodes.set(code, { expires: Date.now() + 5 * 60_000 });
    return code;
  }

  pair(code: string, name: string, platform: Platform, capabilities: string[] = []): { device: Device; token: string } {
    const c = this.pairCodes.get(code);
    if (!c || c.expires < Date.now()) throw new Error("Invalid or expired pairing code");
    this.pairCodes.delete(code);
    const token = crypto.randomBytes(32).toString("base64url");
    const now = new Date().toISOString();
    const device: Device = { id: uid("dev"), name, platform, tokenHash: hash(token), pairedAt: now, lastSeen: now, online: true, capabilities };
    const d = this.load();
    d.devices.push(device);
    this.save(d);
    return { device, token };
  }

  authenticate(token: string): Device | null {
    return this.load().devices.find((x) => x.tokenHash === hash(token)) ?? null;
  }

  heartbeat(deviceId: string, extra: { location?: { lat: number; lon: number } } = {}) {
    const d = this.load();
    const dev = d.devices.find((x) => x.id === deviceId);
    if (!dev) return;
    dev.lastSeen = new Date().toISOString();
    dev.online = true;
    this.save(d);
    if (extra.location) writeJson(dataPath("last-location.json"), { ...extra.location, ts: dev.lastSeen, device: deviceId });
  }

  revoke(deviceId: string) {
    const d = this.load();
    d.devices = d.devices.filter((x) => x.id !== deviceId);
    this.save(d);
  }

  list(): Omit<Device, "tokenHash">[] {
    return this.refreshPresence().devices.map(({ tokenHash: _t, ...rest }) => rest);
  }

  private refreshPresence() {
    const d = this.load();
    let changed = false;
    for (const dev of d.devices) {
      const online = Date.now() - new Date(dev.lastSeen).getTime() < this.offlineAfterMs;
      if (online !== dev.online) {
        dev.online = online;
        changed = true;
      }
    }
    // Hand off sessions whose device went offline.
    for (const s of d.sessions) {
      const active = d.devices.find((x) => x.id === s.activeDevice);
      if (s.activeDevice && (!active || !active.online)) {
        const next = d.devices.filter((x) => x.online).sort((a, b) => b.lastSeen.localeCompare(a.lastSeen))[0];
        bus.emit("device.handoff", { sessionId: s.id, from: s.activeDevice, to: next?.id ?? "daemon" });
        s.activeDevice = next?.id ?? null;
        s.updatedAt = new Date().toISOString();
        changed = true;
      }
    }
    if (changed) this.save(d);
    return d;
  }

  openSession(agent: string, threadId: string, deviceId: string | null): Session {
    const d = this.load();
    const s: Session = { id: uid("ses"), agent, threadId, activeDevice: deviceId, state: {}, updatedAt: new Date().toISOString() };
    d.sessions.push(s);
    this.save(d);
    return s;
  }

  /** Explicitly continue a session on another device. */
  handoff(sessionId: string, toDevice: string) {
    const d = this.load();
    const s = d.sessions.find((x) => x.id === sessionId);
    if (!s) throw new Error("Unknown session");
    bus.emit("device.handoff", { sessionId, from: s.activeDevice ?? "daemon", to: toDevice });
    s.activeDevice = toDevice;
    s.updatedAt = new Date().toISOString();
    this.save(d);
    return s;
  }

  updateSessionState(sessionId: string, patch: Record<string, unknown>) {
    const d = this.load();
    const s = d.sessions.find((x) => x.id === sessionId);
    if (!s) throw new Error("Unknown session");
    s.state = { ...s.state, ...patch };
    s.updatedAt = new Date().toISOString();
    this.save(d);
    return s;
  }

  sessions() {
    return this.refreshPresence().sessions;
  }

  startPresenceMonitor(intervalMs = 30_000) {
    return setInterval(() => this.refreshPresence(), intervalMs);
  }
}

export const devices = new DeviceHub();
