import * as fs from "fs";
import * as path from "path";
import * as crypto from "crypto";
import { VectorStore } from "../ai/embeddings";
import { dataPath, readJson, walkFiles, writeJson } from "../utils/fsx";
import { Logger } from "../utils/logger";

export interface CodeSymbol {
  name: string;
  kind: "class" | "function" | "interface" | "type" | "method" | "const" | "enum" | "struct";
  file: string;
  line: number;
  signature: string;
}

export interface ChunkMeta {
  file: string;
  startLine: number;
  endLine: number;
  symbols: string[];
  preview: string;
}

const CODE_EXT = /\.(ts|tsx|js|jsx|mjs|cjs|py|go|rs|java|kt|swift|rb|php|cs|c|cc|cpp|h|hpp|vue|svelte|sql|md|json|yaml|yml|toml)$/i;

const SYMBOL_PATTERNS: { kind: CodeSymbol["kind"]; re: RegExp }[] = [
  { kind: "class", re: /^\s*(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)/ },
  { kind: "interface", re: /^\s*(?:export\s+)?interface\s+([A-Za-z_$][\w$]*)/ },
  { kind: "type", re: /^\s*(?:export\s+)?type\s+([A-Za-z_$][\w$]*)\s*[=<]/ },
  { kind: "enum", re: /^\s*(?:export\s+)?(?:const\s+)?enum\s+([A-Za-z_$][\w$]*)/ },
  { kind: "function", re: /^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)/ },
  { kind: "const", re: /^\s*(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>/ },
  { kind: "method", re: /^\s+(?:public|private|protected|static|async|\s)*([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*(?::\s*[^{]+)?\{\s*$/ },
  { kind: "function", re: /^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)/ },
  { kind: "class", re: /^\s*class\s+([A-Za-z_]\w*)\s*[:(]/ },
  { kind: "function", re: /^\s*func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)/ },
  { kind: "struct", re: /^\s*(?:pub\s+)?(?:struct|type)\s+([A-Z]\w*)\s+(?:struct|\{)/ },
  { kind: "function", re: /^\s*(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)/ },
];

const KEYWORDS = new Set(["if", "for", "while", "switch", "catch", "return", "function", "constructor"]);

export function extractSymbols(file: string, content: string): CodeSymbol[] {
  const out: CodeSymbol[] = [];
  content.split("\n").forEach((line, i) => {
    for (const { kind, re } of SYMBOL_PATTERNS) {
      const m = line.match(re);
      if (m && !KEYWORDS.has(m[1])) {
        out.push({ name: m[1], kind, file, line: i + 1, signature: line.trim().slice(0, 200) });
        break;
      }
    }
  });
  return out;
}

interface IndexFile {
  root: string;
  hashes: Record<string, string>;
  symbols: CodeSymbol[];
  records: VectorStore<ChunkMeta>["records"];
}

/**
 * Semantic codebase index. Stored locally (never uploaded) under the AgentOS
 * data dir. Incremental: only re-chunks files whose content hash changed.
 */
export class CodeIndex {
  private store = new VectorStore<ChunkMeta>();
  private symbols: CodeSymbol[] = [];
  private hashes: Record<string, string> = {};
  private file: string;

  constructor(public readonly root: string) {
    const key = crypto.createHash("sha1").update(path.resolve(root)).digest("hex").slice(0, 12);
    this.file = dataPath("index", `${key}.json`);
    const saved = readJson<IndexFile | null>(this.file, null);
    if (saved) {
      this.store.records = saved.records;
      this.symbols = saved.symbols;
      this.hashes = saved.hashes;
    }
  }

  build(opts: { chunkLines?: number; overlap?: number; maxFileBytes?: number } = {}) {
    const chunkLines = opts.chunkLines ?? 60;
    const overlap = opts.overlap ?? 10;
    const files = walkFiles(this.root).filter((f) => CODE_EXT.test(f));
    const seen = new Set<string>();
    let changed = 0;
    for (const abs of files) {
      const rel = path.relative(this.root, abs);
      seen.add(rel);
      const stat = fs.statSync(abs);
      if (stat.size > (opts.maxFileBytes ?? 512_000)) continue;
      const content = fs.readFileSync(abs, "utf-8");
      const hash = crypto.createHash("sha1").update(content).digest("hex");
      if (this.hashes[rel] === hash) continue;
      changed++;
      this.hashes[rel] = hash;
      this.store.removeWhere((m) => m.file === rel);
      this.symbols = this.symbols.filter((s) => s.file !== rel);
      const syms = extractSymbols(rel, content);
      this.symbols.push(...syms);
      const lines = content.split("\n");
      for (let start = 0; start < lines.length; start += chunkLines - overlap) {
        const end = Math.min(lines.length, start + chunkLines);
        const text = lines.slice(start, end).join("\n");
        const inChunk = syms.filter((s) => s.line > start && s.line <= end).map((s) => s.name);
        this.store.add(`${rel}:${start + 1}`, `${rel}\n${inChunk.join(" ")}\n${text}`, {
          file: rel,
          startLine: start + 1,
          endLine: end,
          symbols: inChunk,
          preview: text.slice(0, 400),
        });
        if (end === lines.length) break;
      }
    }
    for (const rel of Object.keys(this.hashes)) {
      if (!seen.has(rel)) {
        delete this.hashes[rel];
        this.store.removeWhere((m) => m.file === rel);
        this.symbols = this.symbols.filter((s) => s.file !== rel);
      }
    }
    this.save();
    Logger.success("CodeIndex", `Indexed ${files.length} files (${changed} changed), ${this.symbols.length} symbols, ${this.store.records.length} chunks.`);
    return { files: files.length, changed, symbols: this.symbols.length, chunks: this.store.records.length };
  }

  private save() {
    writeJson(this.file, { root: this.root, hashes: this.hashes, symbols: this.symbols, records: this.store.records } satisfies IndexFile);
  }

  search(query: string, k = 8) {
    return this.store.query(query, k).map((r) => ({ ...r.meta, score: Number(r.score.toFixed(4)) }));
  }

  findSymbol(name: string): CodeSymbol[] {
    const lower = name.toLowerCase();
    return this.symbols
      .filter((s) => s.name.toLowerCase().includes(lower))
      .sort((a, b) => Number(b.name.toLowerCase() === lower) - Number(a.name.toLowerCase() === lower))
      .slice(0, 50);
  }

  /** Architecture overview: files grouped by directory with their top-level symbols. */
  outline(): string {
    const byFile = new Map<string, CodeSymbol[]>();
    for (const s of this.symbols) {
      if (s.kind === "method") continue;
      byFile.set(s.file, [...(byFile.get(s.file) ?? []), s]);
    }
    return [...byFile.entries()]
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([f, syms]) => `${f}: ${syms.map((s) => `${s.kind} ${s.name}`).join(", ")}`)
      .join("\n");
  }
}
